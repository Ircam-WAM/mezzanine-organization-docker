--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.3
-- Dumped by pg_dump version 9.5.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_groups_id_seq OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_id_seq OWNER TO postgres;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: blog_blogcategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE blog_blogcategory (
    id integer NOT NULL,
    title character varying(500) NOT NULL,
    slug character varying(2000),
    site_id integer NOT NULL,
    title_en character varying(500),
    title_fr character varying(500)
);


ALTER TABLE blog_blogcategory OWNER TO postgres;

--
-- Name: blog_blogcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE blog_blogcategory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE blog_blogcategory_id_seq OWNER TO postgres;

--
-- Name: blog_blogcategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE blog_blogcategory_id_seq OWNED BY blog_blogcategory.id;


--
-- Name: blog_blogpost; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE blog_blogpost (
    id integer NOT NULL,
    comments_count integer NOT NULL,
    keywords_string character varying(500) NOT NULL,
    rating_count integer NOT NULL,
    rating_sum integer NOT NULL,
    rating_average double precision NOT NULL,
    title character varying(500) NOT NULL,
    slug character varying(2000),
    _meta_title character varying(500),
    description text NOT NULL,
    gen_description boolean NOT NULL,
    created timestamp with time zone,
    updated timestamp with time zone,
    status integer NOT NULL,
    publish_date timestamp with time zone,
    expiry_date timestamp with time zone,
    short_url character varying(200),
    in_sitemap boolean NOT NULL,
    content text NOT NULL,
    allow_comments boolean NOT NULL,
    featured_image character varying(255),
    site_id integer NOT NULL,
    user_id integer NOT NULL,
    _meta_title_en character varying(500),
    _meta_title_fr character varying(500),
    content_en text,
    content_fr text,
    description_en text,
    description_fr text,
    title_en character varying(500),
    title_fr character varying(500)
);


ALTER TABLE blog_blogpost OWNER TO postgres;

--
-- Name: blog_blogpost_categories; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE blog_blogpost_categories (
    id integer NOT NULL,
    blogpost_id integer NOT NULL,
    blogcategory_id integer NOT NULL
);


ALTER TABLE blog_blogpost_categories OWNER TO postgres;

--
-- Name: blog_blogpost_categories_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE blog_blogpost_categories_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE blog_blogpost_categories_id_seq OWNER TO postgres;

--
-- Name: blog_blogpost_categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE blog_blogpost_categories_id_seq OWNED BY blog_blogpost_categories.id;


--
-- Name: blog_blogpost_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE blog_blogpost_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE blog_blogpost_id_seq OWNER TO postgres;

--
-- Name: blog_blogpost_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE blog_blogpost_id_seq OWNED BY blog_blogpost.id;


--
-- Name: blog_blogpost_related_posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE blog_blogpost_related_posts (
    id integer NOT NULL,
    from_blogpost_id integer NOT NULL,
    to_blogpost_id integer NOT NULL
);


ALTER TABLE blog_blogpost_related_posts OWNER TO postgres;

--
-- Name: blog_blogpost_related_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE blog_blogpost_related_posts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE blog_blogpost_related_posts_id_seq OWNER TO postgres;

--
-- Name: blog_blogpost_related_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE blog_blogpost_related_posts_id_seq OWNED BY blog_blogpost_related_posts.id;


--
-- Name: conf_setting; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE conf_setting (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    value character varying(2000) NOT NULL,
    site_id integer NOT NULL,
    value_en character varying(2000),
    value_fr character varying(2000)
);


ALTER TABLE conf_setting OWNER TO postgres;

--
-- Name: conf_setting_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE conf_setting_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE conf_setting_id_seq OWNER TO postgres;

--
-- Name: conf_setting_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE conf_setting_id_seq OWNED BY conf_setting.id;


--
-- Name: core_sitepermission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE core_sitepermission (
    id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE core_sitepermission OWNER TO postgres;

--
-- Name: core_sitepermission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE core_sitepermission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core_sitepermission_id_seq OWNER TO postgres;

--
-- Name: core_sitepermission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE core_sitepermission_id_seq OWNED BY core_sitepermission.id;


--
-- Name: core_sitepermission_sites; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE core_sitepermission_sites (
    id integer NOT NULL,
    sitepermission_id integer NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE core_sitepermission_sites OWNER TO postgres;

--
-- Name: core_sitepermission_sites_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE core_sitepermission_sites_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE core_sitepermission_sites_id_seq OWNER TO postgres;

--
-- Name: core_sitepermission_sites_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE core_sitepermission_sites_id_seq OWNED BY core_sitepermission_sites.id;


--
-- Name: custom_basicpage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE custom_basicpage (
    page_ptr_id integer NOT NULL,
    content text NOT NULL,
    sub_title character varying(1000) NOT NULL,
    sub_title_en character varying(1000),
    sub_title_fr character varying(1000),
    photo character varying(1024) NOT NULL,
    photo_alignment character varying(32) NOT NULL,
    photo_credits character varying(255),
    photo_description text NOT NULL,
    photo_featured character varying(1024) NOT NULL,
    photo_featured_credits character varying(255)
);


ALTER TABLE custom_basicpage OWNER TO postgres;

--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_comment_flags; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE django_comment_flags (
    id integer NOT NULL,
    flag character varying(30) NOT NULL,
    flag_date timestamp with time zone NOT NULL,
    comment_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE django_comment_flags OWNER TO postgres;

--
-- Name: django_comment_flags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_comment_flags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_comment_flags_id_seq OWNER TO postgres;

--
-- Name: django_comment_flags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_comment_flags_id_seq OWNED BY django_comment_flags.id;


--
-- Name: django_comments; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE django_comments (
    id integer NOT NULL,
    object_pk text NOT NULL,
    user_name character varying(50) NOT NULL,
    user_email character varying(254) NOT NULL,
    user_url character varying(200) NOT NULL,
    comment text NOT NULL,
    submit_date timestamp with time zone NOT NULL,
    ip_address inet,
    is_public boolean NOT NULL,
    is_removed boolean NOT NULL,
    content_type_id integer NOT NULL,
    site_id integer NOT NULL,
    user_id integer
);


ALTER TABLE django_comments OWNER TO postgres;

--
-- Name: django_comments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_comments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_comments_id_seq OWNER TO postgres;

--
-- Name: django_comments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_comments_id_seq OWNED BY django_comments.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_migrations_id_seq OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_migrations_id_seq OWNED BY django_migrations.id;


--
-- Name: django_redirect; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE django_redirect (
    id integer NOT NULL,
    site_id integer NOT NULL,
    old_path character varying(200) NOT NULL,
    new_path character varying(200) NOT NULL
);


ALTER TABLE django_redirect OWNER TO postgres;

--
-- Name: django_redirect_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_redirect_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_redirect_id_seq OWNER TO postgres;

--
-- Name: django_redirect_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_redirect_id_seq OWNED BY django_redirect.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE django_session OWNER TO postgres;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE django_site OWNER TO postgres;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_site_id_seq OWNER TO postgres;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_site_id_seq OWNED BY django_site.id;


--
-- Name: featured_featured; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE featured_featured (
    id integer NOT NULL,
    name character varying(512) NOT NULL,
    description text NOT NULL
);


ALTER TABLE featured_featured OWNER TO postgres;

--
-- Name: featured_featured_articles; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE featured_featured_articles (
    id integer NOT NULL,
    featured_id integer NOT NULL,
    article_id integer NOT NULL
);


ALTER TABLE featured_featured_articles OWNER TO postgres;

--
-- Name: featured_featured_articles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE featured_featured_articles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE featured_featured_articles_id_seq OWNER TO postgres;

--
-- Name: featured_featured_articles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE featured_featured_articles_id_seq OWNED BY featured_featured_articles.id;


--
-- Name: featured_featured_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE featured_featured_events (
    id integer NOT NULL,
    featured_id integer NOT NULL,
    event_id integer NOT NULL
);


ALTER TABLE featured_featured_events OWNER TO postgres;

--
-- Name: featured_featured_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE featured_featured_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE featured_featured_events_id_seq OWNER TO postgres;

--
-- Name: featured_featured_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE featured_featured_events_id_seq OWNED BY featured_featured_events.id;


--
-- Name: featured_featured_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE featured_featured_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE featured_featured_id_seq OWNER TO postgres;

--
-- Name: featured_featured_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE featured_featured_id_seq OWNED BY featured_featured.id;


--
-- Name: featured_featured_pages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE featured_featured_pages (
    id integer NOT NULL,
    featured_id integer NOT NULL,
    basicpage_id integer NOT NULL
);


ALTER TABLE featured_featured_pages OWNER TO postgres;

--
-- Name: featured_featured_pages_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE featured_featured_pages_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE featured_featured_pages_id_seq OWNER TO postgres;

--
-- Name: featured_featured_pages_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE featured_featured_pages_id_seq OWNED BY featured_featured_pages.id;


--
-- Name: featured_featured_playlists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE featured_featured_playlists (
    id integer NOT NULL,
    featured_id integer NOT NULL,
    playlist_id integer NOT NULL
);


ALTER TABLE featured_featured_playlists OWNER TO postgres;

--
-- Name: featured_featured_playlists_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE featured_featured_playlists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE featured_featured_playlists_id_seq OWNER TO postgres;

--
-- Name: featured_featured_playlists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE featured_featured_playlists_id_seq OWNED BY featured_featured_playlists.id;


--
-- Name: featured_featured_videos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE featured_featured_videos (
    id integer NOT NULL,
    featured_id integer NOT NULL,
    video_id integer NOT NULL
);


ALTER TABLE featured_featured_videos OWNER TO postgres;

--
-- Name: featured_featured_videos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE featured_featured_videos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE featured_featured_videos_id_seq OWNER TO postgres;

--
-- Name: featured_featured_videos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE featured_featured_videos_id_seq OWNED BY featured_featured_videos.id;


--
-- Name: festival_artists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE festival_artists (
    id integer NOT NULL,
    keywords_string character varying(500) NOT NULL,
    title character varying(500) NOT NULL,
    title_fr character varying(500),
    title_en character varying(500),
    slug character varying(2000),
    _meta_title character varying(500),
    description text NOT NULL,
    description_fr text,
    description_en text,
    gen_description boolean NOT NULL,
    created timestamp with time zone,
    updated timestamp with time zone,
    status integer NOT NULL,
    publish_date timestamp with time zone,
    expiry_date timestamp with time zone,
    short_url character varying(200),
    in_sitemap boolean NOT NULL,
    content text NOT NULL,
    content_fr text,
    content_en text,
    bio text NOT NULL,
    bio_fr text,
    bio_en text,
    photo character varying(1024) NOT NULL,
    photo_credits character varying(255),
    site_id integer NOT NULL,
    photo_description text NOT NULL,
    photo_alignment character varying(32) NOT NULL,
    photo_featured character varying(1024) NOT NULL,
    photo_featured_credits character varying(255),
    first_name character varying(255),
    last_name character varying(255)
);


ALTER TABLE festival_artists OWNER TO postgres;

--
-- Name: festival_artists_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE festival_artists_events (
    id integer NOT NULL,
    artist_id integer NOT NULL,
    event_id integer NOT NULL
);


ALTER TABLE festival_artists_events OWNER TO postgres;

--
-- Name: festival_artists_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE festival_artists_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE festival_artists_events_id_seq OWNER TO postgres;

--
-- Name: festival_artists_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE festival_artists_events_id_seq OWNED BY festival_artists_events.id;


--
-- Name: festival_artists_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE festival_artists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE festival_artists_id_seq OWNER TO postgres;

--
-- Name: festival_artists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE festival_artists_id_seq OWNED BY festival_artists.id;


--
-- Name: festival_audios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE festival_audios (
    id integer NOT NULL,
    keywords_string character varying(500) NOT NULL,
    title character varying(500) NOT NULL,
    slug character varying(2000),
    _meta_title character varying(500),
    description text NOT NULL,
    gen_description boolean NOT NULL,
    created timestamp with time zone,
    updated timestamp with time zone,
    status integer NOT NULL,
    publish_date timestamp with time zone,
    expiry_date timestamp with time zone,
    short_url character varying(200),
    in_sitemap boolean NOT NULL,
    content text NOT NULL,
    media_id character varying(128) NOT NULL,
    open_source_url character varying(1024) NOT NULL,
    closed_source_url character varying(1024) NOT NULL,
    event_id integer,
    site_id integer NOT NULL,
    content_en text,
    content_fr text,
    description_en text,
    description_fr text,
    title_en character varying(500),
    title_fr character varying(500),
    poster_url character varying(1024) NOT NULL
);


ALTER TABLE festival_audios OWNER TO postgres;

--
-- Name: festival_audios_artists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE festival_audios_artists (
    id integer NOT NULL,
    audio_id integer NOT NULL,
    artist_id integer NOT NULL
);


ALTER TABLE festival_audios_artists OWNER TO postgres;

--
-- Name: festival_audios_artists_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE festival_audios_artists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE festival_audios_artists_id_seq OWNER TO postgres;

--
-- Name: festival_audios_artists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE festival_audios_artists_id_seq OWNED BY festival_audios_artists.id;


--
-- Name: festival_audios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE festival_audios_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE festival_audios_id_seq OWNER TO postgres;

--
-- Name: festival_audios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE festival_audios_id_seq OWNED BY festival_audios.id;


--
-- Name: festival_featured; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE festival_featured (
    id integer NOT NULL,
    name character varying(512) NOT NULL,
    description text NOT NULL
);


ALTER TABLE festival_featured OWNER TO postgres;

--
-- Name: festival_featured_artists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE festival_featured_artists (
    id integer NOT NULL,
    featured_id integer NOT NULL,
    artist_id integer NOT NULL
);


ALTER TABLE festival_featured_artists OWNER TO postgres;

--
-- Name: festival_featured_artists_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE festival_featured_artists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE festival_featured_artists_id_seq OWNER TO postgres;

--
-- Name: festival_featured_artists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE festival_featured_artists_id_seq OWNED BY festival_featured_artists.id;


--
-- Name: festival_featured_blogposts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE festival_featured_blogposts (
    id integer NOT NULL,
    featured_id integer NOT NULL,
    blogpost_id integer NOT NULL
);


ALTER TABLE festival_featured_blogposts OWNER TO postgres;

--
-- Name: festival_featured_blogpost_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE festival_featured_blogpost_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE festival_featured_blogpost_id_seq OWNER TO postgres;

--
-- Name: festival_featured_blogpost_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE festival_featured_blogpost_id_seq OWNED BY festival_featured_blogposts.id;


--
-- Name: festival_featured_events; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE festival_featured_events (
    id integer NOT NULL,
    featured_id integer NOT NULL,
    event_id integer NOT NULL
);


ALTER TABLE festival_featured_events OWNER TO postgres;

--
-- Name: festival_featured_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE festival_featured_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE festival_featured_events_id_seq OWNER TO postgres;

--
-- Name: festival_featured_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE festival_featured_events_id_seq OWNED BY festival_featured_events.id;


--
-- Name: festival_featured_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE festival_featured_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE festival_featured_id_seq OWNER TO postgres;

--
-- Name: festival_featured_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE festival_featured_id_seq OWNED BY festival_featured.id;


--
-- Name: festival_featured_pages; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE festival_featured_pages (
    id integer NOT NULL,
    featured_id integer NOT NULL,
    page_id integer NOT NULL
);


ALTER TABLE festival_featured_pages OWNER TO postgres;

--
-- Name: festival_featured_page_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE festival_featured_page_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE festival_featured_page_id_seq OWNER TO postgres;

--
-- Name: festival_featured_page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE festival_featured_page_id_seq OWNED BY festival_featured_pages.id;


--
-- Name: festival_featured_playlists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE festival_featured_playlists (
    id integer NOT NULL,
    featured_id integer NOT NULL,
    playlist_id integer NOT NULL
);


ALTER TABLE festival_featured_playlists OWNER TO postgres;

--
-- Name: festival_featured_playlists_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE festival_featured_playlists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE festival_featured_playlists_id_seq OWNER TO postgres;

--
-- Name: festival_featured_playlists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE festival_featured_playlists_id_seq OWNED BY festival_featured_playlists.id;


--
-- Name: festival_featured_videos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE festival_featured_videos (
    id integer NOT NULL,
    featured_id integer NOT NULL,
    video_id integer NOT NULL
);


ALTER TABLE festival_featured_videos OWNER TO postgres;

--
-- Name: festival_featured_videos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE festival_featured_videos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE festival_featured_videos_id_seq OWNER TO postgres;

--
-- Name: festival_featured_videos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE festival_featured_videos_id_seq OWNED BY festival_featured_videos.id;


--
-- Name: festival_playlist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE festival_playlist (
    id integer NOT NULL,
    title character varying(512) NOT NULL,
    description text NOT NULL,
    event_id integer
);


ALTER TABLE festival_playlist OWNER TO postgres;

--
-- Name: festival_playlist_audios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE festival_playlist_audios (
    id integer NOT NULL,
    playlist_id integer NOT NULL,
    audio_id integer NOT NULL
);


ALTER TABLE festival_playlist_audios OWNER TO postgres;

--
-- Name: festival_playlist_audios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE festival_playlist_audios_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE festival_playlist_audios_id_seq OWNER TO postgres;

--
-- Name: festival_playlist_audios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE festival_playlist_audios_id_seq OWNED BY festival_playlist_audios.id;


--
-- Name: festival_playlist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE festival_playlist_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE festival_playlist_id_seq OWNER TO postgres;

--
-- Name: festival_playlist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE festival_playlist_id_seq OWNED BY festival_playlist.id;


--
-- Name: festival_video_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE festival_video_category (
    id integer NOT NULL,
    title character varying(500) NOT NULL,
    slug character varying(2000),
    site_id integer NOT NULL
);


ALTER TABLE festival_video_category OWNER TO postgres;

--
-- Name: festival_video_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE festival_video_category_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE festival_video_category_id_seq OWNER TO postgres;

--
-- Name: festival_video_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE festival_video_category_id_seq OWNED BY festival_video_category.id;


--
-- Name: festival_videos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE festival_videos (
    id integer NOT NULL,
    keywords_string character varying(500) NOT NULL,
    title character varying(500) NOT NULL,
    title_fr character varying(500),
    title_en character varying(500),
    slug character varying(2000),
    _meta_title character varying(500),
    description text NOT NULL,
    description_fr text,
    description_en text,
    gen_description boolean NOT NULL,
    created timestamp with time zone,
    updated timestamp with time zone,
    status integer NOT NULL,
    publish_date timestamp with time zone,
    expiry_date timestamp with time zone,
    short_url character varying(200),
    in_sitemap boolean NOT NULL,
    content text NOT NULL,
    content_fr text,
    content_en text,
    media_id character varying(128) NOT NULL,
    event_id integer,
    site_id integer NOT NULL,
    closed_source_url character varying(1024) NOT NULL,
    open_source_url character varying(1024) NOT NULL,
    poster_url character varying(1024) NOT NULL,
    category_id integer
);


ALTER TABLE festival_videos OWNER TO postgres;

--
-- Name: festival_video_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE festival_video_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE festival_video_id_seq OWNER TO postgres;

--
-- Name: festival_video_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE festival_video_id_seq OWNED BY festival_videos.id;


--
-- Name: festival_videos_artists; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE festival_videos_artists (
    id integer NOT NULL,
    video_id integer NOT NULL,
    artist_id integer NOT NULL
);


ALTER TABLE festival_videos_artists OWNER TO postgres;

--
-- Name: festival_videos_artists_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE festival_videos_artists_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE festival_videos_artists_id_seq OWNER TO postgres;

--
-- Name: festival_videos_artists_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE festival_videos_artists_id_seq OWNED BY festival_videos_artists.id;


--
-- Name: forms_field; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE forms_field (
    id integer NOT NULL,
    _order integer,
    label character varying(200) NOT NULL,
    field_type integer NOT NULL,
    required boolean NOT NULL,
    visible boolean NOT NULL,
    choices character varying(1000) NOT NULL,
    "default" character varying(2000) NOT NULL,
    placeholder_text character varying(100) NOT NULL,
    help_text character varying(100) NOT NULL,
    form_id integer NOT NULL,
    choices_en character varying(1000),
    choices_fr character varying(1000),
    default_en character varying(2000),
    default_fr character varying(2000),
    help_text_en character varying(100),
    help_text_fr character varying(100),
    label_en character varying(200),
    label_fr character varying(200),
    placeholder_text_en character varying(100),
    placeholder_text_fr character varying(100)
);


ALTER TABLE forms_field OWNER TO postgres;

--
-- Name: forms_field_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE forms_field_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE forms_field_id_seq OWNER TO postgres;

--
-- Name: forms_field_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE forms_field_id_seq OWNED BY forms_field.id;


--
-- Name: forms_fieldentry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE forms_fieldentry (
    id integer NOT NULL,
    field_id integer NOT NULL,
    value character varying(2000),
    entry_id integer NOT NULL
);


ALTER TABLE forms_fieldentry OWNER TO postgres;

--
-- Name: forms_fieldentry_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE forms_fieldentry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE forms_fieldentry_id_seq OWNER TO postgres;

--
-- Name: forms_fieldentry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE forms_fieldentry_id_seq OWNED BY forms_fieldentry.id;


--
-- Name: forms_form; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE forms_form (
    page_ptr_id integer NOT NULL,
    content text NOT NULL,
    button_text character varying(50) NOT NULL,
    response text NOT NULL,
    send_email boolean NOT NULL,
    email_from character varying(254) NOT NULL,
    email_copies character varying(200) NOT NULL,
    email_subject character varying(200) NOT NULL,
    email_message text NOT NULL,
    button_text_en character varying(50),
    button_text_fr character varying(50),
    content_en text,
    content_fr text,
    email_message_en text,
    email_message_fr text,
    email_subject_en character varying(200),
    email_subject_fr character varying(200),
    response_en text,
    response_fr text
);


ALTER TABLE forms_form OWNER TO postgres;

--
-- Name: forms_formentry; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE forms_formentry (
    id integer NOT NULL,
    entry_time timestamp with time zone NOT NULL,
    form_id integer NOT NULL
);


ALTER TABLE forms_formentry OWNER TO postgres;

--
-- Name: forms_formentry_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE forms_formentry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE forms_formentry_id_seq OWNER TO postgres;

--
-- Name: forms_formentry_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE forms_formentry_id_seq OWNED BY forms_formentry.id;


--
-- Name: galleries_gallery; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE galleries_gallery (
    page_ptr_id integer NOT NULL,
    content text NOT NULL,
    zip_import character varying(100) NOT NULL,
    content_en text,
    content_fr text
);


ALTER TABLE galleries_gallery OWNER TO postgres;

--
-- Name: galleries_galleryimage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE galleries_galleryimage (
    id integer NOT NULL,
    _order integer,
    file character varying(200) NOT NULL,
    description character varying(1000) NOT NULL,
    gallery_id integer NOT NULL,
    description_en character varying(1000),
    description_fr character varying(1000)
);


ALTER TABLE galleries_galleryimage OWNER TO postgres;

--
-- Name: galleries_galleryimage_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE galleries_galleryimage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE galleries_galleryimage_id_seq OWNER TO postgres;

--
-- Name: galleries_galleryimage_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE galleries_galleryimage_id_seq OWNED BY galleries_galleryimage.id;


--
-- Name: generic_assignedkeyword; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE generic_assignedkeyword (
    id integer NOT NULL,
    _order integer,
    object_pk integer NOT NULL,
    content_type_id integer NOT NULL,
    keyword_id integer NOT NULL
);


ALTER TABLE generic_assignedkeyword OWNER TO postgres;

--
-- Name: generic_assignedkeyword_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE generic_assignedkeyword_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE generic_assignedkeyword_id_seq OWNER TO postgres;

--
-- Name: generic_assignedkeyword_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE generic_assignedkeyword_id_seq OWNED BY generic_assignedkeyword.id;


--
-- Name: generic_keyword; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE generic_keyword (
    id integer NOT NULL,
    title character varying(500) NOT NULL,
    slug character varying(2000),
    site_id integer NOT NULL
);


ALTER TABLE generic_keyword OWNER TO postgres;

--
-- Name: generic_keyword_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE generic_keyword_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE generic_keyword_id_seq OWNER TO postgres;

--
-- Name: generic_keyword_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE generic_keyword_id_seq OWNED BY generic_keyword.id;


--
-- Name: generic_rating; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE generic_rating (
    id integer NOT NULL,
    value integer NOT NULL,
    rating_date timestamp with time zone,
    object_pk integer NOT NULL,
    content_type_id integer NOT NULL,
    user_id integer
);


ALTER TABLE generic_rating OWNER TO postgres;

--
-- Name: generic_rating_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE generic_rating_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE generic_rating_id_seq OWNER TO postgres;

--
-- Name: generic_rating_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE generic_rating_id_seq OWNED BY generic_rating.id;


--
-- Name: generic_threadedcomment; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE generic_threadedcomment (
    comment_ptr_id integer NOT NULL,
    rating_count integer NOT NULL,
    rating_sum integer NOT NULL,
    rating_average double precision NOT NULL,
    by_author boolean NOT NULL,
    replied_to_id integer
);


ALTER TABLE generic_threadedcomment OWNER TO postgres;

--
-- Name: mezzanine_agenda_event; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mezzanine_agenda_event (
    id integer NOT NULL,
    comments_count integer NOT NULL,
    keywords_string character varying(500) NOT NULL,
    rating_count integer NOT NULL,
    rating_sum integer NOT NULL,
    rating_average double precision NOT NULL,
    title character varying(500) NOT NULL,
    title_fr character varying(500),
    title_en character varying(500),
    slug character varying(2000),
    _meta_title character varying(500),
    description text NOT NULL,
    gen_description boolean NOT NULL,
    created timestamp with time zone,
    updated timestamp with time zone,
    status integer NOT NULL,
    publish_date timestamp with time zone,
    expiry_date timestamp with time zone,
    short_url character varying(200),
    in_sitemap boolean NOT NULL,
    content text NOT NULL,
    start timestamp with time zone NOT NULL,
    "end" timestamp with time zone,
    facebook_event bigint,
    allow_comments boolean NOT NULL,
    featured_image character varying(255),
    location_id integer,
    site_id integer NOT NULL,
    user_id integer NOT NULL,
    content_en text,
    content_fr text,
    external_id integer,
    featured_image_description text NOT NULL,
    featured_image_header character varying(1024) NOT NULL,
    parent_id integer,
    category_id integer,
    description_en text,
    description_fr text,
    brochure character varying(1024) NOT NULL
);


ALTER TABLE mezzanine_agenda_event OWNER TO postgres;

--
-- Name: mezzanine_agenda_event_blog_posts; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mezzanine_agenda_event_blog_posts (
    id integer NOT NULL,
    event_id integer NOT NULL,
    blogpost_id integer NOT NULL
);


ALTER TABLE mezzanine_agenda_event_blog_posts OWNER TO postgres;

--
-- Name: mezzanine_agenda_event_blog_posts_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mezzanine_agenda_event_blog_posts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mezzanine_agenda_event_blog_posts_id_seq OWNER TO postgres;

--
-- Name: mezzanine_agenda_event_blog_posts_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE mezzanine_agenda_event_blog_posts_id_seq OWNED BY mezzanine_agenda_event_blog_posts.id;


--
-- Name: mezzanine_agenda_event_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mezzanine_agenda_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mezzanine_agenda_event_id_seq OWNER TO postgres;

--
-- Name: mezzanine_agenda_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE mezzanine_agenda_event_id_seq OWNED BY mezzanine_agenda_event.id;


--
-- Name: mezzanine_agenda_event_prices; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mezzanine_agenda_event_prices (
    id integer NOT NULL,
    event_id integer NOT NULL,
    eventprice_id integer NOT NULL
);


ALTER TABLE mezzanine_agenda_event_prices OWNER TO postgres;

--
-- Name: mezzanine_agenda_event_prices_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mezzanine_agenda_event_prices_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mezzanine_agenda_event_prices_id_seq OWNER TO postgres;

--
-- Name: mezzanine_agenda_event_prices_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE mezzanine_agenda_event_prices_id_seq OWNED BY mezzanine_agenda_event_prices.id;


--
-- Name: mezzanine_agenda_eventcategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mezzanine_agenda_eventcategory (
    id integer NOT NULL,
    name character varying(512) NOT NULL,
    description text NOT NULL
);


ALTER TABLE mezzanine_agenda_eventcategory OWNER TO postgres;

--
-- Name: mezzanine_agenda_eventcategory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mezzanine_agenda_eventcategory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mezzanine_agenda_eventcategory_id_seq OWNER TO postgres;

--
-- Name: mezzanine_agenda_eventcategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE mezzanine_agenda_eventcategory_id_seq OWNED BY mezzanine_agenda_eventcategory.id;


--
-- Name: mezzanine_agenda_eventlocation; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mezzanine_agenda_eventlocation (
    id integer NOT NULL,
    title character varying(500) NOT NULL,
    slug character varying(2000),
    address text NOT NULL,
    mappable_location character varying(128) NOT NULL,
    lat numeric(10,7),
    lon numeric(10,7),
    site_id integer NOT NULL,
    description text NOT NULL,
    link character varying(512),
    description_en text,
    description_fr text,
    featured_name character varying(512),
    external_id integer
);


ALTER TABLE mezzanine_agenda_eventlocation OWNER TO postgres;

--
-- Name: mezzanine_agenda_eventlocation_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mezzanine_agenda_eventlocation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mezzanine_agenda_eventlocation_id_seq OWNER TO postgres;

--
-- Name: mezzanine_agenda_eventlocation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE mezzanine_agenda_eventlocation_id_seq OWNED BY mezzanine_agenda_eventlocation.id;


--
-- Name: mezzanine_agenda_eventprice; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mezzanine_agenda_eventprice (
    id integer NOT NULL,
    unit character varying(16),
    value double precision NOT NULL
);


ALTER TABLE mezzanine_agenda_eventprice OWNER TO postgres;

--
-- Name: mezzanine_agenda_eventprice_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mezzanine_agenda_eventprice_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mezzanine_agenda_eventprice_id_seq OWNER TO postgres;

--
-- Name: mezzanine_agenda_eventprice_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE mezzanine_agenda_eventprice_id_seq OWNED BY mezzanine_agenda_eventprice.id;


--
-- Name: organization core_basicpage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization core_basicpage" (
    page_ptr_id integer NOT NULL,
    content text NOT NULL,
    sub_title text NOT NULL,
    sub_title_fr text,
    sub_title_en text
);


ALTER TABLE "organization core_basicpage" OWNER TO postgres;

--
-- Name: organization festival app_artist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization festival app_artist" (
    id integer NOT NULL,
    keywords_string character varying(500) NOT NULL,
    title character varying(500) NOT NULL,
    title_fr character varying(500),
    title_en character varying(500),
    slug character varying(2000),
    _meta_title character varying(500),
    description text NOT NULL,
    description_fr text,
    description_en text,
    gen_description boolean NOT NULL,
    created timestamp with time zone,
    updated timestamp with time zone,
    status integer NOT NULL,
    publish_date timestamp with time zone,
    expiry_date timestamp with time zone,
    short_url character varying(200),
    in_sitemap boolean NOT NULL,
    content text NOT NULL,
    content_fr text,
    content_en text,
    photo character varying(1024) NOT NULL,
    photo_credits character varying(255),
    photo_alignment character varying(32) NOT NULL,
    photo_description text NOT NULL,
    photo_card character varying(1024) NOT NULL,
    photo_card_credits character varying(255),
    photo_slider character varying(1024) NOT NULL,
    photo_slider_credits character varying(255),
    first_name character varying(255),
    last_name character varying(255),
    bio text NOT NULL,
    bio_fr text,
    bio_en text,
    site_id integer NOT NULL
);


ALTER TABLE "organization festival app_artist" OWNER TO postgres;

--
-- Name: organization festival app_artist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "organization festival app_artist_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "organization festival app_artist_id_seq" OWNER TO postgres;

--
-- Name: organization festival app_artist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "organization festival app_artist_id_seq" OWNED BY "organization festival app_artist".id;


--
-- Name: organization magazine_article; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization magazine_article" (
    blogpost_ptr_id integer NOT NULL,
    sub_title character varying(1000) NOT NULL,
    sub_title_fr character varying(1000),
    sub_title_en character varying(1000)
);


ALTER TABLE "organization magazine_article" OWNER TO postgres;

--
-- Name: organization magazine_category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization magazine_category" (
    id integer NOT NULL,
    name character varying(512) NOT NULL,
    description text NOT NULL
);


ALTER TABLE "organization magazine_category" OWNER TO postgres;

--
-- Name: organization magazine_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "organization magazine_category_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "organization magazine_category_id_seq" OWNER TO postgres;

--
-- Name: organization magazine_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "organization magazine_category_id_seq" OWNED BY "organization magazine_category".id;


--
-- Name: organization magazine_topic; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization magazine_topic" (
    id integer NOT NULL,
    name character varying(512) NOT NULL,
    description text NOT NULL
);


ALTER TABLE "organization magazine_topic" OWNER TO postgres;

--
-- Name: organization magazine_topic_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "organization magazine_topic_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "organization magazine_topic_id_seq" OWNER TO postgres;

--
-- Name: organization magazine_topic_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "organization magazine_topic_id_seq" OWNED BY "organization magazine_topic".id;


--
-- Name: organization media_audio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization media_audio" (
    id integer NOT NULL,
    keywords_string character varying(500) NOT NULL,
    title character varying(500) NOT NULL,
    title_fr character varying(500),
    title_en character varying(500),
    slug character varying(2000),
    _meta_title character varying(500),
    description text NOT NULL,
    description_fr text,
    description_en text,
    gen_description boolean NOT NULL,
    created timestamp with time zone,
    updated timestamp with time zone,
    status integer NOT NULL,
    publish_date timestamp with time zone,
    expiry_date timestamp with time zone,
    short_url character varying(200),
    in_sitemap boolean NOT NULL,
    content text NOT NULL,
    content_fr text,
    content_en text,
    media_id character varying(128) NOT NULL,
    open_source_url character varying(1024) NOT NULL,
    closed_source_url character varying(1024) NOT NULL,
    poster_url character varying(1024) NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE "organization media_audio" OWNER TO postgres;

--
-- Name: organization media_audio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "organization media_audio_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "organization media_audio_id_seq" OWNER TO postgres;

--
-- Name: organization media_audio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "organization media_audio_id_seq" OWNED BY "organization media_audio".id;


--
-- Name: organization media_playlist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization media_playlist" (
    id integer NOT NULL,
    title character varying(512) NOT NULL,
    description text NOT NULL
);


ALTER TABLE "organization media_playlist" OWNER TO postgres;

--
-- Name: organization media_playlist_audios; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization media_playlist_audios" (
    id integer NOT NULL,
    playlist_id integer NOT NULL,
    audio_id integer NOT NULL
);


ALTER TABLE "organization media_playlist_audios" OWNER TO postgres;

--
-- Name: organization media_playlist_audios_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "organization media_playlist_audios_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "organization media_playlist_audios_id_seq" OWNER TO postgres;

--
-- Name: organization media_playlist_audios_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "organization media_playlist_audios_id_seq" OWNED BY "organization media_playlist_audios".id;


--
-- Name: organization media_playlist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "organization media_playlist_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "organization media_playlist_id_seq" OWNER TO postgres;

--
-- Name: organization media_playlist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "organization media_playlist_id_seq" OWNED BY "organization media_playlist".id;


--
-- Name: organization media_video; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization media_video" (
    id integer NOT NULL,
    keywords_string character varying(500) NOT NULL,
    title character varying(500) NOT NULL,
    title_fr character varying(500),
    title_en character varying(500),
    slug character varying(2000),
    _meta_title character varying(500),
    description text NOT NULL,
    description_fr text,
    description_en text,
    gen_description boolean NOT NULL,
    created timestamp with time zone,
    updated timestamp with time zone,
    status integer NOT NULL,
    publish_date timestamp with time zone,
    expiry_date timestamp with time zone,
    short_url character varying(200),
    in_sitemap boolean NOT NULL,
    content text NOT NULL,
    content_fr text,
    content_en text,
    media_id character varying(128) NOT NULL,
    open_source_url character varying(1024) NOT NULL,
    closed_source_url character varying(1024) NOT NULL,
    poster_url character varying(1024) NOT NULL,
    category_id integer,
    site_id integer NOT NULL
);


ALTER TABLE "organization media_video" OWNER TO postgres;

--
-- Name: organization media_video_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "organization media_video_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "organization media_video_id_seq" OWNER TO postgres;

--
-- Name: organization media_video_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "organization media_video_id_seq" OWNED BY "organization media_video".id;


--
-- Name: organization media_videocategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization media_videocategory" (
    id integer NOT NULL,
    title character varying(500) NOT NULL,
    slug character varying(2000),
    site_id integer NOT NULL
);


ALTER TABLE "organization media_videocategory" OWNER TO postgres;

--
-- Name: organization media_videocategory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "organization media_videocategory_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "organization media_videocategory_id_seq" OWNER TO postgres;

--
-- Name: organization media_videocategory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "organization media_videocategory_id_seq" OWNED BY "organization media_videocategory".id;


--
-- Name: organization project_project; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization project_project" (
    id integer NOT NULL,
    keywords_string character varying(500) NOT NULL,
    title character varying(500) NOT NULL,
    slug character varying(2000),
    _meta_title character varying(500),
    description text NOT NULL,
    gen_description boolean NOT NULL,
    created timestamp with time zone,
    updated timestamp with time zone,
    status integer NOT NULL,
    publish_date timestamp with time zone,
    expiry_date timestamp with time zone,
    short_url character varying(200),
    in_sitemap boolean NOT NULL,
    content text NOT NULL,
    site_id integer NOT NULL
);


ALTER TABLE "organization project_project" OWNER TO postgres;

--
-- Name: organization project_project_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "organization project_project_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "organization project_project_id_seq" OWNER TO postgres;

--
-- Name: organization project_project_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "organization project_project_id_seq" OWNED BY "organization project_project".id;


--
-- Name: organization project_project_partners; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization project_project_partners" (
    id integer NOT NULL,
    project_id integer NOT NULL,
    organization_id integer NOT NULL
);


ALTER TABLE "organization project_project_partners" OWNER TO postgres;

--
-- Name: organization project_project_partners_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "organization project_project_partners_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "organization project_project_partners_id_seq" OWNER TO postgres;

--
-- Name: organization project_project_partners_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "organization project_project_partners_id_seq" OWNED BY "organization project_project_partners".id;


--
-- Name: organization project_project_persons; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization project_project_persons" (
    id integer NOT NULL,
    project_id integer NOT NULL,
    person_id integer NOT NULL
);


ALTER TABLE "organization project_project_persons" OWNER TO postgres;

--
-- Name: organization project_project_persons_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "organization project_project_persons_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "organization project_project_persons_id_seq" OWNER TO postgres;

--
-- Name: organization project_project_persons_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "organization project_project_persons_id_seq" OWNED BY "organization project_project_persons".id;


--
-- Name: organization structure_activity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization structure_activity" (
    id integer NOT NULL,
    date_begin date,
    date_end date,
    role character varying(512) NOT NULL,
    work text NOT NULL,
    person_id integer NOT NULL
);


ALTER TABLE "organization structure_activity" OWNER TO postgres;

--
-- Name: organization structure_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "organization structure_activity_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "organization structure_activity_id_seq" OWNER TO postgres;

--
-- Name: organization structure_activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "organization structure_activity_id_seq" OWNED BY "organization structure_activity".id;


--
-- Name: organization structure_activity_teams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization structure_activity_teams" (
    id integer NOT NULL,
    activity_id integer NOT NULL,
    team_id integer NOT NULL
);


ALTER TABLE "organization structure_activity_teams" OWNER TO postgres;

--
-- Name: organization structure_activity_teams_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "organization structure_activity_teams_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "organization structure_activity_teams_id_seq" OWNER TO postgres;

--
-- Name: organization structure_activity_teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "organization structure_activity_teams_id_seq" OWNED BY "organization structure_activity_teams".id;


--
-- Name: organization structure_address; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization structure_address" (
    id integer NOT NULL,
    address text NOT NULL,
    postal_code character varying(16) NOT NULL,
    country character varying(2) NOT NULL
);


ALTER TABLE "organization structure_address" OWNER TO postgres;

--
-- Name: organization structure_address_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "organization structure_address_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "organization structure_address_id_seq" OWNER TO postgres;

--
-- Name: organization structure_address_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "organization structure_address_id_seq" OWNED BY "organization structure_address".id;


--
-- Name: organization structure_department; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization structure_department" (
    id integer NOT NULL,
    name character varying(512) NOT NULL,
    description text NOT NULL,
    url character varying(512) NOT NULL,
    weaving_class character varying(64) NOT NULL,
    organization_id integer NOT NULL
);


ALTER TABLE "organization structure_department" OWNER TO postgres;

--
-- Name: organization structure_department_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "organization structure_department_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "organization structure_department_id_seq" OWNER TO postgres;

--
-- Name: organization structure_department_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "organization structure_department_id_seq" OWNED BY "organization structure_department".id;


--
-- Name: organization structure_link; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization structure_link" (
    id integer NOT NULL,
    url character varying(200) NOT NULL,
    link_type_id integer NOT NULL,
    person_id integer NOT NULL
);


ALTER TABLE "organization structure_link" OWNER TO postgres;

--
-- Name: organization structure_link_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "organization structure_link_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "organization structure_link_id_seq" OWNER TO postgres;

--
-- Name: organization structure_link_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "organization structure_link_id_seq" OWNED BY "organization structure_link".id;


--
-- Name: organization structure_linktype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization structure_linktype" (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    slug character varying(256) NOT NULL,
    ordering integer,
    CONSTRAINT "organization structure_linktype_ordering_check" CHECK ((ordering >= 0))
);


ALTER TABLE "organization structure_linktype" OWNER TO postgres;

--
-- Name: organization structure_linktype_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "organization structure_linktype_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "organization structure_linktype_id_seq" OWNER TO postgres;

--
-- Name: organization structure_linktype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "organization structure_linktype_id_seq" OWNED BY "organization structure_linktype".id;


--
-- Name: organization structure_nationality; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization structure_nationality" (
    id integer NOT NULL,
    name character varying(128) NOT NULL
);


ALTER TABLE "organization structure_nationality" OWNER TO postgres;

--
-- Name: organization structure_nationality_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "organization structure_nationality_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "organization structure_nationality_id_seq" OWNER TO postgres;

--
-- Name: organization structure_nationality_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "organization structure_nationality_id_seq" OWNED BY "organization structure_nationality".id;


--
-- Name: organization structure_organization; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization structure_organization" (
    address_ptr_id integer NOT NULL,
    name character varying(512) NOT NULL,
    description text NOT NULL,
    url character varying(512) NOT NULL,
    type_id integer
);


ALTER TABLE "organization structure_organization" OWNER TO postgres;

--
-- Name: organization structure_organizationtype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization structure_organizationtype" (
    id integer NOT NULL,
    name character varying(512) NOT NULL,
    description text NOT NULL
);


ALTER TABLE "organization structure_organizationtype" OWNER TO postgres;

--
-- Name: organization structure_organizationtype_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "organization structure_organizationtype_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "organization structure_organizationtype_id_seq" OWNER TO postgres;

--
-- Name: organization structure_organizationtype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "organization structure_organizationtype_id_seq" OWNED BY "organization structure_organizationtype".id;


--
-- Name: organization structure_person; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization structure_person" (
    id integer NOT NULL,
    keywords_string character varying(500) NOT NULL,
    title character varying(500) NOT NULL,
    slug character varying(2000),
    _meta_title character varying(500),
    description text NOT NULL,
    gen_description boolean NOT NULL,
    created timestamp with time zone,
    updated timestamp with time zone,
    status integer NOT NULL,
    publish_date timestamp with time zone,
    expiry_date timestamp with time zone,
    short_url character varying(200),
    in_sitemap boolean NOT NULL,
    content text NOT NULL,
    photo character varying(1024) NOT NULL,
    photo_credits character varying(255),
    photo_alignment character varying(32) NOT NULL,
    photo_description text NOT NULL,
    photo_card character varying(1024) NOT NULL,
    photo_card_credits character varying(255),
    photo_slider character varying(1024) NOT NULL,
    photo_slider_credits character varying(255),
    person_title character varying(16) NOT NULL,
    gender character varying(16) NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    birthday date NOT NULL,
    site_id integer NOT NULL,
    user_id integer,
    organization_id integer,
    bio text NOT NULL
);


ALTER TABLE "organization structure_person" OWNER TO postgres;

--
-- Name: organization structure_person_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "organization structure_person_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "organization structure_person_id_seq" OWNER TO postgres;

--
-- Name: organization structure_person_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "organization structure_person_id_seq" OWNED BY "organization structure_person".id;


--
-- Name: organization structure_team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE "organization structure_team" (
    id integer NOT NULL,
    name character varying(512) NOT NULL,
    description text NOT NULL,
    department_id integer
);


ALTER TABLE "organization structure_team" OWNER TO postgres;

--
-- Name: organization structure_team_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE "organization structure_team_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE "organization structure_team_id_seq" OWNER TO postgres;

--
-- Name: organization structure_team_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE "organization structure_team_id_seq" OWNED BY "organization structure_team".id;


--
-- Name: organization_activity; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE organization_activity (
    id integer NOT NULL,
    date_begin date,
    date_end date,
    role character varying(512) NOT NULL,
    work text NOT NULL,
    person_id integer NOT NULL
);


ALTER TABLE organization_activity OWNER TO postgres;

--
-- Name: organization_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE organization_activity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE organization_activity_id_seq OWNER TO postgres;

--
-- Name: organization_activity_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE organization_activity_id_seq OWNED BY organization_activity.id;


--
-- Name: organization_activity_teams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE organization_activity_teams (
    id integer NOT NULL,
    activity_id integer NOT NULL,
    team_id integer NOT NULL
);


ALTER TABLE organization_activity_teams OWNER TO postgres;

--
-- Name: organization_activity_teams_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE organization_activity_teams_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE organization_activity_teams_id_seq OWNER TO postgres;

--
-- Name: organization_activity_teams_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE organization_activity_teams_id_seq OWNED BY organization_activity_teams.id;


--
-- Name: organization_department; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE organization_department (
    id integer NOT NULL,
    name character varying(512) NOT NULL,
    description text NOT NULL,
    domain character varying(255) NOT NULL,
    weaving_class character varying(64) NOT NULL,
    organization_id integer NOT NULL
);


ALTER TABLE organization_department OWNER TO postgres;

--
-- Name: organization_department_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE organization_department_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE organization_department_id_seq OWNER TO postgres;

--
-- Name: organization_department_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE organization_department_id_seq OWNED BY organization_department.id;


--
-- Name: organization_link; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE organization_link (
    id integer NOT NULL,
    url character varying(200) NOT NULL,
    link_type_id integer NOT NULL,
    person_id integer NOT NULL
);


ALTER TABLE organization_link OWNER TO postgres;

--
-- Name: organization_link_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE organization_link_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE organization_link_id_seq OWNER TO postgres;

--
-- Name: organization_link_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE organization_link_id_seq OWNED BY organization_link.id;


--
-- Name: organization_linktype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE organization_linktype (
    id integer NOT NULL,
    name character varying(256) NOT NULL,
    slug character varying(256) NOT NULL,
    ordering integer,
    CONSTRAINT organization_linktype_ordering_check CHECK ((ordering >= 0))
);


ALTER TABLE organization_linktype OWNER TO postgres;

--
-- Name: organization_linktype_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE organization_linktype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE organization_linktype_id_seq OWNER TO postgres;

--
-- Name: organization_linktype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE organization_linktype_id_seq OWNED BY organization_linktype.id;


--
-- Name: organization_organization; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE organization_organization (
    id integer NOT NULL,
    name character varying(512) NOT NULL,
    description text NOT NULL,
    address text NOT NULL,
    postalcode character varying(16) NOT NULL,
    country character varying(255) NOT NULL,
    url character varying(512) NOT NULL,
    organization_type_id integer
);


ALTER TABLE organization_organization OWNER TO postgres;

--
-- Name: organization_organization_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE organization_organization_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE organization_organization_id_seq OWNER TO postgres;

--
-- Name: organization_organization_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE organization_organization_id_seq OWNED BY organization_organization.id;


--
-- Name: organization_organizationtype; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE organization_organizationtype (
    id integer NOT NULL,
    type character varying(255) NOT NULL
);


ALTER TABLE organization_organizationtype OWNER TO postgres;

--
-- Name: organization_organizationtype_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE organization_organizationtype_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE organization_organizationtype_id_seq OWNER TO postgres;

--
-- Name: organization_organizationtype_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE organization_organizationtype_id_seq OWNED BY organization_organizationtype.id;


--
-- Name: organization_person; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE organization_person (
    id integer NOT NULL,
    keywords_string character varying(500) NOT NULL,
    title character varying(500) NOT NULL,
    slug character varying(2000),
    _meta_title character varying(500),
    description text NOT NULL,
    gen_description boolean NOT NULL,
    created timestamp with time zone,
    updated timestamp with time zone,
    status integer NOT NULL,
    publish_date timestamp with time zone,
    expiry_date timestamp with time zone,
    short_url character varying(200),
    in_sitemap boolean NOT NULL,
    content text NOT NULL,
    person_title character varying(16) NOT NULL,
    first_name character varying(255),
    last_name character varying(255),
    bio text NOT NULL,
    photo character varying(1024) NOT NULL,
    photo_credits character varying(255),
    photo_alignment character varying(32) NOT NULL,
    photo_description text NOT NULL,
    photo_featured character varying(1024) NOT NULL,
    photo_featured_credits character varying(255),
    organization_id integer,
    site_id integer NOT NULL,
    user_id integer
);


ALTER TABLE organization_person OWNER TO postgres;

--
-- Name: organization_person_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE organization_person_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE organization_person_id_seq OWNER TO postgres;

--
-- Name: organization_person_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE organization_person_id_seq OWNED BY organization_person.id;


--
-- Name: organization_team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE organization_team (
    id integer NOT NULL,
    name character varying(512) NOT NULL,
    description text NOT NULL,
    department_id integer
);


ALTER TABLE organization_team OWNER TO postgres;

--
-- Name: organization_team_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE organization_team_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE organization_team_id_seq OWNER TO postgres;

--
-- Name: organization_team_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE organization_team_id_seq OWNED BY organization_team.id;


--
-- Name: pages_link; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pages_link (
    page_ptr_id integer NOT NULL
);


ALTER TABLE pages_link OWNER TO postgres;

--
-- Name: pages_page; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pages_page (
    id integer NOT NULL,
    keywords_string character varying(500) NOT NULL,
    title character varying(500) NOT NULL,
    slug character varying(2000),
    _meta_title character varying(500),
    description text NOT NULL,
    gen_description boolean NOT NULL,
    created timestamp with time zone,
    updated timestamp with time zone,
    status integer NOT NULL,
    publish_date timestamp with time zone,
    expiry_date timestamp with time zone,
    short_url character varying(200),
    in_sitemap boolean NOT NULL,
    _order integer,
    in_menus character varying(100),
    titles character varying(1000),
    content_model character varying(50),
    login_required boolean NOT NULL,
    parent_id integer,
    site_id integer NOT NULL,
    _meta_title_en character varying(500),
    _meta_title_fr character varying(500),
    description_en text,
    description_fr text,
    title_en character varying(500),
    title_fr character varying(500),
    titles_en character varying(1000),
    titles_fr character varying(1000)
);


ALTER TABLE pages_page OWNER TO postgres;

--
-- Name: pages_page_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE pages_page_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE pages_page_id_seq OWNER TO postgres;

--
-- Name: pages_page_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE pages_page_id_seq OWNED BY pages_page.id;


--
-- Name: pages_richtextpage; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE pages_richtextpage (
    page_ptr_id integer NOT NULL,
    content text NOT NULL,
    content_en text,
    content_fr text
);


ALTER TABLE pages_richtextpage OWNER TO postgres;

--
-- Name: twitter_query; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE twitter_query (
    id integer NOT NULL,
    type character varying(10) NOT NULL,
    value character varying(140) NOT NULL,
    interested boolean NOT NULL
);


ALTER TABLE twitter_query OWNER TO postgres;

--
-- Name: twitter_query_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE twitter_query_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE twitter_query_id_seq OWNER TO postgres;

--
-- Name: twitter_query_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE twitter_query_id_seq OWNED BY twitter_query.id;


--
-- Name: twitter_tweet; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE twitter_tweet (
    id integer NOT NULL,
    remote_id character varying(50) NOT NULL,
    created_at timestamp with time zone,
    text text,
    profile_image_url character varying(200),
    user_name character varying(100),
    full_name character varying(100),
    retweeter_profile_image_url character varying(200),
    retweeter_user_name character varying(100),
    retweeter_full_name character varying(100),
    query_id integer NOT NULL
);


ALTER TABLE twitter_tweet OWNER TO postgres;

--
-- Name: twitter_tweet_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE twitter_tweet_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE twitter_tweet_id_seq OWNER TO postgres;

--
-- Name: twitter_tweet_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE twitter_tweet_id_seq OWNED BY twitter_tweet.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY blog_blogcategory ALTER COLUMN id SET DEFAULT nextval('blog_blogcategory_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY blog_blogpost ALTER COLUMN id SET DEFAULT nextval('blog_blogpost_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY blog_blogpost_categories ALTER COLUMN id SET DEFAULT nextval('blog_blogpost_categories_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY blog_blogpost_related_posts ALTER COLUMN id SET DEFAULT nextval('blog_blogpost_related_posts_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY conf_setting ALTER COLUMN id SET DEFAULT nextval('conf_setting_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY core_sitepermission ALTER COLUMN id SET DEFAULT nextval('core_sitepermission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY core_sitepermission_sites ALTER COLUMN id SET DEFAULT nextval('core_sitepermission_sites_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_comment_flags ALTER COLUMN id SET DEFAULT nextval('django_comment_flags_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_comments ALTER COLUMN id SET DEFAULT nextval('django_comments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_migrations ALTER COLUMN id SET DEFAULT nextval('django_migrations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_redirect ALTER COLUMN id SET DEFAULT nextval('django_redirect_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_site ALTER COLUMN id SET DEFAULT nextval('django_site_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured ALTER COLUMN id SET DEFAULT nextval('featured_featured_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_articles ALTER COLUMN id SET DEFAULT nextval('featured_featured_articles_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_events ALTER COLUMN id SET DEFAULT nextval('featured_featured_events_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_pages ALTER COLUMN id SET DEFAULT nextval('featured_featured_pages_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_playlists ALTER COLUMN id SET DEFAULT nextval('featured_featured_playlists_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_videos ALTER COLUMN id SET DEFAULT nextval('featured_featured_videos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_artists ALTER COLUMN id SET DEFAULT nextval('festival_artists_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_artists_events ALTER COLUMN id SET DEFAULT nextval('festival_artists_events_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_audios ALTER COLUMN id SET DEFAULT nextval('festival_audios_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_audios_artists ALTER COLUMN id SET DEFAULT nextval('festival_audios_artists_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured ALTER COLUMN id SET DEFAULT nextval('festival_featured_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_artists ALTER COLUMN id SET DEFAULT nextval('festival_featured_artists_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_blogposts ALTER COLUMN id SET DEFAULT nextval('festival_featured_blogpost_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_events ALTER COLUMN id SET DEFAULT nextval('festival_featured_events_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_pages ALTER COLUMN id SET DEFAULT nextval('festival_featured_page_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_playlists ALTER COLUMN id SET DEFAULT nextval('festival_featured_playlists_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_videos ALTER COLUMN id SET DEFAULT nextval('festival_featured_videos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_playlist ALTER COLUMN id SET DEFAULT nextval('festival_playlist_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_playlist_audios ALTER COLUMN id SET DEFAULT nextval('festival_playlist_audios_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_video_category ALTER COLUMN id SET DEFAULT nextval('festival_video_category_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_videos ALTER COLUMN id SET DEFAULT nextval('festival_video_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_videos_artists ALTER COLUMN id SET DEFAULT nextval('festival_videos_artists_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY forms_field ALTER COLUMN id SET DEFAULT nextval('forms_field_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY forms_fieldentry ALTER COLUMN id SET DEFAULT nextval('forms_fieldentry_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY forms_formentry ALTER COLUMN id SET DEFAULT nextval('forms_formentry_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY galleries_galleryimage ALTER COLUMN id SET DEFAULT nextval('galleries_galleryimage_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY generic_assignedkeyword ALTER COLUMN id SET DEFAULT nextval('generic_assignedkeyword_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY generic_keyword ALTER COLUMN id SET DEFAULT nextval('generic_keyword_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY generic_rating ALTER COLUMN id SET DEFAULT nextval('generic_rating_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_event ALTER COLUMN id SET DEFAULT nextval('mezzanine_agenda_event_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_event_blog_posts ALTER COLUMN id SET DEFAULT nextval('mezzanine_agenda_event_blog_posts_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_event_prices ALTER COLUMN id SET DEFAULT nextval('mezzanine_agenda_event_prices_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_eventcategory ALTER COLUMN id SET DEFAULT nextval('mezzanine_agenda_eventcategory_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_eventlocation ALTER COLUMN id SET DEFAULT nextval('mezzanine_agenda_eventlocation_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_eventprice ALTER COLUMN id SET DEFAULT nextval('mezzanine_agenda_eventprice_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization festival app_artist" ALTER COLUMN id SET DEFAULT nextval('"organization festival app_artist_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization magazine_category" ALTER COLUMN id SET DEFAULT nextval('"organization magazine_category_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization magazine_topic" ALTER COLUMN id SET DEFAULT nextval('"organization magazine_topic_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization media_audio" ALTER COLUMN id SET DEFAULT nextval('"organization media_audio_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization media_playlist" ALTER COLUMN id SET DEFAULT nextval('"organization media_playlist_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization media_playlist_audios" ALTER COLUMN id SET DEFAULT nextval('"organization media_playlist_audios_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization media_video" ALTER COLUMN id SET DEFAULT nextval('"organization media_video_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization media_videocategory" ALTER COLUMN id SET DEFAULT nextval('"organization media_videocategory_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization project_project" ALTER COLUMN id SET DEFAULT nextval('"organization project_project_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization project_project_partners" ALTER COLUMN id SET DEFAULT nextval('"organization project_project_partners_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization project_project_persons" ALTER COLUMN id SET DEFAULT nextval('"organization project_project_persons_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_activity" ALTER COLUMN id SET DEFAULT nextval('"organization structure_activity_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_activity_teams" ALTER COLUMN id SET DEFAULT nextval('"organization structure_activity_teams_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_address" ALTER COLUMN id SET DEFAULT nextval('"organization structure_address_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_department" ALTER COLUMN id SET DEFAULT nextval('"organization structure_department_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_link" ALTER COLUMN id SET DEFAULT nextval('"organization structure_link_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_linktype" ALTER COLUMN id SET DEFAULT nextval('"organization structure_linktype_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_nationality" ALTER COLUMN id SET DEFAULT nextval('"organization structure_nationality_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_organizationtype" ALTER COLUMN id SET DEFAULT nextval('"organization structure_organizationtype_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_person" ALTER COLUMN id SET DEFAULT nextval('"organization structure_person_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_team" ALTER COLUMN id SET DEFAULT nextval('"organization structure_team_id_seq"'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_activity ALTER COLUMN id SET DEFAULT nextval('organization_activity_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_activity_teams ALTER COLUMN id SET DEFAULT nextval('organization_activity_teams_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_department ALTER COLUMN id SET DEFAULT nextval('organization_department_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_link ALTER COLUMN id SET DEFAULT nextval('organization_link_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_linktype ALTER COLUMN id SET DEFAULT nextval('organization_linktype_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_organization ALTER COLUMN id SET DEFAULT nextval('organization_organization_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_organizationtype ALTER COLUMN id SET DEFAULT nextval('organization_organizationtype_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_person ALTER COLUMN id SET DEFAULT nextval('organization_person_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_team ALTER COLUMN id SET DEFAULT nextval('organization_team_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pages_page ALTER COLUMN id SET DEFAULT nextval('pages_page_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY twitter_query ALTER COLUMN id SET DEFAULT nextval('twitter_query_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY twitter_tweet ALTER COLUMN id SET DEFAULT nextval('twitter_tweet_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_group (id, name) FROM stdin;
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	1	add_permission
2	Can change permission	1	change_permission
3	Can delete permission	1	delete_permission
4	Can add group	2	add_group
5	Can change group	2	change_group
6	Can delete group	2	delete_group
7	Can add user	3	add_user
8	Can change user	3	change_user
9	Can delete user	3	delete_user
10	Can add content type	4	add_contenttype
11	Can change content type	4	change_contenttype
12	Can delete content type	4	delete_contenttype
13	Can add redirect	5	add_redirect
14	Can change redirect	5	change_redirect
15	Can delete redirect	5	delete_redirect
16	Can add session	6	add_session
17	Can change session	6	change_session
18	Can delete session	6	delete_session
19	Can add site	7	add_site
20	Can change site	7	change_site
21	Can delete site	7	delete_site
22	Can add Setting	8	add_setting
23	Can change Setting	8	change_setting
24	Can delete Setting	8	delete_setting
25	Can add Site permission	9	add_sitepermission
26	Can change Site permission	9	change_sitepermission
27	Can delete Site permission	9	delete_sitepermission
28	Can add Comment	10	add_threadedcomment
29	Can change Comment	10	change_threadedcomment
30	Can delete Comment	10	delete_threadedcomment
31	Can add Keyword	11	add_keyword
32	Can change Keyword	11	change_keyword
33	Can delete Keyword	11	delete_keyword
34	Can add assigned keyword	12	add_assignedkeyword
35	Can change assigned keyword	12	change_assignedkeyword
36	Can delete assigned keyword	12	delete_assignedkeyword
37	Can add Rating	13	add_rating
38	Can change Rating	13	change_rating
39	Can delete Rating	13	delete_rating
40	Can add Page	14	add_page
41	Can change Page	14	change_page
42	Can delete Page	14	delete_page
43	Can add Rich text page	15	add_richtextpage
44	Can change Rich text page	15	change_richtextpage
45	Can delete Rich text page	15	delete_richtextpage
46	Can add Link	16	add_link
47	Can change Link	16	change_link
48	Can delete Link	16	delete_link
49	Can add basic page	17	add_basicpage
50	Can change basic page	17	change_basicpage
51	Can delete basic page	17	delete_basicpage
52	Can add Blog post	18	add_blogpost
53	Can change Blog post	18	change_blogpost
54	Can delete Blog post	18	delete_blogpost
55	Can add Blog Category	19	add_blogcategory
56	Can change Blog Category	19	change_blogcategory
57	Can delete Blog Category	19	delete_blogcategory
58	Can add Form	20	add_form
59	Can change Form	20	change_form
60	Can delete Form	20	delete_form
61	Can add Field	21	add_field
62	Can change Field	21	change_field
63	Can delete Field	21	delete_field
64	Can add Form entry	22	add_formentry
65	Can change Form entry	22	change_formentry
66	Can delete Form entry	22	delete_formentry
67	Can add Form field entry	23	add_fieldentry
68	Can change Form field entry	23	change_fieldentry
69	Can delete Form field entry	23	delete_fieldentry
70	Can add Gallery	24	add_gallery
71	Can change Gallery	24	change_gallery
72	Can delete Gallery	24	delete_gallery
73	Can add Image	25	add_galleryimage
74	Can change Image	25	change_galleryimage
75	Can delete Image	25	delete_galleryimage
76	Can add Twitter query	26	add_query
77	Can change Twitter query	26	change_query
78	Can delete Twitter query	26	delete_query
79	Can add Tweet	27	add_tweet
80	Can change Tweet	27	change_tweet
81	Can delete Tweet	27	delete_tweet
82	Can add Event	28	add_event
83	Can change Event	28	change_event
84	Can delete Event	28	delete_event
85	Can add Event Location	29	add_eventlocation
86	Can change Event Location	29	change_eventlocation
87	Can delete Event Location	29	delete_eventlocation
88	Can add Event category	30	add_eventcategory
89	Can change Event category	30	change_eventcategory
90	Can delete Event category	30	delete_eventcategory
91	Can add Event price	31	add_eventprice
92	Can change Event price	31	change_eventprice
93	Can delete Event price	31	delete_eventprice
94	Can add artist	32	add_artist
95	Can change artist	32	change_artist
96	Can delete artist	32	delete_artist
97	Can add audio	33	add_audio
98	Can change audio	33	change_audio
99	Can delete audio	33	delete_audio
100	Can add video	34	add_video
101	Can change video	34	change_video
102	Can delete video	34	delete_video
103	Can add playlist	35	add_playlist
104	Can change playlist	35	change_playlist
105	Can delete playlist	35	delete_playlist
106	Can add featured	36	add_featured
107	Can change featured	36	change_featured
108	Can delete featured	36	delete_featured
109	Can add video category	37	add_videocategory
110	Can change video category	37	change_videocategory
111	Can delete video category	37	delete_videocategory
112	Can add organization	38	add_organization
113	Can change organization	38	change_organization
114	Can delete organization	38	delete_organization
115	Can add organization type	39	add_organizationtype
116	Can change organization type	39	change_organizationtype
117	Can delete organization type	39	delete_organizationtype
118	Can add department	40	add_department
119	Can change department	40	change_department
120	Can delete department	40	delete_department
121	Can add team	41	add_team
122	Can change team	41	change_team
123	Can delete team	41	delete_team
124	Can add person	42	add_person
125	Can change person	42	change_person
126	Can delete person	42	delete_person
127	Can add link	43	add_link
128	Can change link	43	change_link
129	Can delete link	43	delete_link
130	Can add link type	44	add_linktype
131	Can change link type	44	change_linktype
132	Can delete link type	44	delete_linktype
133	Can add activity	45	add_activity
134	Can change activity	45	change_activity
135	Can delete activity	45	delete_activity
136	Can add log entry	46	add_logentry
137	Can change log entry	46	change_logentry
138	Can delete log entry	46	delete_logentry
139	Can add comment	47	add_comment
140	Can change comment	47	change_comment
141	Can delete comment	47	delete_comment
142	Can moderate comments	47	can_moderate
143	Can add comment flag	48	add_commentflag
144	Can change comment flag	48	change_commentflag
145	Can delete comment flag	48	delete_commentflag
146	Can add basic page	49	add_basicpage
147	Can change basic page	49	change_basicpage
148	Can delete basic page	49	delete_basicpage
149	Can add address	50	add_address
150	Can change address	50	change_address
151	Can delete address	50	delete_address
152	Can add organization	51	add_organization
153	Can change organization	51	change_organization
154	Can delete organization	51	delete_organization
155	Can add organization type	52	add_organizationtype
156	Can change organization type	52	change_organizationtype
157	Can delete organization type	52	delete_organizationtype
158	Can add department	53	add_department
159	Can change department	53	change_department
160	Can delete department	53	delete_department
161	Can add team	54	add_team
162	Can change team	54	change_team
163	Can delete team	54	delete_team
164	Can add person	55	add_person
165	Can change person	55	change_person
166	Can delete person	55	delete_person
167	Can add nationality	56	add_nationality
168	Can change nationality	56	change_nationality
169	Can delete nationality	56	delete_nationality
170	Can add link	57	add_link
171	Can change link	57	change_link
172	Can delete link	57	delete_link
173	Can add link type	58	add_linktype
174	Can change link type	58	change_linktype
175	Can delete link type	58	delete_linktype
176	Can add activity	59	add_activity
177	Can change activity	59	change_activity
178	Can delete activity	59	delete_activity
179	Can add artist	60	add_artist
180	Can change artist	60	change_artist
181	Can delete artist	60	delete_artist
182	Can add article	61	add_article
183	Can change article	61	change_article
184	Can delete article	61	delete_article
185	Can add category	62	add_category
186	Can change category	62	change_category
187	Can delete category	62	delete_category
188	Can add topic	63	add_topic
189	Can change topic	63	change_topic
190	Can delete topic	63	delete_topic
191	Can add audio	64	add_audio
192	Can change audio	64	change_audio
193	Can delete audio	64	delete_audio
194	Can add video	65	add_video
195	Can change video	65	change_video
196	Can delete video	65	delete_video
197	Can add video category	66	add_videocategory
198	Can change video category	66	change_videocategory
199	Can delete video category	66	delete_videocategory
200	Can add playlist	67	add_playlist
201	Can change playlist	67	change_playlist
202	Can delete playlist	67	delete_playlist
203	Can add project	68	add_project
204	Can change project	68	change_project
205	Can delete project	68	delete_project
206	Can add featured	69	add_featured
207	Can change featured	69	change_featured
208	Can delete featured	69	delete_featured
\.


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_permission_id_seq', 208, true);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1	pbkdf2_sha256$24000$RXjru6frNL5G$20UhA9EqppTNbBl7vWFKWuowUjBiKG4ZH8yn0WjweQU=	2016-07-07 14:32:17.448201+00	t	admin			root@example.com	t	t	2016-07-06 11:17:52.156136+00
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_id_seq', 1, true);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: blog_blogcategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY blog_blogcategory (id, title, slug, site_id, title_en, title_fr) FROM stdin;
\.


--
-- Name: blog_blogcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('blog_blogcategory_id_seq', 1, false);


--
-- Data for Name: blog_blogpost; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY blog_blogpost (id, comments_count, keywords_string, rating_count, rating_sum, rating_average, title, slug, _meta_title, description, gen_description, created, updated, status, publish_date, expiry_date, short_url, in_sitemap, content, allow_comments, featured_image, site_id, user_id, _meta_title_en, _meta_title_fr, content_en, content_fr, description_en, description_fr, title_en, title_fr) FROM stdin;
\.


--
-- Data for Name: blog_blogpost_categories; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY blog_blogpost_categories (id, blogpost_id, blogcategory_id) FROM stdin;
\.


--
-- Name: blog_blogpost_categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('blog_blogpost_categories_id_seq', 1, false);


--
-- Name: blog_blogpost_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('blog_blogpost_id_seq', 1, false);


--
-- Data for Name: blog_blogpost_related_posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY blog_blogpost_related_posts (id, from_blogpost_id, to_blogpost_id) FROM stdin;
\.


--
-- Name: blog_blogpost_related_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('blog_blogpost_related_posts_id_seq', 1, false);


--
-- Data for Name: conf_setting; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY conf_setting (id, name, value, site_id, value_en, value_fr) FROM stdin;
\.


--
-- Name: conf_setting_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('conf_setting_id_seq', 1, false);


--
-- Data for Name: core_sitepermission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY core_sitepermission (id, user_id) FROM stdin;
\.


--
-- Name: core_sitepermission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('core_sitepermission_id_seq', 1, false);


--
-- Data for Name: core_sitepermission_sites; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY core_sitepermission_sites (id, sitepermission_id, site_id) FROM stdin;
\.


--
-- Name: core_sitepermission_sites_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('core_sitepermission_sites_id_seq', 1, false);


--
-- Data for Name: custom_basicpage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY custom_basicpage (page_ptr_id, content, sub_title, sub_title_en, sub_title_fr, photo, photo_alignment, photo_credits, photo_description, photo_featured, photo_featured_credits) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 1, false);


--
-- Data for Name: django_comment_flags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_comment_flags (id, flag, flag_date, comment_id, user_id) FROM stdin;
\.


--
-- Name: django_comment_flags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_comment_flags_id_seq', 1, false);


--
-- Data for Name: django_comments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_comments (id, object_pk, user_name, user_email, user_url, comment, submit_date, ip_address, is_public, is_removed, content_type_id, site_id, user_id) FROM stdin;
\.


--
-- Name: django_comments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_comments_id_seq', 1, false);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_content_type (id, app_label, model) FROM stdin;
1	auth	permission
2	auth	group
3	auth	user
4	contenttypes	contenttype
5	redirects	redirect
6	sessions	session
7	sites	site
8	conf	setting
9	core	sitepermission
10	generic	threadedcomment
11	generic	keyword
12	generic	assignedkeyword
13	generic	rating
14	pages	page
15	pages	richtextpage
16	pages	link
17	custom	basicpage
18	blog	blogpost
19	blog	blogcategory
20	forms	form
21	forms	field
22	forms	formentry
23	forms	fieldentry
24	galleries	gallery
25	galleries	galleryimage
26	twitter	query
27	twitter	tweet
28	mezzanine_agenda	event
29	mezzanine_agenda	eventlocation
30	mezzanine_agenda	eventcategory
31	mezzanine_agenda	eventprice
32	festival	artist
33	festival	audio
34	festival	video
35	festival	playlist
36	festival	featured
37	festival	videocategory
38	organization	organization
39	organization	organizationtype
40	organization	department
41	organization	team
42	organization	person
43	organization	link
44	organization	linktype
45	organization	activity
46	admin	logentry
47	django_comments	comment
48	django_comments	commentflag
49	organization core	basicpage
50	organization structure	address
51	organization structure	organization
52	organization structure	organizationtype
53	organization structure	department
54	organization structure	team
55	organization structure	person
56	organization structure	nationality
57	organization structure	link
58	organization structure	linktype
59	organization structure	activity
60	organization festival app	artist
61	organization magazine	article
62	organization magazine	category
63	organization magazine	topic
64	organization media	audio
65	organization media	video
66	organization media	videocategory
67	organization media	playlist
68	organization project	project
69	featured	featured
\.


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_content_type_id_seq', 69, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2016-07-06 11:17:33.576436+00
2	auth	0001_initial	2016-07-06 11:17:33.804326+00
3	admin	0001_initial	2016-07-06 11:17:33.854813+00
4	admin	0002_logentry_remove_auto_add	2016-07-06 11:17:33.882728+00
5	contenttypes	0002_remove_content_type_name	2016-07-06 11:17:33.93224+00
6	auth	0002_alter_permission_name_max_length	2016-07-06 11:17:33.961591+00
7	auth	0003_alter_user_email_max_length	2016-07-06 11:17:33.976732+00
8	auth	0004_alter_user_username_opts	2016-07-06 11:17:33.991679+00
9	auth	0005_alter_user_last_login_null	2016-07-06 11:17:34.014311+00
10	auth	0006_require_contenttypes_0002	2016-07-06 11:17:34.018015+00
11	auth	0007_alter_validators_add_error_messages	2016-07-06 11:17:34.029702+00
12	sites	0001_initial	2016-07-06 11:17:34.063531+00
13	blog	0001_initial	2016-07-06 11:17:34.222491+00
14	blog	0002_auto_20150527_1555	2016-07-06 11:17:34.254595+00
15	blog	0003_auto_20151223_1313	2016-07-06 11:17:34.409439+00
16	conf	0001_initial	2016-07-06 11:17:34.483045+00
17	conf	0002_auto_20151223_1313	2016-07-06 11:17:34.521413+00
18	core	0001_initial	2016-07-06 11:17:34.63433+00
19	core	0002_auto_20150414_2140	2016-07-06 11:17:34.674828+00
20	pages	0001_initial	2016-07-06 11:17:34.793224+00
21	pages	0002_auto_20141227_0224	2016-07-06 11:17:34.840071+00
22	pages	0003_auto_20150527_1555	2016-07-06 11:17:34.869716+00
23	pages	0004_auto_20151223_1313	2016-07-06 11:17:35.089189+00
24	custom	0001_initial	2016-07-06 11:17:35.146476+00
25	custom	0002_auto_20160705_1559	2016-07-06 11:17:35.209803+00
26	custom	0003_auto_20160705_1702	2016-07-06 11:17:35.331519+00
27	custom	0004_auto_20160705_1810	2016-07-06 11:17:35.552071+00
28	django_comments	0001_initial	2016-07-06 11:17:35.722307+00
29	django_comments	0002_update_user_email_field_length	2016-07-06 11:17:35.757311+00
30	django_comments	0003_add_submit_date_index	2016-07-06 11:17:35.846745+00
31	sites	0002_alter_domain_unique	2016-07-06 11:17:35.891795+00
32	mezzanine_agenda	0001_initial	2016-07-06 11:17:36.114437+00
33	mezzanine_agenda	0002_auto_20160224_1142	2016-07-06 11:17:36.179693+00
34	mezzanine_agenda	0003_auto_20160309_1621	2016-07-06 11:17:36.561098+00
35	mezzanine_agenda	0004_auto_20160331_1832	2016-07-06 11:17:36.613663+00
36	mezzanine_agenda	0005_auto_20160404_0043	2016-07-06 11:17:36.684794+00
37	mezzanine_agenda	0006_remove_event_featured	2016-07-06 11:17:36.725732+00
38	festival	0001_initial	2016-07-06 11:17:37.014071+00
39	festival	0002_auto_20160225_1602	2016-07-06 11:17:37.095537+00
40	festival	0003_auto_20160229_1430	2016-07-06 11:17:37.34211+00
41	festival	0004_auto_20160229_1630	2016-07-06 11:17:37.536323+00
42	festival	0005_auto_20160229_1636	2016-07-06 11:17:37.576246+00
43	festival	0006_auto_20160303_1442	2016-07-06 11:17:37.745633+00
44	festival	0007_auto_20160309_1441	2016-07-06 11:17:37.95468+00
45	festival	0008_auto_20160322_0018	2016-07-06 11:17:38.205059+00
46	festival	0009_auto_20160322_0021	2016-07-06 11:17:38.539535+00
47	festival	0010_playlist	2016-07-06 11:17:38.651827+00
48	festival	0011_auto_20160323_1159	2016-07-06 11:17:38.73952+00
49	festival	0012_auto_20160405_2351	2016-07-06 11:17:38.947353+00
50	festival	0013_auto_20160407_1432	2016-07-06 11:17:39.138817+00
51	festival	0014_auto_20160407_1433	2016-07-06 11:17:39.227372+00
52	festival	0015_auto_20160407_2249	2016-07-06 11:17:39.966657+00
53	festival	0016_auto_20160407_2255	2016-07-06 11:17:40.057544+00
54	festival	0017_auto_20160407_2256	2016-07-06 11:17:40.147653+00
55	festival	0018_auto_20160407_2301	2016-07-06 11:17:40.157918+00
56	festival	0019_auto_20160410_2148	2016-07-06 11:17:40.329405+00
57	festival	0020_auto_20160421_1059	2016-07-06 11:17:40.462014+00
58	festival	0021_delete_pagecategory	2016-07-06 11:17:40.477503+00
59	festival	0022_auto_20160517_1457	2016-07-06 11:17:40.68233+00
60	forms	0001_initial	2016-07-06 11:17:40.981729+00
61	forms	0002_auto_20141227_0224	2016-07-06 11:17:41.039537+00
62	forms	0003_emailfield	2016-07-06 11:17:41.100148+00
63	forms	0004_auto_20150517_0510	2016-07-06 11:17:41.165419+00
64	forms	0005_auto_20151223_1313	2016-07-06 11:17:42.355486+00
65	forms	0006_auto_20160407_2249	2016-07-06 11:17:42.724326+00
66	galleries	0001_initial	2016-07-06 11:17:42.88274+00
67	galleries	0002_auto_20141227_0224	2016-07-06 11:17:42.943683+00
68	galleries	0003_auto_20151223_1313	2016-07-06 11:17:43.174778+00
69	generic	0001_initial	2016-07-06 11:17:43.652508+00
70	generic	0002_auto_20141227_0224	2016-07-06 11:17:43.724476+00
71	mezzanine_agenda	0007_auto_20160410_2148	2016-07-06 11:17:44.192642+00
72	mezzanine_agenda	0008_auto_20160410_2149	2016-07-06 11:17:44.332545+00
73	mezzanine_agenda	0009_auto_20160410_2154	2016-07-06 11:17:44.476957+00
74	mezzanine_agenda	0010_eventlocation_external_id	2016-07-06 11:17:44.57031+00
75	mezzanine_agenda	0011_auto_20160410_2330	2016-07-06 11:17:45.063162+00
76	mezzanine_agenda	0012_auto_20160410_2336	2016-07-06 11:17:45.154517+00
77	mezzanine_agenda	0013_auto_20160510_1542	2016-07-06 11:17:45.37437+00
78	mezzanine_agenda	0014_event_brochure	2016-07-06 11:17:45.562702+00
79	organization	0001_initial	2016-07-06 11:17:46.531678+00
80	redirects	0001_initial	2016-07-06 11:17:46.70286+00
81	sessions	0001_initial	2016-07-06 11:17:46.782799+00
82	twitter	0001_initial	2016-07-06 11:17:46.87268+00
83	organization media	0001_initial	2016-07-07 14:31:49.290168+00
84	organization magazine	0001_initial	2016-07-07 14:31:49.352937+00
85	organization magazine	0002_article	2016-07-07 14:31:49.404348+00
86	organization core	0001_initial	2016-07-07 14:31:49.898337+00
87	organization core	0002_auto_20160707_1614	2016-07-07 14:31:50.170218+00
88	featured	0001_initial	2016-07-07 14:31:51.733842+00
89	featured	0002_auto_20160707_1614	2016-07-07 14:31:52.009166+00
90	organization festival app	0001_initial	2016-07-07 14:31:54.493064+00
91	organization structure	0001_initial	2016-07-07 14:31:55.54891+00
92	organization project	0001_initial	2016-07-07 14:31:55.639897+00
93	organization project	0002_auto_20160707_1053	2016-07-07 14:31:56.02429+00
94	organization structure	0002_auto_20160707_1614	2016-07-07 14:31:56.29599+00
\.


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_migrations_id_seq', 94, true);


--
-- Data for Name: django_redirect; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_redirect (id, site_id, old_path, new_path) FROM stdin;
\.


--
-- Name: django_redirect_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_redirect_id_seq', 1, false);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
hcogqdq3idoy9f3nl5e0o3jd0eua79jz	NWQ2MTQ2NGMyZmM2MDJmMjUwNjkyMmY3NWUyMDVkOTE1NGU5OWYzMjp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoibWV6emFuaW5lLmNvcmUuYXV0aF9iYWNrZW5kcy5NZXp6YW5pbmVCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMjc0NmNkZGVmNTg3NTRhYjlkZjVjMmEyYjk1ZjcxMGFiMmJiYjc5MCJ9	2016-07-20 11:18:03.473975+00
atk1id0kndjgh4cn908p0ccirk32xzo2	ZTExYWZjOTZjMTIzZjE0OTY4ZjFhMjU3ZDZhZTU1ZmI1MmY5YTdkNTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9oYXNoIjoiMjc0NmNkZGVmNTg3NTRhYjlkZjVjMmEyYjk1ZjcxMGFiMmJiYjc5MCIsIl9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCJ9	2016-07-21 14:32:17.484655+00
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_site (id, domain, name) FROM stdin;
1	example.com	example.com
\.


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_site_id_seq', 1, true);


--
-- Data for Name: featured_featured; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY featured_featured (id, name, description) FROM stdin;
\.


--
-- Data for Name: featured_featured_articles; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY featured_featured_articles (id, featured_id, article_id) FROM stdin;
\.


--
-- Name: featured_featured_articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('featured_featured_articles_id_seq', 1, false);


--
-- Data for Name: featured_featured_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY featured_featured_events (id, featured_id, event_id) FROM stdin;
\.


--
-- Name: featured_featured_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('featured_featured_events_id_seq', 1, false);


--
-- Name: featured_featured_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('featured_featured_id_seq', 1, false);


--
-- Data for Name: featured_featured_pages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY featured_featured_pages (id, featured_id, basicpage_id) FROM stdin;
\.


--
-- Name: featured_featured_pages_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('featured_featured_pages_id_seq', 1, false);


--
-- Data for Name: featured_featured_playlists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY featured_featured_playlists (id, featured_id, playlist_id) FROM stdin;
\.


--
-- Name: featured_featured_playlists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('featured_featured_playlists_id_seq', 1, false);


--
-- Data for Name: featured_featured_videos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY featured_featured_videos (id, featured_id, video_id) FROM stdin;
\.


--
-- Name: featured_featured_videos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('featured_featured_videos_id_seq', 1, false);


--
-- Data for Name: festival_artists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY festival_artists (id, keywords_string, title, title_fr, title_en, slug, _meta_title, description, description_fr, description_en, gen_description, created, updated, status, publish_date, expiry_date, short_url, in_sitemap, content, content_fr, content_en, bio, bio_fr, bio_en, photo, photo_credits, site_id, photo_description, photo_alignment, photo_featured, photo_featured_credits, first_name, last_name) FROM stdin;
\.


--
-- Data for Name: festival_artists_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY festival_artists_events (id, artist_id, event_id) FROM stdin;
\.


--
-- Name: festival_artists_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('festival_artists_events_id_seq', 1, false);


--
-- Name: festival_artists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('festival_artists_id_seq', 1, false);


--
-- Data for Name: festival_audios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY festival_audios (id, keywords_string, title, slug, _meta_title, description, gen_description, created, updated, status, publish_date, expiry_date, short_url, in_sitemap, content, media_id, open_source_url, closed_source_url, event_id, site_id, content_en, content_fr, description_en, description_fr, title_en, title_fr, poster_url) FROM stdin;
\.


--
-- Data for Name: festival_audios_artists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY festival_audios_artists (id, audio_id, artist_id) FROM stdin;
\.


--
-- Name: festival_audios_artists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('festival_audios_artists_id_seq', 1, false);


--
-- Name: festival_audios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('festival_audios_id_seq', 1, false);


--
-- Data for Name: festival_featured; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY festival_featured (id, name, description) FROM stdin;
\.


--
-- Data for Name: festival_featured_artists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY festival_featured_artists (id, featured_id, artist_id) FROM stdin;
\.


--
-- Name: festival_featured_artists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('festival_featured_artists_id_seq', 1, false);


--
-- Name: festival_featured_blogpost_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('festival_featured_blogpost_id_seq', 1, false);


--
-- Data for Name: festival_featured_blogposts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY festival_featured_blogposts (id, featured_id, blogpost_id) FROM stdin;
\.


--
-- Data for Name: festival_featured_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY festival_featured_events (id, featured_id, event_id) FROM stdin;
\.


--
-- Name: festival_featured_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('festival_featured_events_id_seq', 1, false);


--
-- Name: festival_featured_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('festival_featured_id_seq', 1, false);


--
-- Name: festival_featured_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('festival_featured_page_id_seq', 1, false);


--
-- Data for Name: festival_featured_pages; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY festival_featured_pages (id, featured_id, page_id) FROM stdin;
\.


--
-- Data for Name: festival_featured_playlists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY festival_featured_playlists (id, featured_id, playlist_id) FROM stdin;
\.


--
-- Name: festival_featured_playlists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('festival_featured_playlists_id_seq', 1, false);


--
-- Data for Name: festival_featured_videos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY festival_featured_videos (id, featured_id, video_id) FROM stdin;
\.


--
-- Name: festival_featured_videos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('festival_featured_videos_id_seq', 1, false);


--
-- Data for Name: festival_playlist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY festival_playlist (id, title, description, event_id) FROM stdin;
\.


--
-- Data for Name: festival_playlist_audios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY festival_playlist_audios (id, playlist_id, audio_id) FROM stdin;
\.


--
-- Name: festival_playlist_audios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('festival_playlist_audios_id_seq', 1, false);


--
-- Name: festival_playlist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('festival_playlist_id_seq', 1, false);


--
-- Data for Name: festival_video_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY festival_video_category (id, title, slug, site_id) FROM stdin;
\.


--
-- Name: festival_video_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('festival_video_category_id_seq', 1, false);


--
-- Name: festival_video_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('festival_video_id_seq', 1, false);


--
-- Data for Name: festival_videos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY festival_videos (id, keywords_string, title, title_fr, title_en, slug, _meta_title, description, description_fr, description_en, gen_description, created, updated, status, publish_date, expiry_date, short_url, in_sitemap, content, content_fr, content_en, media_id, event_id, site_id, closed_source_url, open_source_url, poster_url, category_id) FROM stdin;
\.


--
-- Data for Name: festival_videos_artists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY festival_videos_artists (id, video_id, artist_id) FROM stdin;
\.


--
-- Name: festival_videos_artists_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('festival_videos_artists_id_seq', 1, false);


--
-- Data for Name: forms_field; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY forms_field (id, _order, label, field_type, required, visible, choices, "default", placeholder_text, help_text, form_id, choices_en, choices_fr, default_en, default_fr, help_text_en, help_text_fr, label_en, label_fr, placeholder_text_en, placeholder_text_fr) FROM stdin;
\.


--
-- Name: forms_field_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('forms_field_id_seq', 1, false);


--
-- Data for Name: forms_fieldentry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY forms_fieldentry (id, field_id, value, entry_id) FROM stdin;
\.


--
-- Name: forms_fieldentry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('forms_fieldentry_id_seq', 1, false);


--
-- Data for Name: forms_form; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY forms_form (page_ptr_id, content, button_text, response, send_email, email_from, email_copies, email_subject, email_message, button_text_en, button_text_fr, content_en, content_fr, email_message_en, email_message_fr, email_subject_en, email_subject_fr, response_en, response_fr) FROM stdin;
\.


--
-- Data for Name: forms_formentry; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY forms_formentry (id, entry_time, form_id) FROM stdin;
\.


--
-- Name: forms_formentry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('forms_formentry_id_seq', 1, false);


--
-- Data for Name: galleries_gallery; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY galleries_gallery (page_ptr_id, content, zip_import, content_en, content_fr) FROM stdin;
\.


--
-- Data for Name: galleries_galleryimage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY galleries_galleryimage (id, _order, file, description, gallery_id, description_en, description_fr) FROM stdin;
\.


--
-- Name: galleries_galleryimage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('galleries_galleryimage_id_seq', 1, false);


--
-- Data for Name: generic_assignedkeyword; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY generic_assignedkeyword (id, _order, object_pk, content_type_id, keyword_id) FROM stdin;
\.


--
-- Name: generic_assignedkeyword_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('generic_assignedkeyword_id_seq', 1, false);


--
-- Data for Name: generic_keyword; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY generic_keyword (id, title, slug, site_id) FROM stdin;
\.


--
-- Name: generic_keyword_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('generic_keyword_id_seq', 1, false);


--
-- Data for Name: generic_rating; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY generic_rating (id, value, rating_date, object_pk, content_type_id, user_id) FROM stdin;
\.


--
-- Name: generic_rating_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('generic_rating_id_seq', 1, false);


--
-- Data for Name: generic_threadedcomment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY generic_threadedcomment (comment_ptr_id, rating_count, rating_sum, rating_average, by_author, replied_to_id) FROM stdin;
\.


--
-- Data for Name: mezzanine_agenda_event; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mezzanine_agenda_event (id, comments_count, keywords_string, rating_count, rating_sum, rating_average, title, title_fr, title_en, slug, _meta_title, description, gen_description, created, updated, status, publish_date, expiry_date, short_url, in_sitemap, content, start, "end", facebook_event, allow_comments, featured_image, location_id, site_id, user_id, content_en, content_fr, external_id, featured_image_description, featured_image_header, parent_id, category_id, description_en, description_fr, brochure) FROM stdin;
\.


--
-- Data for Name: mezzanine_agenda_event_blog_posts; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mezzanine_agenda_event_blog_posts (id, event_id, blogpost_id) FROM stdin;
\.


--
-- Name: mezzanine_agenda_event_blog_posts_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mezzanine_agenda_event_blog_posts_id_seq', 1, false);


--
-- Name: mezzanine_agenda_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mezzanine_agenda_event_id_seq', 1, false);


--
-- Data for Name: mezzanine_agenda_event_prices; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mezzanine_agenda_event_prices (id, event_id, eventprice_id) FROM stdin;
\.


--
-- Name: mezzanine_agenda_event_prices_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mezzanine_agenda_event_prices_id_seq', 1, false);


--
-- Data for Name: mezzanine_agenda_eventcategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mezzanine_agenda_eventcategory (id, name, description) FROM stdin;
\.


--
-- Name: mezzanine_agenda_eventcategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mezzanine_agenda_eventcategory_id_seq', 1, false);


--
-- Data for Name: mezzanine_agenda_eventlocation; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mezzanine_agenda_eventlocation (id, title, slug, address, mappable_location, lat, lon, site_id, description, link, description_en, description_fr, featured_name, external_id) FROM stdin;
\.


--
-- Name: mezzanine_agenda_eventlocation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mezzanine_agenda_eventlocation_id_seq', 1, false);


--
-- Data for Name: mezzanine_agenda_eventprice; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mezzanine_agenda_eventprice (id, unit, value) FROM stdin;
\.


--
-- Name: mezzanine_agenda_eventprice_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mezzanine_agenda_eventprice_id_seq', 1, false);


--
-- Data for Name: organization core_basicpage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization core_basicpage" (page_ptr_id, content, sub_title, sub_title_fr, sub_title_en) FROM stdin;
\.


--
-- Data for Name: organization festival app_artist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization festival app_artist" (id, keywords_string, title, title_fr, title_en, slug, _meta_title, description, description_fr, description_en, gen_description, created, updated, status, publish_date, expiry_date, short_url, in_sitemap, content, content_fr, content_en, photo, photo_credits, photo_alignment, photo_description, photo_card, photo_card_credits, photo_slider, photo_slider_credits, first_name, last_name, bio, bio_fr, bio_en, site_id) FROM stdin;
\.


--
-- Name: organization festival app_artist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"organization festival app_artist_id_seq"', 1, false);


--
-- Data for Name: organization magazine_article; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization magazine_article" (blogpost_ptr_id, sub_title, sub_title_fr, sub_title_en) FROM stdin;
\.


--
-- Data for Name: organization magazine_category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization magazine_category" (id, name, description) FROM stdin;
\.


--
-- Name: organization magazine_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"organization magazine_category_id_seq"', 1, false);


--
-- Data for Name: organization magazine_topic; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization magazine_topic" (id, name, description) FROM stdin;
\.


--
-- Name: organization magazine_topic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"organization magazine_topic_id_seq"', 1, false);


--
-- Data for Name: organization media_audio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization media_audio" (id, keywords_string, title, title_fr, title_en, slug, _meta_title, description, description_fr, description_en, gen_description, created, updated, status, publish_date, expiry_date, short_url, in_sitemap, content, content_fr, content_en, media_id, open_source_url, closed_source_url, poster_url, site_id) FROM stdin;
\.


--
-- Name: organization media_audio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"organization media_audio_id_seq"', 1, false);


--
-- Data for Name: organization media_playlist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization media_playlist" (id, title, description) FROM stdin;
\.


--
-- Data for Name: organization media_playlist_audios; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization media_playlist_audios" (id, playlist_id, audio_id) FROM stdin;
\.


--
-- Name: organization media_playlist_audios_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"organization media_playlist_audios_id_seq"', 1, false);


--
-- Name: organization media_playlist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"organization media_playlist_id_seq"', 1, false);


--
-- Data for Name: organization media_video; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization media_video" (id, keywords_string, title, title_fr, title_en, slug, _meta_title, description, description_fr, description_en, gen_description, created, updated, status, publish_date, expiry_date, short_url, in_sitemap, content, content_fr, content_en, media_id, open_source_url, closed_source_url, poster_url, category_id, site_id) FROM stdin;
\.


--
-- Name: organization media_video_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"organization media_video_id_seq"', 1, false);


--
-- Data for Name: organization media_videocategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization media_videocategory" (id, title, slug, site_id) FROM stdin;
\.


--
-- Name: organization media_videocategory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"organization media_videocategory_id_seq"', 1, false);


--
-- Data for Name: organization project_project; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization project_project" (id, keywords_string, title, slug, _meta_title, description, gen_description, created, updated, status, publish_date, expiry_date, short_url, in_sitemap, content, site_id) FROM stdin;
\.


--
-- Name: organization project_project_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"organization project_project_id_seq"', 1, false);


--
-- Data for Name: organization project_project_partners; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization project_project_partners" (id, project_id, organization_id) FROM stdin;
\.


--
-- Name: organization project_project_partners_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"organization project_project_partners_id_seq"', 1, false);


--
-- Data for Name: organization project_project_persons; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization project_project_persons" (id, project_id, person_id) FROM stdin;
\.


--
-- Name: organization project_project_persons_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"organization project_project_persons_id_seq"', 1, false);


--
-- Data for Name: organization structure_activity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization structure_activity" (id, date_begin, date_end, role, work, person_id) FROM stdin;
\.


--
-- Name: organization structure_activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"organization structure_activity_id_seq"', 1, false);


--
-- Data for Name: organization structure_activity_teams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization structure_activity_teams" (id, activity_id, team_id) FROM stdin;
\.


--
-- Name: organization structure_activity_teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"organization structure_activity_teams_id_seq"', 1, false);


--
-- Data for Name: organization structure_address; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization structure_address" (id, address, postal_code, country) FROM stdin;
\.


--
-- Name: organization structure_address_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"organization structure_address_id_seq"', 1, false);


--
-- Data for Name: organization structure_department; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization structure_department" (id, name, description, url, weaving_class, organization_id) FROM stdin;
\.


--
-- Name: organization structure_department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"organization structure_department_id_seq"', 1, false);


--
-- Data for Name: organization structure_link; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization structure_link" (id, url, link_type_id, person_id) FROM stdin;
\.


--
-- Name: organization structure_link_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"organization structure_link_id_seq"', 1, false);


--
-- Data for Name: organization structure_linktype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization structure_linktype" (id, name, slug, ordering) FROM stdin;
\.


--
-- Name: organization structure_linktype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"organization structure_linktype_id_seq"', 1, false);


--
-- Data for Name: organization structure_nationality; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization structure_nationality" (id, name) FROM stdin;
\.


--
-- Name: organization structure_nationality_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"organization structure_nationality_id_seq"', 1, false);


--
-- Data for Name: organization structure_organization; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization structure_organization" (address_ptr_id, name, description, url, type_id) FROM stdin;
\.


--
-- Data for Name: organization structure_organizationtype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization structure_organizationtype" (id, name, description) FROM stdin;
\.


--
-- Name: organization structure_organizationtype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"organization structure_organizationtype_id_seq"', 1, false);


--
-- Data for Name: organization structure_person; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization structure_person" (id, keywords_string, title, slug, _meta_title, description, gen_description, created, updated, status, publish_date, expiry_date, short_url, in_sitemap, content, photo, photo_credits, photo_alignment, photo_description, photo_card, photo_card_credits, photo_slider, photo_slider_credits, person_title, gender, first_name, last_name, birthday, site_id, user_id, organization_id, bio) FROM stdin;
\.


--
-- Name: organization structure_person_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"organization structure_person_id_seq"', 1, false);


--
-- Data for Name: organization structure_team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "organization structure_team" (id, name, description, department_id) FROM stdin;
\.


--
-- Name: organization structure_team_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"organization structure_team_id_seq"', 1, false);


--
-- Data for Name: organization_activity; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY organization_activity (id, date_begin, date_end, role, work, person_id) FROM stdin;
\.


--
-- Name: organization_activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('organization_activity_id_seq', 1, false);


--
-- Data for Name: organization_activity_teams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY organization_activity_teams (id, activity_id, team_id) FROM stdin;
\.


--
-- Name: organization_activity_teams_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('organization_activity_teams_id_seq', 1, false);


--
-- Data for Name: organization_department; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY organization_department (id, name, description, domain, weaving_class, organization_id) FROM stdin;
\.


--
-- Name: organization_department_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('organization_department_id_seq', 1, false);


--
-- Data for Name: organization_link; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY organization_link (id, url, link_type_id, person_id) FROM stdin;
\.


--
-- Name: organization_link_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('organization_link_id_seq', 1, false);


--
-- Data for Name: organization_linktype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY organization_linktype (id, name, slug, ordering) FROM stdin;
\.


--
-- Name: organization_linktype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('organization_linktype_id_seq', 1, false);


--
-- Data for Name: organization_organization; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY organization_organization (id, name, description, address, postalcode, country, url, organization_type_id) FROM stdin;
\.


--
-- Name: organization_organization_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('organization_organization_id_seq', 1, false);


--
-- Data for Name: organization_organizationtype; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY organization_organizationtype (id, type) FROM stdin;
\.


--
-- Name: organization_organizationtype_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('organization_organizationtype_id_seq', 1, false);


--
-- Data for Name: organization_person; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY organization_person (id, keywords_string, title, slug, _meta_title, description, gen_description, created, updated, status, publish_date, expiry_date, short_url, in_sitemap, content, person_title, first_name, last_name, bio, photo, photo_credits, photo_alignment, photo_description, photo_featured, photo_featured_credits, organization_id, site_id, user_id) FROM stdin;
\.


--
-- Name: organization_person_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('organization_person_id_seq', 1, false);


--
-- Data for Name: organization_team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY organization_team (id, name, description, department_id) FROM stdin;
\.


--
-- Name: organization_team_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('organization_team_id_seq', 1, false);


--
-- Data for Name: pages_link; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pages_link (page_ptr_id) FROM stdin;
\.


--
-- Data for Name: pages_page; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pages_page (id, keywords_string, title, slug, _meta_title, description, gen_description, created, updated, status, publish_date, expiry_date, short_url, in_sitemap, _order, in_menus, titles, content_model, login_required, parent_id, site_id, _meta_title_en, _meta_title_fr, description_en, description_fr, title_en, title_fr, titles_en, titles_fr) FROM stdin;
\.


--
-- Name: pages_page_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('pages_page_id_seq', 1, false);


--
-- Data for Name: pages_richtextpage; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY pages_richtextpage (page_ptr_id, content, content_en, content_fr) FROM stdin;
\.


--
-- Data for Name: twitter_query; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY twitter_query (id, type, value, interested) FROM stdin;
\.


--
-- Name: twitter_query_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('twitter_query_id_seq', 1, false);


--
-- Data for Name: twitter_tweet; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY twitter_tweet (id, remote_id, created_at, text, profile_image_url, user_name, full_name, retweeter_profile_image_url, retweeter_user_name, retweeter_full_name, query_id) FROM stdin;
\.


--
-- Name: twitter_tweet_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('twitter_tweet_id_seq', 1, false);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: blog_blogcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY blog_blogcategory
    ADD CONSTRAINT blog_blogcategory_pkey PRIMARY KEY (id);


--
-- Name: blog_blogpost_categories_blogpost_id_a64d32c5_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY blog_blogpost_categories
    ADD CONSTRAINT blog_blogpost_categories_blogpost_id_a64d32c5_uniq UNIQUE (blogpost_id, blogcategory_id);


--
-- Name: blog_blogpost_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY blog_blogpost_categories
    ADD CONSTRAINT blog_blogpost_categories_pkey PRIMARY KEY (id);


--
-- Name: blog_blogpost_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY blog_blogpost
    ADD CONSTRAINT blog_blogpost_pkey PRIMARY KEY (id);


--
-- Name: blog_blogpost_related_posts_from_blogpost_id_3bd0f49f_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY blog_blogpost_related_posts
    ADD CONSTRAINT blog_blogpost_related_posts_from_blogpost_id_3bd0f49f_uniq UNIQUE (from_blogpost_id, to_blogpost_id);


--
-- Name: blog_blogpost_related_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY blog_blogpost_related_posts
    ADD CONSTRAINT blog_blogpost_related_posts_pkey PRIMARY KEY (id);


--
-- Name: conf_setting_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY conf_setting
    ADD CONSTRAINT conf_setting_pkey PRIMARY KEY (id);


--
-- Name: core_sitepermission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY core_sitepermission
    ADD CONSTRAINT core_sitepermission_pkey PRIMARY KEY (id);


--
-- Name: core_sitepermission_sites_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY core_sitepermission_sites
    ADD CONSTRAINT core_sitepermission_sites_pkey PRIMARY KEY (id);


--
-- Name: core_sitepermission_sites_sitepermission_id_e3e7353a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY core_sitepermission_sites
    ADD CONSTRAINT core_sitepermission_sites_sitepermission_id_e3e7353a_uniq UNIQUE (sitepermission_id, site_id);


--
-- Name: core_sitepermission_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY core_sitepermission
    ADD CONSTRAINT core_sitepermission_user_id_key UNIQUE (user_id);


--
-- Name: custom_basicpage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY custom_basicpage
    ADD CONSTRAINT custom_basicpage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_comment_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_comment_flags
    ADD CONSTRAINT django_comment_flags_pkey PRIMARY KEY (id);


--
-- Name: django_comment_flags_user_id_537f77a7_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_comment_flags
    ADD CONSTRAINT django_comment_flags_user_id_537f77a7_uniq UNIQUE (user_id, comment_id, flag);


--
-- Name: django_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_comments
    ADD CONSTRAINT django_comments_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_redirect_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_redirect
    ADD CONSTRAINT django_redirect_pkey PRIMARY KEY (id);


--
-- Name: django_redirect_site_id_ac5dd16b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_redirect
    ADD CONSTRAINT django_redirect_site_id_ac5dd16b_uniq UNIQUE (site_id, old_path);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site_domain_a2e37b91_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_site
    ADD CONSTRAINT django_site_domain_a2e37b91_uniq UNIQUE (domain);


--
-- Name: django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: featured_featured_articles_featured_id_7b02d3d0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_articles
    ADD CONSTRAINT featured_featured_articles_featured_id_7b02d3d0_uniq UNIQUE (featured_id, article_id);


--
-- Name: featured_featured_articles_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_articles
    ADD CONSTRAINT featured_featured_articles_pkey PRIMARY KEY (id);


--
-- Name: featured_featured_events_featured_id_2cbbdb13_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_events
    ADD CONSTRAINT featured_featured_events_featured_id_2cbbdb13_uniq UNIQUE (featured_id, event_id);


--
-- Name: featured_featured_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_events
    ADD CONSTRAINT featured_featured_events_pkey PRIMARY KEY (id);


--
-- Name: featured_featured_pages_featured_id_3e2ae711_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_pages
    ADD CONSTRAINT featured_featured_pages_featured_id_3e2ae711_uniq UNIQUE (featured_id, basicpage_id);


--
-- Name: featured_featured_pages_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_pages
    ADD CONSTRAINT featured_featured_pages_pkey PRIMARY KEY (id);


--
-- Name: featured_featured_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured
    ADD CONSTRAINT featured_featured_pkey PRIMARY KEY (id);


--
-- Name: featured_featured_playlists_featured_id_ef5f0156_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_playlists
    ADD CONSTRAINT featured_featured_playlists_featured_id_ef5f0156_uniq UNIQUE (featured_id, playlist_id);


--
-- Name: featured_featured_playlists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_playlists
    ADD CONSTRAINT featured_featured_playlists_pkey PRIMARY KEY (id);


--
-- Name: featured_featured_videos_featured_id_6a284c11_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_videos
    ADD CONSTRAINT featured_featured_videos_featured_id_6a284c11_uniq UNIQUE (featured_id, video_id);


--
-- Name: featured_featured_videos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_videos
    ADD CONSTRAINT featured_featured_videos_pkey PRIMARY KEY (id);


--
-- Name: festival_artists_events_artist_id_7a228fd9_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_artists_events
    ADD CONSTRAINT festival_artists_events_artist_id_7a228fd9_uniq UNIQUE (artist_id, event_id);


--
-- Name: festival_artists_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_artists_events
    ADD CONSTRAINT festival_artists_events_pkey PRIMARY KEY (id);


--
-- Name: festival_artists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_artists
    ADD CONSTRAINT festival_artists_pkey PRIMARY KEY (id);


--
-- Name: festival_audios_artists_audio_id_76a1f2bf_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_audios_artists
    ADD CONSTRAINT festival_audios_artists_audio_id_76a1f2bf_uniq UNIQUE (audio_id, artist_id);


--
-- Name: festival_audios_artists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_audios_artists
    ADD CONSTRAINT festival_audios_artists_pkey PRIMARY KEY (id);


--
-- Name: festival_audios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_audios
    ADD CONSTRAINT festival_audios_pkey PRIMARY KEY (id);


--
-- Name: festival_featured_artists_featured_id_d3ea1a8f_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_artists
    ADD CONSTRAINT festival_featured_artists_featured_id_d3ea1a8f_uniq UNIQUE (featured_id, artist_id);


--
-- Name: festival_featured_artists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_artists
    ADD CONSTRAINT festival_featured_artists_pkey PRIMARY KEY (id);


--
-- Name: festival_featured_blogpost_featured_id_49f8847b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_blogposts
    ADD CONSTRAINT festival_featured_blogpost_featured_id_49f8847b_uniq UNIQUE (featured_id, blogpost_id);


--
-- Name: festival_featured_blogpost_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_blogposts
    ADD CONSTRAINT festival_featured_blogpost_pkey PRIMARY KEY (id);


--
-- Name: festival_featured_events_featured_id_de69ea4c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_events
    ADD CONSTRAINT festival_featured_events_featured_id_de69ea4c_uniq UNIQUE (featured_id, event_id);


--
-- Name: festival_featured_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_events
    ADD CONSTRAINT festival_featured_events_pkey PRIMARY KEY (id);


--
-- Name: festival_featured_page_featured_id_8988bf55_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_pages
    ADD CONSTRAINT festival_featured_page_featured_id_8988bf55_uniq UNIQUE (featured_id, page_id);


--
-- Name: festival_featured_page_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_pages
    ADD CONSTRAINT festival_featured_page_pkey PRIMARY KEY (id);


--
-- Name: festival_featured_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured
    ADD CONSTRAINT festival_featured_pkey PRIMARY KEY (id);


--
-- Name: festival_featured_playlists_featured_id_aa10c909_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_playlists
    ADD CONSTRAINT festival_featured_playlists_featured_id_aa10c909_uniq UNIQUE (featured_id, playlist_id);


--
-- Name: festival_featured_playlists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_playlists
    ADD CONSTRAINT festival_featured_playlists_pkey PRIMARY KEY (id);


--
-- Name: festival_featured_videos_featured_id_96398d4a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_videos
    ADD CONSTRAINT festival_featured_videos_featured_id_96398d4a_uniq UNIQUE (featured_id, video_id);


--
-- Name: festival_featured_videos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_videos
    ADD CONSTRAINT festival_featured_videos_pkey PRIMARY KEY (id);


--
-- Name: festival_playlist_audios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_playlist_audios
    ADD CONSTRAINT festival_playlist_audios_pkey PRIMARY KEY (id);


--
-- Name: festival_playlist_audios_playlist_id_60cf8a36_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_playlist_audios
    ADD CONSTRAINT festival_playlist_audios_playlist_id_60cf8a36_uniq UNIQUE (playlist_id, audio_id);


--
-- Name: festival_playlist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_playlist
    ADD CONSTRAINT festival_playlist_pkey PRIMARY KEY (id);


--
-- Name: festival_video_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_video_category
    ADD CONSTRAINT festival_video_category_pkey PRIMARY KEY (id);


--
-- Name: festival_video_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_videos
    ADD CONSTRAINT festival_video_pkey PRIMARY KEY (id);


--
-- Name: festival_videos_artists_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_videos_artists
    ADD CONSTRAINT festival_videos_artists_pkey PRIMARY KEY (id);


--
-- Name: festival_videos_artists_video_id_95e42728_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_videos_artists
    ADD CONSTRAINT festival_videos_artists_video_id_95e42728_uniq UNIQUE (video_id, artist_id);


--
-- Name: forms_field_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY forms_field
    ADD CONSTRAINT forms_field_pkey PRIMARY KEY (id);


--
-- Name: forms_fieldentry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY forms_fieldentry
    ADD CONSTRAINT forms_fieldentry_pkey PRIMARY KEY (id);


--
-- Name: forms_form_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY forms_form
    ADD CONSTRAINT forms_form_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: forms_formentry_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY forms_formentry
    ADD CONSTRAINT forms_formentry_pkey PRIMARY KEY (id);


--
-- Name: galleries_gallery_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY galleries_gallery
    ADD CONSTRAINT galleries_gallery_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: galleries_galleryimage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY galleries_galleryimage
    ADD CONSTRAINT galleries_galleryimage_pkey PRIMARY KEY (id);


--
-- Name: generic_assignedkeyword_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY generic_assignedkeyword
    ADD CONSTRAINT generic_assignedkeyword_pkey PRIMARY KEY (id);


--
-- Name: generic_keyword_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY generic_keyword
    ADD CONSTRAINT generic_keyword_pkey PRIMARY KEY (id);


--
-- Name: generic_rating_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY generic_rating
    ADD CONSTRAINT generic_rating_pkey PRIMARY KEY (id);


--
-- Name: generic_threadedcomment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY generic_threadedcomment
    ADD CONSTRAINT generic_threadedcomment_pkey PRIMARY KEY (comment_ptr_id);


--
-- Name: mezzanine_agenda_event_blog_posts_event_id_5c0a6b6a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_event_blog_posts
    ADD CONSTRAINT mezzanine_agenda_event_blog_posts_event_id_5c0a6b6a_uniq UNIQUE (event_id, blogpost_id);


--
-- Name: mezzanine_agenda_event_blog_posts_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_event_blog_posts
    ADD CONSTRAINT mezzanine_agenda_event_blog_posts_pkey PRIMARY KEY (id);


--
-- Name: mezzanine_agenda_event_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_event
    ADD CONSTRAINT mezzanine_agenda_event_pkey PRIMARY KEY (id);


--
-- Name: mezzanine_agenda_event_prices_event_id_2181d124_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_event_prices
    ADD CONSTRAINT mezzanine_agenda_event_prices_event_id_2181d124_uniq UNIQUE (event_id, eventprice_id);


--
-- Name: mezzanine_agenda_event_prices_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_event_prices
    ADD CONSTRAINT mezzanine_agenda_event_prices_pkey PRIMARY KEY (id);


--
-- Name: mezzanine_agenda_eventcategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_eventcategory
    ADD CONSTRAINT mezzanine_agenda_eventcategory_pkey PRIMARY KEY (id);


--
-- Name: mezzanine_agenda_eventlocation_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_eventlocation
    ADD CONSTRAINT mezzanine_agenda_eventlocation_pkey PRIMARY KEY (id);


--
-- Name: mezzanine_agenda_eventprice_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_eventprice
    ADD CONSTRAINT mezzanine_agenda_eventprice_pkey PRIMARY KEY (id);


--
-- Name: organization core_basicpage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization core_basicpage"
    ADD CONSTRAINT "organization core_basicpage_pkey" PRIMARY KEY (page_ptr_id);


--
-- Name: organization festival app_artist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization festival app_artist"
    ADD CONSTRAINT "organization festival app_artist_pkey" PRIMARY KEY (id);


--
-- Name: organization magazine_article_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization magazine_article"
    ADD CONSTRAINT "organization magazine_article_pkey" PRIMARY KEY (blogpost_ptr_id);


--
-- Name: organization magazine_category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization magazine_category"
    ADD CONSTRAINT "organization magazine_category_pkey" PRIMARY KEY (id);


--
-- Name: organization magazine_topic_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization magazine_topic"
    ADD CONSTRAINT "organization magazine_topic_pkey" PRIMARY KEY (id);


--
-- Name: organization media_audio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization media_audio"
    ADD CONSTRAINT "organization media_audio_pkey" PRIMARY KEY (id);


--
-- Name: organization media_playlist_audios_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization media_playlist_audios"
    ADD CONSTRAINT "organization media_playlist_audios_pkey" PRIMARY KEY (id);


--
-- Name: organization media_playlist_audios_playlist_id_572e632d_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization media_playlist_audios"
    ADD CONSTRAINT "organization media_playlist_audios_playlist_id_572e632d_uniq" UNIQUE (playlist_id, audio_id);


--
-- Name: organization media_playlist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization media_playlist"
    ADD CONSTRAINT "organization media_playlist_pkey" PRIMARY KEY (id);


--
-- Name: organization media_video_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization media_video"
    ADD CONSTRAINT "organization media_video_pkey" PRIMARY KEY (id);


--
-- Name: organization media_videocategory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization media_videocategory"
    ADD CONSTRAINT "organization media_videocategory_pkey" PRIMARY KEY (id);


--
-- Name: organization project_project_partners_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization project_project_partners"
    ADD CONSTRAINT "organization project_project_partners_pkey" PRIMARY KEY (id);


--
-- Name: organization project_project_partners_project_id_f5f989aa_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization project_project_partners"
    ADD CONSTRAINT "organization project_project_partners_project_id_f5f989aa_uniq" UNIQUE (project_id, organization_id);


--
-- Name: organization project_project_persons_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization project_project_persons"
    ADD CONSTRAINT "organization project_project_persons_pkey" PRIMARY KEY (id);


--
-- Name: organization project_project_persons_project_id_e51b8130_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization project_project_persons"
    ADD CONSTRAINT "organization project_project_persons_project_id_e51b8130_uniq" UNIQUE (project_id, person_id);


--
-- Name: organization project_project_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization project_project"
    ADD CONSTRAINT "organization project_project_pkey" PRIMARY KEY (id);


--
-- Name: organization structure_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_activity"
    ADD CONSTRAINT "organization structure_activity_pkey" PRIMARY KEY (id);


--
-- Name: organization structure_activity_teams_activity_id_1af98e79_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_activity_teams"
    ADD CONSTRAINT "organization structure_activity_teams_activity_id_1af98e79_uniq" UNIQUE (activity_id, team_id);


--
-- Name: organization structure_activity_teams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_activity_teams"
    ADD CONSTRAINT "organization structure_activity_teams_pkey" PRIMARY KEY (id);


--
-- Name: organization structure_address_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_address"
    ADD CONSTRAINT "organization structure_address_pkey" PRIMARY KEY (id);


--
-- Name: organization structure_department_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_department"
    ADD CONSTRAINT "organization structure_department_pkey" PRIMARY KEY (id);


--
-- Name: organization structure_link_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_link"
    ADD CONSTRAINT "organization structure_link_pkey" PRIMARY KEY (id);


--
-- Name: organization structure_linktype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_linktype"
    ADD CONSTRAINT "organization structure_linktype_pkey" PRIMARY KEY (id);


--
-- Name: organization structure_nationality_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_nationality"
    ADD CONSTRAINT "organization structure_nationality_pkey" PRIMARY KEY (id);


--
-- Name: organization structure_organization_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_organization"
    ADD CONSTRAINT "organization structure_organization_pkey" PRIMARY KEY (address_ptr_id);


--
-- Name: organization structure_organizationtype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_organizationtype"
    ADD CONSTRAINT "organization structure_organizationtype_pkey" PRIMARY KEY (id);


--
-- Name: organization structure_person_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_person"
    ADD CONSTRAINT "organization structure_person_pkey" PRIMARY KEY (id);


--
-- Name: organization structure_team_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_team"
    ADD CONSTRAINT "organization structure_team_pkey" PRIMARY KEY (id);


--
-- Name: organization_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_activity
    ADD CONSTRAINT organization_activity_pkey PRIMARY KEY (id);


--
-- Name: organization_activity_teams_activity_id_1c673181_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_activity_teams
    ADD CONSTRAINT organization_activity_teams_activity_id_1c673181_uniq UNIQUE (activity_id, team_id);


--
-- Name: organization_activity_teams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_activity_teams
    ADD CONSTRAINT organization_activity_teams_pkey PRIMARY KEY (id);


--
-- Name: organization_department_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_department
    ADD CONSTRAINT organization_department_pkey PRIMARY KEY (id);


--
-- Name: organization_link_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_link
    ADD CONSTRAINT organization_link_pkey PRIMARY KEY (id);


--
-- Name: organization_linktype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_linktype
    ADD CONSTRAINT organization_linktype_pkey PRIMARY KEY (id);


--
-- Name: organization_organization_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_organization
    ADD CONSTRAINT organization_organization_pkey PRIMARY KEY (id);


--
-- Name: organization_organizationtype_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_organizationtype
    ADD CONSTRAINT organization_organizationtype_pkey PRIMARY KEY (id);


--
-- Name: organization_person_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_person
    ADD CONSTRAINT organization_person_pkey PRIMARY KEY (id);


--
-- Name: organization_team_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_team
    ADD CONSTRAINT organization_team_pkey PRIMARY KEY (id);


--
-- Name: pages_link_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pages_link
    ADD CONSTRAINT pages_link_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: pages_page_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pages_page
    ADD CONSTRAINT pages_page_pkey PRIMARY KEY (id);


--
-- Name: pages_richtextpage_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pages_richtextpage
    ADD CONSTRAINT pages_richtextpage_pkey PRIMARY KEY (page_ptr_id);


--
-- Name: twitter_query_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY twitter_query
    ADD CONSTRAINT twitter_query_pkey PRIMARY KEY (id);


--
-- Name: twitter_tweet_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY twitter_tweet
    ADD CONSTRAINT twitter_tweet_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_0e939a4f ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_8373b171 ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_417f1b1c ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_0e939a4f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_0e939a4f ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_e8701ad4 ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_8373b171 ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_e8701ad4 ON auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_username_6821ab7c_like ON auth_user USING btree (username varchar_pattern_ops);


--
-- Name: blog_blogcategory_9365d6e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_blogcategory_9365d6e7 ON blog_blogcategory USING btree (site_id);


--
-- Name: blog_blogpost_9365d6e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_blogpost_9365d6e7 ON blog_blogpost USING btree (site_id);


--
-- Name: blog_blogpost_categories_53a0aca2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_blogpost_categories_53a0aca2 ON blog_blogpost_categories USING btree (blogpost_id);


--
-- Name: blog_blogpost_categories_efb54956; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_blogpost_categories_efb54956 ON blog_blogpost_categories USING btree (blogcategory_id);


--
-- Name: blog_blogpost_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_blogpost_e8701ad4 ON blog_blogpost USING btree (user_id);


--
-- Name: blog_blogpost_publish_date_703abc16_uniq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_blogpost_publish_date_703abc16_uniq ON blog_blogpost USING btree (publish_date);


--
-- Name: blog_blogpost_related_posts_191c4981; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_blogpost_related_posts_191c4981 ON blog_blogpost_related_posts USING btree (from_blogpost_id);


--
-- Name: blog_blogpost_related_posts_71f16e58; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX blog_blogpost_related_posts_71f16e58 ON blog_blogpost_related_posts USING btree (to_blogpost_id);


--
-- Name: conf_setting_9365d6e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX conf_setting_9365d6e7 ON conf_setting USING btree (site_id);


--
-- Name: core_sitepermission_sites_9365d6e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_sitepermission_sites_9365d6e7 ON core_sitepermission_sites USING btree (site_id);


--
-- Name: core_sitepermission_sites_f6687ce4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX core_sitepermission_sites_f6687ce4 ON core_sitepermission_sites USING btree (sitepermission_id);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_417f1b1c ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_e8701ad4 ON django_admin_log USING btree (user_id);


--
-- Name: django_comment_flags_327a6c43; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_comment_flags_327a6c43 ON django_comment_flags USING btree (flag);


--
-- Name: django_comment_flags_69b97d17; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_comment_flags_69b97d17 ON django_comment_flags USING btree (comment_id);


--
-- Name: django_comment_flags_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_comment_flags_e8701ad4 ON django_comment_flags USING btree (user_id);


--
-- Name: django_comment_flags_flag_8b141fcb_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_comment_flags_flag_8b141fcb_like ON django_comment_flags USING btree (flag varchar_pattern_ops);


--
-- Name: django_comments_417f1b1c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_comments_417f1b1c ON django_comments USING btree (content_type_id);


--
-- Name: django_comments_9365d6e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_comments_9365d6e7 ON django_comments USING btree (site_id);


--
-- Name: django_comments_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_comments_e8701ad4 ON django_comments USING btree (user_id);


--
-- Name: django_comments_submit_date_514ed2d9_uniq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_comments_submit_date_514ed2d9_uniq ON django_comments USING btree (submit_date);


--
-- Name: django_redirect_91a0b591; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_redirect_91a0b591 ON django_redirect USING btree (old_path);


--
-- Name: django_redirect_9365d6e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_redirect_9365d6e7 ON django_redirect USING btree (site_id);


--
-- Name: django_redirect_old_path_c6cc94d3_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_redirect_old_path_c6cc94d3_like ON django_redirect USING btree (old_path varchar_pattern_ops);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_de54fa62 ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: django_site_domain_a2e37b91_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_site_domain_a2e37b91_like ON django_site USING btree (domain varchar_pattern_ops);


--
-- Name: featured_featured_articles_58b5bd2f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX featured_featured_articles_58b5bd2f ON featured_featured_articles USING btree (featured_id);


--
-- Name: featured_featured_articles_a00c1b00; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX featured_featured_articles_a00c1b00 ON featured_featured_articles USING btree (article_id);


--
-- Name: featured_featured_events_4437cfac; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX featured_featured_events_4437cfac ON featured_featured_events USING btree (event_id);


--
-- Name: featured_featured_events_58b5bd2f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX featured_featured_events_58b5bd2f ON featured_featured_events USING btree (featured_id);


--
-- Name: featured_featured_pages_58b5bd2f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX featured_featured_pages_58b5bd2f ON featured_featured_pages USING btree (featured_id);


--
-- Name: featured_featured_pages_b4c0045d; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX featured_featured_pages_b4c0045d ON featured_featured_pages USING btree (basicpage_id);


--
-- Name: featured_featured_playlists_58b5bd2f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX featured_featured_playlists_58b5bd2f ON featured_featured_playlists USING btree (featured_id);


--
-- Name: featured_featured_playlists_5d3a6442; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX featured_featured_playlists_5d3a6442 ON featured_featured_playlists USING btree (playlist_id);


--
-- Name: featured_featured_videos_58b5bd2f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX featured_featured_videos_58b5bd2f ON featured_featured_videos USING btree (featured_id);


--
-- Name: featured_featured_videos_b58b747e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX featured_featured_videos_b58b747e ON featured_featured_videos USING btree (video_id);


--
-- Name: festival_artists_76776489; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_artists_76776489 ON festival_artists USING btree (publish_date);


--
-- Name: festival_artists_9365d6e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_artists_9365d6e7 ON festival_artists USING btree (site_id);


--
-- Name: festival_artists_events_4437cfac; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_artists_events_4437cfac ON festival_artists_events USING btree (event_id);


--
-- Name: festival_artists_events_ca949605; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_artists_events_ca949605 ON festival_artists_events USING btree (artist_id);


--
-- Name: festival_audios_4437cfac; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_audios_4437cfac ON festival_audios USING btree (event_id);


--
-- Name: festival_audios_76776489; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_audios_76776489 ON festival_audios USING btree (publish_date);


--
-- Name: festival_audios_9365d6e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_audios_9365d6e7 ON festival_audios USING btree (site_id);


--
-- Name: festival_audios_artists_26f6023f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_audios_artists_26f6023f ON festival_audios_artists USING btree (audio_id);


--
-- Name: festival_audios_artists_ca949605; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_audios_artists_ca949605 ON festival_audios_artists USING btree (artist_id);


--
-- Name: festival_featured_artists_58b5bd2f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_featured_artists_58b5bd2f ON festival_featured_artists USING btree (featured_id);


--
-- Name: festival_featured_artists_ca949605; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_featured_artists_ca949605 ON festival_featured_artists USING btree (artist_id);


--
-- Name: festival_featured_blogpost_53a0aca2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_featured_blogpost_53a0aca2 ON festival_featured_blogposts USING btree (blogpost_id);


--
-- Name: festival_featured_blogpost_58b5bd2f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_featured_blogpost_58b5bd2f ON festival_featured_blogposts USING btree (featured_id);


--
-- Name: festival_featured_events_4437cfac; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_featured_events_4437cfac ON festival_featured_events USING btree (event_id);


--
-- Name: festival_featured_events_58b5bd2f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_featured_events_58b5bd2f ON festival_featured_events USING btree (featured_id);


--
-- Name: festival_featured_page_1a63c800; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_featured_page_1a63c800 ON festival_featured_pages USING btree (page_id);


--
-- Name: festival_featured_page_58b5bd2f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_featured_page_58b5bd2f ON festival_featured_pages USING btree (featured_id);


--
-- Name: festival_featured_playlists_58b5bd2f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_featured_playlists_58b5bd2f ON festival_featured_playlists USING btree (featured_id);


--
-- Name: festival_featured_playlists_5d3a6442; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_featured_playlists_5d3a6442 ON festival_featured_playlists USING btree (playlist_id);


--
-- Name: festival_featured_videos_58b5bd2f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_featured_videos_58b5bd2f ON festival_featured_videos USING btree (featured_id);


--
-- Name: festival_featured_videos_b58b747e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_featured_videos_b58b747e ON festival_featured_videos USING btree (video_id);


--
-- Name: festival_playlist_4437cfac; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_playlist_4437cfac ON festival_playlist USING btree (event_id);


--
-- Name: festival_playlist_audios_26f6023f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_playlist_audios_26f6023f ON festival_playlist_audios USING btree (audio_id);


--
-- Name: festival_playlist_audios_5d3a6442; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_playlist_audios_5d3a6442 ON festival_playlist_audios USING btree (playlist_id);


--
-- Name: festival_video_4437cfac; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_video_4437cfac ON festival_videos USING btree (event_id);


--
-- Name: festival_video_76776489; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_video_76776489 ON festival_videos USING btree (publish_date);


--
-- Name: festival_video_9365d6e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_video_9365d6e7 ON festival_videos USING btree (site_id);


--
-- Name: festival_video_category_9365d6e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_video_category_9365d6e7 ON festival_video_category USING btree (site_id);


--
-- Name: festival_videos_artists_b58b747e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_videos_artists_b58b747e ON festival_videos_artists USING btree (video_id);


--
-- Name: festival_videos_artists_ca949605; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_videos_artists_ca949605 ON festival_videos_artists USING btree (artist_id);


--
-- Name: festival_videos_b583a629; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX festival_videos_b583a629 ON festival_videos USING btree (category_id);


--
-- Name: forms_field_d6cba1ad; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX forms_field_d6cba1ad ON forms_field USING btree (form_id);


--
-- Name: forms_fieldentry_b64a62ea; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX forms_fieldentry_b64a62ea ON forms_fieldentry USING btree (entry_id);


--
-- Name: forms_formentry_d6cba1ad; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX forms_formentry_d6cba1ad ON forms_formentry USING btree (form_id);


--
-- Name: galleries_galleryimage_6d994cdb; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX galleries_galleryimage_6d994cdb ON galleries_galleryimage USING btree (gallery_id);


--
-- Name: generic_assignedkeyword_417f1b1c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX generic_assignedkeyword_417f1b1c ON generic_assignedkeyword USING btree (content_type_id);


--
-- Name: generic_assignedkeyword_5c003bba; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX generic_assignedkeyword_5c003bba ON generic_assignedkeyword USING btree (keyword_id);


--
-- Name: generic_keyword_9365d6e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX generic_keyword_9365d6e7 ON generic_keyword USING btree (site_id);


--
-- Name: generic_rating_417f1b1c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX generic_rating_417f1b1c ON generic_rating USING btree (content_type_id);


--
-- Name: generic_rating_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX generic_rating_e8701ad4 ON generic_rating USING btree (user_id);


--
-- Name: generic_threadedcomment_21ce1e68; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX generic_threadedcomment_21ce1e68 ON generic_threadedcomment USING btree (replied_to_id);


--
-- Name: mezzanine_agenda_event_6be37982; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX mezzanine_agenda_event_6be37982 ON mezzanine_agenda_event USING btree (parent_id);


--
-- Name: mezzanine_agenda_event_76776489; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX mezzanine_agenda_event_76776489 ON mezzanine_agenda_event USING btree (publish_date);


--
-- Name: mezzanine_agenda_event_9365d6e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX mezzanine_agenda_event_9365d6e7 ON mezzanine_agenda_event USING btree (site_id);


--
-- Name: mezzanine_agenda_event_b583a629; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX mezzanine_agenda_event_b583a629 ON mezzanine_agenda_event USING btree (category_id);


--
-- Name: mezzanine_agenda_event_blog_posts_4437cfac; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX mezzanine_agenda_event_blog_posts_4437cfac ON mezzanine_agenda_event_blog_posts USING btree (event_id);


--
-- Name: mezzanine_agenda_event_blog_posts_53a0aca2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX mezzanine_agenda_event_blog_posts_53a0aca2 ON mezzanine_agenda_event_blog_posts USING btree (blogpost_id);


--
-- Name: mezzanine_agenda_event_e274a5da; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX mezzanine_agenda_event_e274a5da ON mezzanine_agenda_event USING btree (location_id);


--
-- Name: mezzanine_agenda_event_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX mezzanine_agenda_event_e8701ad4 ON mezzanine_agenda_event USING btree (user_id);


--
-- Name: mezzanine_agenda_event_prices_4437cfac; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX mezzanine_agenda_event_prices_4437cfac ON mezzanine_agenda_event_prices USING btree (event_id);


--
-- Name: mezzanine_agenda_event_prices_cc89e522; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX mezzanine_agenda_event_prices_cc89e522 ON mezzanine_agenda_event_prices USING btree (eventprice_id);


--
-- Name: mezzanine_agenda_eventlocation_9365d6e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX mezzanine_agenda_eventlocation_9365d6e7 ON mezzanine_agenda_eventlocation USING btree (site_id);


--
-- Name: organization festival app_artist_76776489; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization festival app_artist_76776489" ON "organization festival app_artist" USING btree (publish_date);


--
-- Name: organization festival app_artist_9365d6e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization festival app_artist_9365d6e7" ON "organization festival app_artist" USING btree (site_id);


--
-- Name: organization media_audio_76776489; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization media_audio_76776489" ON "organization media_audio" USING btree (publish_date);


--
-- Name: organization media_audio_9365d6e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization media_audio_9365d6e7" ON "organization media_audio" USING btree (site_id);


--
-- Name: organization media_playlist_audios_26f6023f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization media_playlist_audios_26f6023f" ON "organization media_playlist_audios" USING btree (audio_id);


--
-- Name: organization media_playlist_audios_5d3a6442; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization media_playlist_audios_5d3a6442" ON "organization media_playlist_audios" USING btree (playlist_id);


--
-- Name: organization media_video_76776489; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization media_video_76776489" ON "organization media_video" USING btree (publish_date);


--
-- Name: organization media_video_9365d6e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization media_video_9365d6e7" ON "organization media_video" USING btree (site_id);


--
-- Name: organization media_video_b583a629; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization media_video_b583a629" ON "organization media_video" USING btree (category_id);


--
-- Name: organization media_videocategory_9365d6e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization media_videocategory_9365d6e7" ON "organization media_videocategory" USING btree (site_id);


--
-- Name: organization project_project_76776489; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization project_project_76776489" ON "organization project_project" USING btree (publish_date);


--
-- Name: organization project_project_9365d6e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization project_project_9365d6e7" ON "organization project_project" USING btree (site_id);


--
-- Name: organization project_project_partners_26b2345e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization project_project_partners_26b2345e" ON "organization project_project_partners" USING btree (organization_id);


--
-- Name: organization project_project_partners_b098ad43; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization project_project_partners_b098ad43" ON "organization project_project_partners" USING btree (project_id);


--
-- Name: organization project_project_persons_a8452ca7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization project_project_persons_a8452ca7" ON "organization project_project_persons" USING btree (person_id);


--
-- Name: organization project_project_persons_b098ad43; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization project_project_persons_b098ad43" ON "organization project_project_persons" USING btree (project_id);


--
-- Name: organization structure_activity_a8452ca7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization structure_activity_a8452ca7" ON "organization structure_activity" USING btree (person_id);


--
-- Name: organization structure_activity_teams_f6a7ca40; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization structure_activity_teams_f6a7ca40" ON "organization structure_activity_teams" USING btree (team_id);


--
-- Name: organization structure_activity_teams_f8a3193a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization structure_activity_teams_f8a3193a" ON "organization structure_activity_teams" USING btree (activity_id);


--
-- Name: organization structure_department_26b2345e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization structure_department_26b2345e" ON "organization structure_department" USING btree (organization_id);


--
-- Name: organization structure_link_5fa7bec0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization structure_link_5fa7bec0" ON "organization structure_link" USING btree (link_type_id);


--
-- Name: organization structure_link_a8452ca7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization structure_link_a8452ca7" ON "organization structure_link" USING btree (person_id);


--
-- Name: organization structure_linktype_2dbcba41; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization structure_linktype_2dbcba41" ON "organization structure_linktype" USING btree (slug);


--
-- Name: organization structure_linktype_slug_24ecd300_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization structure_linktype_slug_24ecd300_like" ON "organization structure_linktype" USING btree (slug varchar_pattern_ops);


--
-- Name: organization structure_organization_94757cae; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization structure_organization_94757cae" ON "organization structure_organization" USING btree (type_id);


--
-- Name: organization structure_person_26b2345e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization structure_person_26b2345e" ON "organization structure_person" USING btree (organization_id);


--
-- Name: organization structure_person_76776489; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization structure_person_76776489" ON "organization structure_person" USING btree (publish_date);


--
-- Name: organization structure_person_9365d6e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization structure_person_9365d6e7" ON "organization structure_person" USING btree (site_id);


--
-- Name: organization structure_person_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization structure_person_e8701ad4" ON "organization structure_person" USING btree (user_id);


--
-- Name: organization structure_team_bf691be4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX "organization structure_team_bf691be4" ON "organization structure_team" USING btree (department_id);


--
-- Name: organization_activity_a8452ca7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organization_activity_a8452ca7 ON organization_activity USING btree (person_id);


--
-- Name: organization_activity_teams_f6a7ca40; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organization_activity_teams_f6a7ca40 ON organization_activity_teams USING btree (team_id);


--
-- Name: organization_activity_teams_f8a3193a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organization_activity_teams_f8a3193a ON organization_activity_teams USING btree (activity_id);


--
-- Name: organization_department_26b2345e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organization_department_26b2345e ON organization_department USING btree (organization_id);


--
-- Name: organization_link_5fa7bec0; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organization_link_5fa7bec0 ON organization_link USING btree (link_type_id);


--
-- Name: organization_link_a8452ca7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organization_link_a8452ca7 ON organization_link USING btree (person_id);


--
-- Name: organization_linktype_2dbcba41; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organization_linktype_2dbcba41 ON organization_linktype USING btree (slug);


--
-- Name: organization_linktype_slug_1f0b2037_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organization_linktype_slug_1f0b2037_like ON organization_linktype USING btree (slug varchar_pattern_ops);


--
-- Name: organization_organization_8a291c53; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organization_organization_8a291c53 ON organization_organization USING btree (organization_type_id);


--
-- Name: organization_person_26b2345e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organization_person_26b2345e ON organization_person USING btree (organization_id);


--
-- Name: organization_person_76776489; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organization_person_76776489 ON organization_person USING btree (publish_date);


--
-- Name: organization_person_9365d6e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organization_person_9365d6e7 ON organization_person USING btree (site_id);


--
-- Name: organization_person_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organization_person_e8701ad4 ON organization_person USING btree (user_id);


--
-- Name: organization_team_bf691be4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX organization_team_bf691be4 ON organization_team USING btree (department_id);


--
-- Name: pages_page_6be37982; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pages_page_6be37982 ON pages_page USING btree (parent_id);


--
-- Name: pages_page_9365d6e7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pages_page_9365d6e7 ON pages_page USING btree (site_id);


--
-- Name: pages_page_publish_date_eb7c8d46_uniq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX pages_page_publish_date_eb7c8d46_uniq ON pages_page USING btree (publish_date);


--
-- Name: twitter_tweet_0bbeda9c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX twitter_tweet_0bbeda9c ON twitter_tweet USING btree (query_id);


--
-- Name: D1d7ce5194efb980d70fae29ffc6b163; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_organization
    ADD CONSTRAINT "D1d7ce5194efb980d70fae29ffc6b163" FOREIGN KEY (organization_type_id) REFERENCES organization_organizationtype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: D28ad8287181d02c6296528ee0f01ea1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_person"
    ADD CONSTRAINT "D28ad8287181d02c6296528ee0f01ea1" FOREIGN KEY (organization_id) REFERENCES "organization structure_organization"(address_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: D80137809d0b76dc5cef7726c7537a8c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization project_project_partners"
    ADD CONSTRAINT "D80137809d0b76dc5cef7726c7537a8c" FOREIGN KEY (organization_id) REFERENCES "organization structure_organization"(address_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ad11d0c1662f6ed6839bc6d43c9ce4f3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY generic_threadedcomment
    ADD CONSTRAINT ad11d0c1662f6ed6839bc6d43c9ce4f3 FOREIGN KEY (replied_to_id) REFERENCES generic_threadedcomment(comment_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_per_permission_id_1fbb5f2c_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_per_permission_id_1fbb5f2c_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: b794d4ff9a8e52c64f67c489cc2bb8ca; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_department"
    ADD CONSTRAINT b794d4ff9a8e52c64f67c489cc2bb8ca FOREIGN KEY (organization_id) REFERENCES "organization structure_organization"(address_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_blogcategory_site_id_42b9c96d_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY blog_blogcategory
    ADD CONSTRAINT blog_blogcategory_site_id_42b9c96d_fk_django_site_id FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_blogpost__blogcategory_id_f6695246_fk_blog_blogcategory_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY blog_blogpost_categories
    ADD CONSTRAINT blog_blogpost__blogcategory_id_f6695246_fk_blog_blogcategory_id FOREIGN KEY (blogcategory_id) REFERENCES blog_blogcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_blogpost_categori_blogpost_id_daeea608_fk_blog_blogpost_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY blog_blogpost_categories
    ADD CONSTRAINT blog_blogpost_categori_blogpost_id_daeea608_fk_blog_blogpost_id FOREIGN KEY (blogpost_id) REFERENCES blog_blogpost(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_blogpost_rel_from_blogpost_id_27ea4c18_fk_blog_blogpost_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY blog_blogpost_related_posts
    ADD CONSTRAINT blog_blogpost_rel_from_blogpost_id_27ea4c18_fk_blog_blogpost_id FOREIGN KEY (from_blogpost_id) REFERENCES blog_blogpost(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_blogpost_relat_to_blogpost_id_35f7acdd_fk_blog_blogpost_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY blog_blogpost_related_posts
    ADD CONSTRAINT blog_blogpost_relat_to_blogpost_id_35f7acdd_fk_blog_blogpost_id FOREIGN KEY (to_blogpost_id) REFERENCES blog_blogpost(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_blogpost_site_id_7995688f_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY blog_blogpost
    ADD CONSTRAINT blog_blogpost_site_id_7995688f_fk_django_site_id FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: blog_blogpost_user_id_12ed6b16_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY blog_blogpost
    ADD CONSTRAINT blog_blogpost_user_id_12ed6b16_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: conf_setting_site_id_b235f7ed_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY conf_setting
    ADD CONSTRAINT conf_setting_site_id_b235f7ed_fk_django_site_id FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_sitep_sitepermission_id_d33bc79e_fk_core_sitepermission_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY core_sitepermission_sites
    ADD CONSTRAINT core_sitep_sitepermission_id_d33bc79e_fk_core_sitepermission_id FOREIGN KEY (sitepermission_id) REFERENCES core_sitepermission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_sitepermission_sites_site_id_38038b76_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY core_sitepermission_sites
    ADD CONSTRAINT core_sitepermission_sites_site_id_38038b76_fk_django_site_id FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_sitepermission_user_id_0a3cbb11_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY core_sitepermission
    ADD CONSTRAINT core_sitepermission_user_id_0a3cbb11_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: custom_basicpage_page_ptr_id_d0f454e1_fk_pages_page_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY custom_basicpage
    ADD CONSTRAINT custom_basicpage_page_ptr_id_d0f454e1_fk_pages_page_id FOREIGN KEY (page_ptr_id) REFERENCES pages_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: d64f6535e656c5745cc20a6f46313c19; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_articles
    ADD CONSTRAINT d64f6535e656c5745cc20a6f46313c19 FOREIGN KEY (article_id) REFERENCES "organization magazine_article"(blogpost_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: department_id_f883d4ab_fk_organization structure_department_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_team"
    ADD CONSTRAINT "department_id_f883d4ab_fk_organization structure_department_id" FOREIGN KEY (department_id) REFERENCES "organization structure_department"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: dfba514b74da58741e9d9fb33d523a70; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_pages
    ADD CONSTRAINT dfba514b74da58741e9d9fb33d523a70 FOREIGN KEY (basicpage_id) REFERENCES "organization core_basicpage"(page_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_content_type_id_c4bce8eb_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_content_type_id_c4bce8eb_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comme_content_type_id_c4afe962_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_comments
    ADD CONSTRAINT django_comme_content_type_id_c4afe962_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comment_flags_comment_id_d8054933_fk_django_comments_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_comment_flags
    ADD CONSTRAINT django_comment_flags_comment_id_d8054933_fk_django_comments_id FOREIGN KEY (comment_id) REFERENCES django_comments(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comment_flags_user_id_f3f81f0a_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_comment_flags
    ADD CONSTRAINT django_comment_flags_user_id_f3f81f0a_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comments_site_id_9dcf666e_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_comments
    ADD CONSTRAINT django_comments_site_id_9dcf666e_fk_django_site_id FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_comments_user_id_a0a440a1_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_comments
    ADD CONSTRAINT django_comments_user_id_a0a440a1_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_redirect_site_id_c3e37341_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_redirect
    ADD CONSTRAINT django_redirect_site_id_c3e37341_fk_django_site_id FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: featured_featu_video_id_e9e7d96e_fk_organization media_video_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_videos
    ADD CONSTRAINT "featured_featu_video_id_e9e7d96e_fk_organization media_video_id" FOREIGN KEY (video_id) REFERENCES "organization media_video"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: featured_feature_event_id_6255e6f3_fk_mezzanine_agenda_event_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_events
    ADD CONSTRAINT featured_feature_event_id_6255e6f3_fk_mezzanine_agenda_event_id FOREIGN KEY (event_id) REFERENCES mezzanine_agenda_event(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: featured_featured__featured_id_48c8d3d6_fk_featured_featured_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_articles
    ADD CONSTRAINT featured_featured__featured_id_48c8d3d6_fk_featured_featured_id FOREIGN KEY (featured_id) REFERENCES featured_featured(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: featured_featured__featured_id_b6e32128_fk_featured_featured_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_events
    ADD CONSTRAINT featured_featured__featured_id_b6e32128_fk_featured_featured_id FOREIGN KEY (featured_id) REFERENCES featured_featured(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: featured_featured__featured_id_d7ae69aa_fk_featured_featured_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_videos
    ADD CONSTRAINT featured_featured__featured_id_d7ae69aa_fk_featured_featured_id FOREIGN KEY (featured_id) REFERENCES featured_featured(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: featured_featured__featured_id_dc078de8_fk_featured_featured_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_pages
    ADD CONSTRAINT featured_featured__featured_id_dc078de8_fk_featured_featured_id FOREIGN KEY (featured_id) REFERENCES featured_featured(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: featured_featured__featured_id_fa985286_fk_featured_featured_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_playlists
    ADD CONSTRAINT featured_featured__featured_id_fa985286_fk_featured_featured_id FOREIGN KEY (featured_id) REFERENCES featured_featured(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: featured_playlist_id_330bfa1d_fk_organization media_playlist_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY featured_featured_playlists
    ADD CONSTRAINT "featured_playlist_id_330bfa1d_fk_organization media_playlist_id" FOREIGN KEY (playlist_id) REFERENCES "organization media_playlist"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_artists_even_artist_id_833ca1d3_fk_festival_artists_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_artists_events
    ADD CONSTRAINT festival_artists_even_artist_id_833ca1d3_fk_festival_artists_id FOREIGN KEY (artist_id) REFERENCES festival_artists(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_artists_event_id_c8615747_fk_mezzanine_agenda_event_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_artists_events
    ADD CONSTRAINT festival_artists_event_id_c8615747_fk_mezzanine_agenda_event_id FOREIGN KEY (event_id) REFERENCES mezzanine_agenda_event(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_artists_site_id_50fdeb52_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_artists
    ADD CONSTRAINT festival_artists_site_id_50fdeb52_fk_django_site_id FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_audios_artis_artist_id_36ce2489_fk_festival_artists_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_audios_artists
    ADD CONSTRAINT festival_audios_artis_artist_id_36ce2489_fk_festival_artists_id FOREIGN KEY (artist_id) REFERENCES festival_artists(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_audios_artists_audio_id_2ff0e9c8_fk_festival_audios_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_audios_artists
    ADD CONSTRAINT festival_audios_artists_audio_id_2ff0e9c8_fk_festival_audios_id FOREIGN KEY (audio_id) REFERENCES festival_audios(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_audios_event_id_a27b685f_fk_mezzanine_agenda_event_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_audios
    ADD CONSTRAINT festival_audios_event_id_a27b685f_fk_mezzanine_agenda_event_id FOREIGN KEY (event_id) REFERENCES mezzanine_agenda_event(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_audios_site_id_1fed3780_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_audios
    ADD CONSTRAINT festival_audios_site_id_1fed3780_fk_django_site_id FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_feature_event_id_8d271d48_fk_mezzanine_agenda_event_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_events
    ADD CONSTRAINT festival_feature_event_id_8d271d48_fk_mezzanine_agenda_event_id FOREIGN KEY (event_id) REFERENCES mezzanine_agenda_event(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_featured__featured_id_3ad1f022_fk_festival_featured_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_events
    ADD CONSTRAINT festival_featured__featured_id_3ad1f022_fk_festival_featured_id FOREIGN KEY (featured_id) REFERENCES festival_featured(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_featured__featured_id_aae89f8a_fk_festival_featured_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_blogposts
    ADD CONSTRAINT festival_featured__featured_id_aae89f8a_fk_festival_featured_id FOREIGN KEY (featured_id) REFERENCES festival_featured(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_featured__featured_id_b055f56f_fk_festival_featured_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_pages
    ADD CONSTRAINT festival_featured__featured_id_b055f56f_fk_festival_featured_id FOREIGN KEY (featured_id) REFERENCES festival_featured(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_featured__featured_id_c3604d25_fk_festival_featured_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_videos
    ADD CONSTRAINT festival_featured__featured_id_c3604d25_fk_festival_featured_id FOREIGN KEY (featured_id) REFERENCES festival_featured(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_featured__featured_id_c9be5886_fk_festival_featured_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_playlists
    ADD CONSTRAINT festival_featured__featured_id_c9be5886_fk_festival_featured_id FOREIGN KEY (featured_id) REFERENCES festival_featured(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_featured__featured_id_dc7a42c5_fk_festival_featured_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_artists
    ADD CONSTRAINT festival_featured__featured_id_dc7a42c5_fk_festival_featured_id FOREIGN KEY (featured_id) REFERENCES festival_featured(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_featured__playlist_id_d092170f_fk_festival_playlist_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_playlists
    ADD CONSTRAINT festival_featured__playlist_id_d092170f_fk_festival_playlist_id FOREIGN KEY (playlist_id) REFERENCES festival_playlist(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_featured_art_artist_id_d06f2766_fk_festival_artists_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_artists
    ADD CONSTRAINT festival_featured_art_artist_id_d06f2766_fk_festival_artists_id FOREIGN KEY (artist_id) REFERENCES festival_artists(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_featured_blog_blogpost_id_2e026bb2_fk_blog_blogpost_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_blogposts
    ADD CONSTRAINT festival_featured_blog_blogpost_id_2e026bb2_fk_blog_blogpost_id FOREIGN KEY (blogpost_id) REFERENCES blog_blogpost(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_featured_pages_page_id_e92a7221_fk_pages_page_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_pages
    ADD CONSTRAINT festival_featured_pages_page_id_e92a7221_fk_pages_page_id FOREIGN KEY (page_id) REFERENCES pages_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_featured_video_video_id_d75fa16e_fk_festival_videos_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_featured_videos
    ADD CONSTRAINT festival_featured_video_video_id_d75fa16e_fk_festival_videos_id FOREIGN KEY (video_id) REFERENCES festival_videos(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_playlis_event_id_a78e4e6a_fk_mezzanine_agenda_event_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_playlist
    ADD CONSTRAINT festival_playlis_event_id_a78e4e6a_fk_mezzanine_agenda_event_id FOREIGN KEY (event_id) REFERENCES mezzanine_agenda_event(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_playlist__playlist_id_715e85b2_fk_festival_playlist_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_playlist_audios
    ADD CONSTRAINT festival_playlist__playlist_id_715e85b2_fk_festival_playlist_id FOREIGN KEY (playlist_id) REFERENCES festival_playlist(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_playlist_audio_audio_id_409d0de7_fk_festival_audios_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_playlist_audios
    ADD CONSTRAINT festival_playlist_audio_audio_id_409d0de7_fk_festival_audios_id FOREIGN KEY (audio_id) REFERENCES festival_audios(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_vid_category_id_958ff9c1_fk_festival_video_category_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_videos
    ADD CONSTRAINT festival_vid_category_id_958ff9c1_fk_festival_video_category_id FOREIGN KEY (category_id) REFERENCES festival_video_category(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_video_category_site_id_63fcd2e1_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_video_category
    ADD CONSTRAINT festival_video_category_site_id_63fcd2e1_fk_django_site_id FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_video_event_id_8e3fd88d_fk_mezzanine_agenda_event_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_videos
    ADD CONSTRAINT festival_video_event_id_8e3fd88d_fk_mezzanine_agenda_event_id FOREIGN KEY (event_id) REFERENCES mezzanine_agenda_event(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_video_site_id_6702cf38_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_videos
    ADD CONSTRAINT festival_video_site_id_6702cf38_fk_django_site_id FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_videos_artis_artist_id_2f90187b_fk_festival_artists_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_videos_artists
    ADD CONSTRAINT festival_videos_artis_artist_id_2f90187b_fk_festival_artists_id FOREIGN KEY (artist_id) REFERENCES festival_artists(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: festival_videos_artists_video_id_b11ed9e9_fk_festival_videos_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY festival_videos_artists
    ADD CONSTRAINT festival_videos_artists_video_id_b11ed9e9_fk_festival_videos_id FOREIGN KEY (video_id) REFERENCES festival_videos(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: forms_field_form_id_9ca5dc7e_fk_forms_form_page_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY forms_field
    ADD CONSTRAINT forms_field_form_id_9ca5dc7e_fk_forms_form_page_ptr_id FOREIGN KEY (form_id) REFERENCES forms_form(page_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: forms_fieldentry_entry_id_c4fdc570_fk_forms_formentry_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY forms_fieldentry
    ADD CONSTRAINT forms_fieldentry_entry_id_c4fdc570_fk_forms_formentry_id FOREIGN KEY (entry_id) REFERENCES forms_formentry(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: forms_form_page_ptr_id_d3bcbf3a_fk_pages_page_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY forms_form
    ADD CONSTRAINT forms_form_page_ptr_id_d3bcbf3a_fk_pages_page_id FOREIGN KEY (page_ptr_id) REFERENCES pages_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: forms_formentry_form_id_d0f23912_fk_forms_form_page_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY forms_formentry
    ADD CONSTRAINT forms_formentry_form_id_d0f23912_fk_forms_form_page_ptr_id FOREIGN KEY (form_id) REFERENCES forms_form(page_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: galleries__gallery_id_af12d3f5_fk_galleries_gallery_page_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY galleries_galleryimage
    ADD CONSTRAINT galleries__gallery_id_af12d3f5_fk_galleries_gallery_page_ptr_id FOREIGN KEY (gallery_id) REFERENCES galleries_gallery(page_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: galleries_gallery_page_ptr_id_8562ba87_fk_pages_page_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY galleries_gallery
    ADD CONSTRAINT galleries_gallery_page_ptr_id_8562ba87_fk_pages_page_id FOREIGN KEY (page_ptr_id) REFERENCES pages_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: generic_assi_content_type_id_3dd89a7f_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY generic_assignedkeyword
    ADD CONSTRAINT generic_assi_content_type_id_3dd89a7f_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: generic_assignedkeywo_keyword_id_44c17f9d_fk_generic_keyword_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY generic_assignedkeyword
    ADD CONSTRAINT generic_assignedkeywo_keyword_id_44c17f9d_fk_generic_keyword_id FOREIGN KEY (keyword_id) REFERENCES generic_keyword(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: generic_keyword_site_id_c5be0acc_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY generic_keyword
    ADD CONSTRAINT generic_keyword_site_id_c5be0acc_fk_django_site_id FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: generic_rati_content_type_id_eaf475fa_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY generic_rating
    ADD CONSTRAINT generic_rati_content_type_id_eaf475fa_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: generic_rating_user_id_60020469_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY generic_rating
    ADD CONSTRAINT generic_rating_user_id_60020469_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: generic_threadedc_comment_ptr_id_e208ed60_fk_django_comments_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY generic_threadedcomment
    ADD CONSTRAINT generic_threadedc_comment_ptr_id_e208ed60_fk_django_comments_id FOREIGN KEY (comment_ptr_id) REFERENCES django_comments(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mezza_category_id_f9632aec_fk_mezzanine_agenda_eventcategory_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_event
    ADD CONSTRAINT mezza_category_id_f9632aec_fk_mezzanine_agenda_eventcategory_id FOREIGN KEY (category_id) REFERENCES mezzanine_agenda_eventcategory(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mezza_location_id_79f17710_fk_mezzanine_agenda_eventlocation_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_event
    ADD CONSTRAINT mezza_location_id_79f17710_fk_mezzanine_agenda_eventlocation_id FOREIGN KEY (location_id) REFERENCES mezzanine_agenda_eventlocation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mezzan_eventprice_id_8d79c68b_fk_mezzanine_agenda_eventprice_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_event_prices
    ADD CONSTRAINT mezzan_eventprice_id_8d79c68b_fk_mezzanine_agenda_eventprice_id FOREIGN KEY (eventprice_id) REFERENCES mezzanine_agenda_eventprice(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mezzanine_agend_parent_id_0e3235d9_fk_mezzanine_agenda_event_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_event
    ADD CONSTRAINT mezzanine_agend_parent_id_0e3235d9_fk_mezzanine_agenda_event_id FOREIGN KEY (parent_id) REFERENCES mezzanine_agenda_event(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mezzanine_agenda_event_blogpost_id_76acb543_fk_blog_blogpost_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_event_blog_posts
    ADD CONSTRAINT mezzanine_agenda_event_blogpost_id_76acb543_fk_blog_blogpost_id FOREIGN KEY (blogpost_id) REFERENCES blog_blogpost(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mezzanine_agenda_event_id_cfa89ea7_fk_mezzanine_agenda_event_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_event_prices
    ADD CONSTRAINT mezzanine_agenda_event_id_cfa89ea7_fk_mezzanine_agenda_event_id FOREIGN KEY (event_id) REFERENCES mezzanine_agenda_event(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mezzanine_agenda_event_id_e64a5327_fk_mezzanine_agenda_event_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_event_blog_posts
    ADD CONSTRAINT mezzanine_agenda_event_id_e64a5327_fk_mezzanine_agenda_event_id FOREIGN KEY (event_id) REFERENCES mezzanine_agenda_event(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mezzanine_agenda_event_site_id_4a5df2ce_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_event
    ADD CONSTRAINT mezzanine_agenda_event_site_id_4a5df2ce_fk_django_site_id FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mezzanine_agenda_event_user_id_422b0aea_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_event
    ADD CONSTRAINT mezzanine_agenda_event_user_id_422b0aea_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: mezzanine_agenda_eventlocati_site_id_aaa69136_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mezzanine_agenda_eventlocation
    ADD CONSTRAINT mezzanine_agenda_eventlocati_site_id_aaa69136_fk_django_site_id FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: or_address_ptr_id_132044ea_fk_organization structure_address_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_organization"
    ADD CONSTRAINT "or_address_ptr_id_132044ea_fk_organization structure_address_id" FOREIGN KEY (address_ptr_id) REFERENCES "organization structure_address"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: org_category_id_7ec6ada7_fk_organization media_videocategory_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization media_video"
    ADD CONSTRAINT "org_category_id_7ec6ada7_fk_organization media_videocategory_id" FOREIGN KEY (category_id) REFERENCES "organization media_videocategory"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: org_link_type_id_6e63d2c1_fk_organization structure_linktype_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_link"
    ADD CONSTRAINT "org_link_type_id_6e63d2c1_fk_organization structure_linktype_id" FOREIGN KEY (link_type_id) REFERENCES "organization structure_linktype"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: orga_activity_id_5562dbb1_fk_organization structure_activity_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_activity_teams"
    ADD CONSTRAINT "orga_activity_id_5562dbb1_fk_organization structure_activity_id" FOREIGN KEY (activity_id) REFERENCES "organization structure_activity"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organi_organization_id_28133c66_fk_organization_organization_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_person
    ADD CONSTRAINT organi_organization_id_28133c66_fk_organization_organization_id FOREIGN KEY (organization_id) REFERENCES organization_organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organi_organization_id_460ed4f9_fk_organization_organization_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_department
    ADD CONSTRAINT organi_organization_id_460ed4f9_fk_organization_organization_id FOREIGN KEY (organization_id) REFERENCES organization_organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organiza_person_id_127c37ab_fk_organization structure_person_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization project_project_persons"
    ADD CONSTRAINT "organiza_person_id_127c37ab_fk_organization structure_person_id" FOREIGN KEY (person_id) REFERENCES "organization structure_person"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organiza_person_id_36635e87_fk_organization structure_person_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_activity"
    ADD CONSTRAINT "organiza_person_id_36635e87_fk_organization structure_person_id" FOREIGN KEY (person_id) REFERENCES "organization structure_person"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organiza_person_id_4014b622_fk_organization structure_person_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_link"
    ADD CONSTRAINT "organiza_person_id_4014b622_fk_organization structure_person_id" FOREIGN KEY (person_id) REFERENCES "organization structure_person"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organiza_playlist_id_1b30b257_fk_organization media_playlist_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization media_playlist_audios"
    ADD CONSTRAINT "organiza_playlist_id_1b30b257_fk_organization media_playlist_id" FOREIGN KEY (playlist_id) REFERENCES "organization media_playlist"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organiza_project_id_54c7bb13_fk_organization project_project_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization project_project_partners"
    ADD CONSTRAINT "organiza_project_id_54c7bb13_fk_organization project_project_id" FOREIGN KEY (project_id) REFERENCES "organization project_project"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organiza_project_id_c52c1f96_fk_organization project_project_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization project_project_persons"
    ADD CONSTRAINT "organiza_project_id_c52c1f96_fk_organization project_project_id" FOREIGN KEY (project_id) REFERENCES "organization project_project"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organizati_department_id_53381866_fk_organization_department_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_team
    ADD CONSTRAINT organizati_department_id_53381866_fk_organization_department_id FOREIGN KEY (department_id) REFERENCES organization_department(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization core_basicpa_page_ptr_id_e37e1422_fk_pages_page_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization core_basicpage"
    ADD CONSTRAINT "organization core_basicpa_page_ptr_id_e37e1422_fk_pages_page_id" FOREIGN KEY (page_ptr_id) REFERENCES pages_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization festival app_ar_site_id_f3d1d07e_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization festival app_artist"
    ADD CONSTRAINT "organization festival app_ar_site_id_f3d1d07e_fk_django_site_id" FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization m_audio_id_8288538b_fk_organization media_audio_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization media_playlist_audios"
    ADD CONSTRAINT "organization m_audio_id_8288538b_fk_organization media_audio_id" FOREIGN KEY (audio_id) REFERENCES "organization media_audio"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization magaz_blogpost_ptr_id_7eca9632_fk_blog_blogpost_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization magazine_article"
    ADD CONSTRAINT "organization magaz_blogpost_ptr_id_7eca9632_fk_blog_blogpost_id" FOREIGN KEY (blogpost_ptr_id) REFERENCES blog_blogpost(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization media_audio_site_id_d5cdc93f_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization media_audio"
    ADD CONSTRAINT "organization media_audio_site_id_d5cdc93f_fk_django_site_id" FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization media_video_site_id_81a1fe47_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization media_video"
    ADD CONSTRAINT "organization media_video_site_id_81a1fe47_fk_django_site_id" FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization media_videocate_site_id_9ef0082b_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization media_videocategory"
    ADD CONSTRAINT "organization media_videocate_site_id_9ef0082b_fk_django_site_id" FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization project_project_site_id_76acb4cd_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization project_project"
    ADD CONSTRAINT "organization project_project_site_id_76acb4cd_fk_django_site_id" FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization structure_perso_site_id_715223db_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_person"
    ADD CONSTRAINT "organization structure_perso_site_id_715223db_fk_django_site_id" FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization structure_person_user_id_e293ce9e_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_person"
    ADD CONSTRAINT "organization structure_person_user_id_e293ce9e_fk_auth_user_id" FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization__link_type_id_1f576256_fk_organization_linktype_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_link
    ADD CONSTRAINT organization__link_type_id_1f576256_fk_organization_linktype_id FOREIGN KEY (link_type_id) REFERENCES organization_linktype(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization_a_activity_id_74e130d5_fk_organization_activity_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_activity_teams
    ADD CONSTRAINT organization_a_activity_id_74e130d5_fk_organization_activity_id FOREIGN KEY (activity_id) REFERENCES organization_activity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization_activ_person_id_6be7474e_fk_organization_person_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_activity
    ADD CONSTRAINT organization_activ_person_id_6be7474e_fk_organization_person_id FOREIGN KEY (person_id) REFERENCES organization_person(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization_activity__team_id_1ad9296d_fk_organization_team_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_activity_teams
    ADD CONSTRAINT organization_activity__team_id_1ad9296d_fk_organization_team_id FOREIGN KEY (team_id) REFERENCES organization_team(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization_link_person_id_53629bcd_fk_organization_person_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_link
    ADD CONSTRAINT organization_link_person_id_53629bcd_fk_organization_person_id FOREIGN KEY (person_id) REFERENCES organization_person(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization_person_site_id_f8f17ee8_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_person
    ADD CONSTRAINT organization_person_site_id_f8f17ee8_fk_django_site_id FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization_person_user_id_5a133c8a_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY organization_person
    ADD CONSTRAINT organization_person_user_id_5a133c8a_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization_team_id_6f1fc070_fk_organization structure_team_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_activity_teams"
    ADD CONSTRAINT "organization_team_id_6f1fc070_fk_organization structure_team_id" FOREIGN KEY (team_id) REFERENCES "organization structure_team"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: pages_link_page_ptr_id_37d469f7_fk_pages_page_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pages_link
    ADD CONSTRAINT pages_link_page_ptr_id_37d469f7_fk_pages_page_id FOREIGN KEY (page_ptr_id) REFERENCES pages_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: pages_page_parent_id_133fa4d3_fk_pages_page_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pages_page
    ADD CONSTRAINT pages_page_parent_id_133fa4d3_fk_pages_page_id FOREIGN KEY (parent_id) REFERENCES pages_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: pages_page_site_id_47a43e5b_fk_django_site_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pages_page
    ADD CONSTRAINT pages_page_site_id_47a43e5b_fk_django_site_id FOREIGN KEY (site_id) REFERENCES django_site(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: pages_richtextpage_page_ptr_id_8ca99b83_fk_pages_page_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY pages_richtextpage
    ADD CONSTRAINT pages_richtextpage_page_ptr_id_8ca99b83_fk_pages_page_id FOREIGN KEY (page_ptr_id) REFERENCES pages_page(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: twitter_tweet_query_id_bd42b699_fk_twitter_query_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY twitter_tweet
    ADD CONSTRAINT twitter_tweet_query_id_bd42b699_fk_twitter_query_id FOREIGN KEY (query_id) REFERENCES twitter_query(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: type_id_ca6f443f_fk_organization structure_organizationtype_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "organization structure_organization"
    ADD CONSTRAINT "type_id_ca6f443f_fk_organization structure_organizationtype_id" FOREIGN KEY (type_id) REFERENCES "organization structure_organizationtype"(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

