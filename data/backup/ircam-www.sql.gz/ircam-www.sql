-- MySQL dump 10.16  Distrib 10.1.14-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db    Database: ircam-www
-- ------------------------------------------------------
-- Server version	10.1.14-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissi_permission_id_84c5c92e_fk_auth_permission_id` (`permission_id`),
  CONSTRAINT `auth_group_permissi_permission_id_84c5c92e_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permissions_group_id_b120cbf9_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_01ab375a_uniq` (`content_type_id`,`codename`),
  CONSTRAINT `auth_permissi_content_type_id_2f476e4b_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=146 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add permission',1,'add_permission'),(2,'Can change permission',1,'change_permission'),(3,'Can delete permission',1,'delete_permission'),(4,'Can add group',2,'add_group'),(5,'Can change group',2,'change_group'),(6,'Can delete group',2,'delete_group'),(7,'Can add user',3,'add_user'),(8,'Can change user',3,'change_user'),(9,'Can delete user',3,'delete_user'),(10,'Can add content type',4,'add_contenttype'),(11,'Can change content type',4,'change_contenttype'),(12,'Can delete content type',4,'delete_contenttype'),(13,'Can add redirect',5,'add_redirect'),(14,'Can change redirect',5,'change_redirect'),(15,'Can delete redirect',5,'delete_redirect'),(16,'Can add session',6,'add_session'),(17,'Can change session',6,'change_session'),(18,'Can delete session',6,'delete_session'),(19,'Can add site',7,'add_site'),(20,'Can change site',7,'change_site'),(21,'Can delete site',7,'delete_site'),(22,'Can add Setting',8,'add_setting'),(23,'Can change Setting',8,'change_setting'),(24,'Can delete Setting',8,'delete_setting'),(25,'Can add Site permission',9,'add_sitepermission'),(26,'Can change Site permission',9,'change_sitepermission'),(27,'Can delete Site permission',9,'delete_sitepermission'),(28,'Can add Comment',10,'add_threadedcomment'),(29,'Can change Comment',10,'change_threadedcomment'),(30,'Can delete Comment',10,'delete_threadedcomment'),(31,'Can add Keyword',11,'add_keyword'),(32,'Can change Keyword',11,'change_keyword'),(33,'Can delete Keyword',11,'delete_keyword'),(34,'Can add assigned keyword',12,'add_assignedkeyword'),(35,'Can change assigned keyword',12,'change_assignedkeyword'),(36,'Can delete assigned keyword',12,'delete_assignedkeyword'),(37,'Can add Rating',13,'add_rating'),(38,'Can change Rating',13,'change_rating'),(39,'Can delete Rating',13,'delete_rating'),(40,'Can add Page',14,'add_page'),(41,'Can change Page',14,'change_page'),(42,'Can delete Page',14,'delete_page'),(43,'Can add Rich text page',15,'add_richtextpage'),(44,'Can change Rich text page',15,'change_richtextpage'),(45,'Can delete Rich text page',15,'delete_richtextpage'),(46,'Can add Link',16,'add_link'),(47,'Can change Link',16,'change_link'),(48,'Can delete Link',16,'delete_link'),(49,'Can add Blog post',17,'add_blogpost'),(50,'Can change Blog post',17,'change_blogpost'),(51,'Can delete Blog post',17,'delete_blogpost'),(52,'Can add Blog Category',18,'add_blogcategory'),(53,'Can change Blog Category',18,'change_blogcategory'),(54,'Can delete Blog Category',18,'delete_blogcategory'),(55,'Can add Form',19,'add_form'),(56,'Can change Form',19,'change_form'),(57,'Can delete Form',19,'delete_form'),(58,'Can add Field',20,'add_field'),(59,'Can change Field',20,'change_field'),(60,'Can delete Field',20,'delete_field'),(61,'Can add Form entry',21,'add_formentry'),(62,'Can change Form entry',21,'change_formentry'),(63,'Can delete Form entry',21,'delete_formentry'),(64,'Can add Form field entry',22,'add_fieldentry'),(65,'Can change Form field entry',22,'change_fieldentry'),(66,'Can delete Form field entry',22,'delete_fieldentry'),(67,'Can add Gallery',23,'add_gallery'),(68,'Can change Gallery',23,'change_gallery'),(69,'Can delete Gallery',23,'delete_gallery'),(70,'Can add Image',24,'add_galleryimage'),(71,'Can change Image',24,'change_galleryimage'),(72,'Can delete Image',24,'delete_galleryimage'),(73,'Can add Twitter query',25,'add_query'),(74,'Can change Twitter query',25,'change_query'),(75,'Can delete Twitter query',25,'delete_query'),(76,'Can add Tweet',26,'add_tweet'),(77,'Can change Tweet',26,'change_tweet'),(78,'Can delete Tweet',26,'delete_tweet'),(79,'Can add artist',27,'add_artist'),(80,'Can change artist',27,'change_artist'),(81,'Can delete artist',27,'delete_artist'),(82,'Can add audio',28,'add_audio'),(83,'Can change audio',28,'change_audio'),(84,'Can delete audio',28,'delete_audio'),(85,'Can add video',29,'add_video'),(86,'Can change video',29,'change_video'),(87,'Can delete video',29,'delete_video'),(88,'Can add playlist',30,'add_playlist'),(89,'Can change playlist',30,'change_playlist'),(90,'Can delete playlist',30,'delete_playlist'),(91,'Can add featured',31,'add_featured'),(92,'Can change featured',31,'change_featured'),(93,'Can delete featured',31,'delete_featured'),(94,'Can add video category',32,'add_videocategory'),(95,'Can change video category',32,'change_videocategory'),(96,'Can delete video category',32,'delete_videocategory'),(97,'Can add Event',33,'add_event'),(98,'Can change Event',33,'change_event'),(99,'Can delete Event',33,'delete_event'),(100,'Can add Event Location',34,'add_eventlocation'),(101,'Can change Event Location',34,'change_eventlocation'),(102,'Can delete Event Location',34,'delete_eventlocation'),(103,'Can add Event category',35,'add_eventcategory'),(104,'Can change Event category',35,'change_eventcategory'),(105,'Can delete Event category',35,'delete_eventcategory'),(106,'Can add Event price',36,'add_eventprice'),(107,'Can change Event price',36,'change_eventprice'),(108,'Can delete Event price',36,'delete_eventprice'),(109,'Can add log entry',37,'add_logentry'),(110,'Can change log entry',37,'change_logentry'),(111,'Can delete log entry',37,'delete_logentry'),(112,'Can add comment',38,'add_comment'),(113,'Can change comment',38,'change_comment'),(114,'Can delete comment',38,'delete_comment'),(115,'Can moderate comments',38,'can_moderate'),(116,'Can add comment flag',39,'add_commentflag'),(117,'Can change comment flag',39,'change_commentflag'),(118,'Can delete comment flag',39,'delete_commentflag'),(119,'Can add basic page',40,'add_basicpage'),(120,'Can change basic page',40,'change_basicpage'),(121,'Can delete basic page',40,'delete_basicpage'),(122,'Can add organization',41,'add_organization'),(123,'Can change organization',41,'change_organization'),(124,'Can delete organization',41,'delete_organization'),(125,'Can add organization type',42,'add_organizationtype'),(126,'Can change organization type',42,'change_organizationtype'),(127,'Can delete organization type',42,'delete_organizationtype'),(128,'Can add department',43,'add_department'),(129,'Can change department',43,'change_department'),(130,'Can delete department',43,'delete_department'),(131,'Can add team',44,'add_team'),(132,'Can change team',44,'change_team'),(133,'Can delete team',44,'delete_team'),(134,'Can add person',45,'add_person'),(135,'Can change person',45,'change_person'),(136,'Can delete person',45,'delete_person'),(137,'Can add link',46,'add_link'),(138,'Can change link',46,'change_link'),(139,'Can delete link',46,'delete_link'),(140,'Can add link type',47,'add_linktype'),(141,'Can change link type',47,'change_linktype'),(142,'Can delete link type',47,'delete_linktype'),(143,'Can add activity',48,'add_activity'),(144,'Can change activity',48,'change_activity'),(145,'Can delete activity',48,'delete_activity');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$24000$2z4yF1grRcyI$lNYDn2jkNncv+cfEbEW3KpFKr65ETWLI63nUToYGot4=','2016-07-05 13:46:07',1,'admin','','','root@example.com',1,1,'2016-06-20 09:53:54');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_97559544_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_97559544_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_6a12ed8b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_perm_permission_id_1fbb5f2c_fk_auth_permission_id` (`permission_id`),
  CONSTRAINT `auth_user_user_perm_permission_id_1fbb5f2c_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_blogcategory`
--

DROP TABLE IF EXISTS `blog_blogcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_blogcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  `title_en` varchar(500) DEFAULT NULL,
  `title_fr` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_blogcategory_site_id_42b9c96d_fk_django_site_id` (`site_id`),
  CONSTRAINT `blog_blogcategory_site_id_42b9c96d_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_blogcategory`
--

LOCK TABLES `blog_blogcategory` WRITE;
/*!40000 ALTER TABLE `blog_blogcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_blogcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_blogpost`
--

DROP TABLE IF EXISTS `blog_blogpost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_blogpost` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comments_count` int(11) NOT NULL,
  `keywords_string` varchar(500) NOT NULL,
  `rating_count` int(11) NOT NULL,
  `rating_sum` int(11) NOT NULL,
  `rating_average` double NOT NULL,
  `title` varchar(500) NOT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `_meta_title` varchar(500) DEFAULT NULL,
  `description` longtext NOT NULL,
  `gen_description` tinyint(1) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `status` int(11) NOT NULL,
  `publish_date` datetime DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `short_url` varchar(200) DEFAULT NULL,
  `in_sitemap` tinyint(1) NOT NULL,
  `content` longtext NOT NULL,
  `allow_comments` tinyint(1) NOT NULL,
  `featured_image` varchar(255) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `_meta_title_en` varchar(500) DEFAULT NULL,
  `_meta_title_fr` varchar(500) DEFAULT NULL,
  `content_en` longtext,
  `content_fr` longtext,
  `description_en` longtext,
  `description_fr` longtext,
  `title_en` varchar(500) DEFAULT NULL,
  `title_fr` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_blogpost_site_id_7995688f_fk_django_site_id` (`site_id`),
  KEY `blog_blogpost_user_id_12ed6b16_fk_auth_user_id` (`user_id`),
  KEY `blog_blogpost_publish_date_703abc16_uniq` (`publish_date`),
  CONSTRAINT `blog_blogpost_site_id_7995688f_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`),
  CONSTRAINT `blog_blogpost_user_id_12ed6b16_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_blogpost`
--

LOCK TABLES `blog_blogpost` WRITE;
/*!40000 ALTER TABLE `blog_blogpost` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_blogpost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_blogpost_categories`
--

DROP TABLE IF EXISTS `blog_blogpost_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_blogpost_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blogpost_id` int(11) NOT NULL,
  `blogcategory_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `blog_blogpost_categories_blogpost_id_a64d32c5_uniq` (`blogpost_id`,`blogcategory_id`),
  KEY `blog_blogpost_c_blogcategory_id_f6695246_fk_blog_blogcategory_id` (`blogcategory_id`),
  CONSTRAINT `blog_blogpost_c_blogcategory_id_f6695246_fk_blog_blogcategory_id` FOREIGN KEY (`blogcategory_id`) REFERENCES `blog_blogcategory` (`id`),
  CONSTRAINT `blog_blogpost_categorie_blogpost_id_daeea608_fk_blog_blogpost_id` FOREIGN KEY (`blogpost_id`) REFERENCES `blog_blogpost` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_blogpost_categories`
--

LOCK TABLES `blog_blogpost_categories` WRITE;
/*!40000 ALTER TABLE `blog_blogpost_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_blogpost_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_blogpost_related_posts`
--

DROP TABLE IF EXISTS `blog_blogpost_related_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_blogpost_related_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_blogpost_id` int(11) NOT NULL,
  `to_blogpost_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `blog_blogpost_related_posts_from_blogpost_id_3bd0f49f_uniq` (`from_blogpost_id`,`to_blogpost_id`),
  KEY `blog_blogpost_relate_to_blogpost_id_35f7acdd_fk_blog_blogpost_id` (`to_blogpost_id`),
  CONSTRAINT `blog_blogpost_rela_from_blogpost_id_27ea4c18_fk_blog_blogpost_id` FOREIGN KEY (`from_blogpost_id`) REFERENCES `blog_blogpost` (`id`),
  CONSTRAINT `blog_blogpost_relate_to_blogpost_id_35f7acdd_fk_blog_blogpost_id` FOREIGN KEY (`to_blogpost_id`) REFERENCES `blog_blogpost` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_blogpost_related_posts`
--

LOCK TABLES `blog_blogpost_related_posts` WRITE;
/*!40000 ALTER TABLE `blog_blogpost_related_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_blogpost_related_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conf_setting`
--

DROP TABLE IF EXISTS `conf_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conf_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `value` varchar(2000) NOT NULL,
  `site_id` int(11) NOT NULL,
  `value_en` varchar(2000) DEFAULT NULL,
  `value_fr` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `conf_setting_site_id_b235f7ed_fk_django_site_id` (`site_id`),
  CONSTRAINT `conf_setting_site_id_b235f7ed_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conf_setting`
--

LOCK TABLES `conf_setting` WRITE;
/*!40000 ALTER TABLE `conf_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `conf_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `core_sitepermission`
--

DROP TABLE IF EXISTS `core_sitepermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `core_sitepermission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `core_sitepermission_user_id_0a3cbb11_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `core_sitepermission`
--

LOCK TABLES `core_sitepermission` WRITE;
/*!40000 ALTER TABLE `core_sitepermission` DISABLE KEYS */;
/*!40000 ALTER TABLE `core_sitepermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `core_sitepermission_sites`
--

DROP TABLE IF EXISTS `core_sitepermission_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `core_sitepermission_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sitepermission_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `core_sitepermission_sites_sitepermission_id_e3e7353a_uniq` (`sitepermission_id`,`site_id`),
  KEY `core_sitepermission_sites_site_id_38038b76_fk_django_site_id` (`site_id`),
  CONSTRAINT `core_sitepe_sitepermission_id_d33bc79e_fk_core_sitepermission_id` FOREIGN KEY (`sitepermission_id`) REFERENCES `core_sitepermission` (`id`),
  CONSTRAINT `core_sitepermission_sites_site_id_38038b76_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `core_sitepermission_sites`
--

LOCK TABLES `core_sitepermission_sites` WRITE;
/*!40000 ALTER TABLE `core_sitepermission_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `core_sitepermission_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `custom_basicpage`
--

DROP TABLE IF EXISTS `custom_basicpage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `custom_basicpage` (
  `page_ptr_id` int(11) NOT NULL,
  `content` longtext NOT NULL,
  `sub_title` varchar(1000) NOT NULL,
  `sub_title_en` varchar(1000) DEFAULT NULL,
  `sub_title_fr` varchar(1000) DEFAULT NULL,
  `photo` varchar(1024) NOT NULL,
  `photo_alignment` varchar(32) NOT NULL,
  `photo_credits` varchar(255),
  `photo_description` longtext NOT NULL,
  `photo_featured` varchar(1024) NOT NULL,
  `photo_featured_credits` varchar(255),
  PRIMARY KEY (`page_ptr_id`),
  CONSTRAINT `custom_basicpage_page_ptr_id_d0f454e1_fk_pages_page_id` FOREIGN KEY (`page_ptr_id`) REFERENCES `pages_page` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `custom_basicpage`
--

LOCK TABLES `custom_basicpage` WRITE;
/*!40000 ALTER TABLE `custom_basicpage` DISABLE KEYS */;
INSERT INTO `custom_basicpage` VALUES (6,'<p>Vbi curarum abiectis ponderibus aliis tamquam nodum et codicem difficillimum Caesarem convellere nisu valido cogitabat, eique deliberanti cum proximis clandestinis conloquiis et nocturnis qua vi, quibusve commentis id fieret, antequam effundendis rebus pertinacius incumberet confidentia, acciri mollioribus scriptis per simulationem tractatus publici nimis urgentis eundem placuerat Gallum, ut auxilio destitutus sine ullo interiret obstaculo.</p>\n<p>Ex turba vero imae sortis et paupertinae in tabernis aliqui pernoctant vinariis, non nulli velariis umbraculorum theatralium latent, quae Campanam imitatus lasciviam Catulus in aedilitate sua suspendit omnium primus; aut pugnaciter aleis certant turpi sono fragosis naribus introrsum reducto spiritu concrepantes; aut quod est studiorum omnium maximum ab ortu lucis ad vesperam sole fatiscunt vel pluviis, per minutias aurigarum equorumque praecipua vel delicta scrutantes.</p>\n<p>Haec ubi latius fama vulgasset missaeque relationes adsiduae Gallum Caesarem permovissent, quoniam magister equitum longius ea tempestate distinebatur, iussus comes orientis Nebridius contractis undique militaribus copiis ad eximendam periculo civitatem amplam et oportunam studio properabat ingenti, quo cognito abscessere latrones nulla re amplius memorabili gesta, dispersique ut solent avia montium petiere celsorum.</p>','Ex turba vero imae sortis et paupertinae','','Ex turba vero imae sortis et paupertinae','uploads/images/photos/flower-197343_960_720.jpg','left','flower credits','flow description','uploads/images/photos/flower-631765_960_720.jpg','Photo featured credits'),(7,'<p>Vbi curarum abiectis ponderibus aliis tamquam nodum et codicem difficillimum Caesarem convellere nisu valido cogitabat, eique deliberanti cum proximis clandestinis conloquiis et nocturnis qua vi, quibusve commentis id fieret, antequam effundendis rebus pertinacius incumberet confidentia, acciri mollioribus scriptis per simulationem tractatus publici nimis urgentis eundem placuerat Gallum, ut auxilio destitutus sine ullo interiret obstaculo.</p>\n<p>Ex turba vero imae sortis et paupertinae in tabernis aliqui pernoctant vinariis, non nulli velariis umbraculorum theatralium latent, quae Campanam imitatus lasciviam Catulus in aedilitate sua suspendit omnium primus; aut pugnaciter aleis certant turpi sono fragosis naribus introrsum reducto spiritu concrepantes; aut quod est studiorum omnium maximum ab ortu lucis ad vesperam sole fatiscunt vel pluviis, per minutias aurigarum equorumque praecipua vel delicta scrutantes.</p>\n<p>Haec ubi latius fama vulgasset missaeque relationes adsiduae Gallum Caesarem permovissent, quoniam magister equitum longius ea tempestate distinebatur, iussus comes orientis Nebridius contractis undique militaribus copiis ad eximendam periculo civitatem amplam et oportunam studio properabat ingenti, quo cognito abscessere latrones nulla re amplius memorabili gesta, dispersique ut solent avia montium petiere celsorum.</p>','Vbi curarum abiectis ponderibus aliis tamquam','','Vbi curarum abiectis ponderibus aliis tamquam','','left',NULL,'','',NULL),(8,'<p>Vbi curarum abiectis ponderibus aliis tamquam nodum et codicem difficillimum Caesarem convellere nisu valido cogitabat, eique deliberanti cum proximis clandestinis conloquiis et nocturnis qua vi, quibusve commentis id fieret, antequam effundendis rebus pertinacius incumberet confidentia, acciri mollioribus scriptis per simulationem tractatus publici nimis urgentis eundem placuerat Gallum, ut auxilio destitutus sine ullo interiret obstaculo.</p>\n<p>Ex turba vero imae sortis et paupertinae in tabernis aliqui pernoctant vinariis, non nulli velariis umbraculorum theatralium latent, quae Campanam imitatus lasciviam Catulus in aedilitate sua suspendit omnium primus; aut pugnaciter aleis certant turpi sono fragosis naribus introrsum reducto spiritu concrepantes; aut quod est studiorum omnium maximum ab ortu lucis ad vesperam sole fatiscunt vel pluviis, per minutias aurigarum equorumque praecipua vel delicta scrutantes.</p>\n<p>Haec ubi latius fama vulgasset missaeque relationes adsiduae Gallum Caesarem permovissent, quoniam magister equitum longius ea tempestate distinebatur, iussus comes orientis Nebridius contractis undique militaribus copiis ad eximendam periculo civitatem amplam et oportunam studio properabat ingenti, quo cognito abscessere latrones nulla re amplius memorabili gesta, dispersique ut solent avia montium petiere celsorum.</p>','Haec ubi latius fama vulgasset missaeque','','Haec ubi latius fama vulgasset missaeque','','left',NULL,'','',NULL),(9,'<p>lorem</p>','','','','','left',NULL,'','',NULL),(10,'<p>lorem</p>','test','','test','','left','credit photo','photo description','','Photo featured credits:'),(11,'<p>lorem</p>','','','','','left',NULL,'','',NULL),(12,'<p>lorem</p>','','','','','left',NULL,'','',NULL),(13,'<p>Vbi curarum abiectis ponderibus aliis tamquam nodum et codicem difficillimum Caesarem convellere nisu valido cogitabat, eique deliberanti cum proximis clandestinis conloquiis et nocturnis qua vi, quibusve commentis id fieret, antequam effundendis rebus pertinacius incumberet confidentia, acciri mollioribus scriptis per simulationem tractatus publici nimis urgentis eundem placuerat Gallum, ut auxilio destitutus sine ullo interiret obstaculo.</p>\n<p>Ex turba vero imae sortis et paupertinae in tabernis aliqui pernoctant vinariis, non nulli velariis umbraculorum theatralium latent, quae Campanam imitatus lasciviam Catulus in aedilitate sua suspendit omnium primus; aut pugnaciter aleis certant turpi sono fragosis naribus introrsum reducto spiritu concrepantes; aut quod est studiorum omnium maximum ab ortu lucis ad vesperam sole fatiscunt vel pluviis, per minutias aurigarum equorumque praecipua vel delicta scrutantes.</p>\n<p>Haec ubi latius fama vulgasset missaeque relationes adsiduae Gallum Caesarem permovissent, quoniam magister equitum longius ea tempestate distinebatur, iussus comes orientis Nebridius contractis undique militaribus copiis ad eximendam periculo civitatem amplam et oportunam studio properabat ingenti, quo cognito abscessere latrones nulla re amplius memorabili gesta, dispersique ut solent avia montium petiere celsorum.</p>','Haec ubi latius fama vulgasset missaeque','','Haec ubi latius fama vulgasset missaeque','','left',NULL,'','',NULL),(14,'<p>lorem</p>','','','','','left',NULL,'','',NULL),(15,'<p>lorem</p>','','','','','left',NULL,'','',NULL),(16,'<p>lorem</p>','','','','','left',NULL,'','',NULL),(17,'<p>lorem</p>','','','','','left',NULL,'','',NULL),(18,'<p>lorem</p>','','','','','left',NULL,'','',NULL);
/*!40000 ALTER TABLE `custom_basicpage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin__content_type_id_c4bce8eb_fk_django_content_type_id` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6_fk_auth_user_id` (`user_id`),
  CONSTRAINT `django_admin__content_type_id_c4bce8eb_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_c564eba6_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2016-06-21 21:35:39','1','Recherche',1,'Ajout.',16,1),(2,'2016-06-21 21:36:25','2','Création',1,'Ajout.',16,1),(3,'2016-06-21 21:36:51','3','Transmission',1,'Ajout.',16,1),(4,'2016-06-21 21:37:30','4','Innovations',1,'Ajout.',16,1),(5,'2016-06-21 21:38:02','5','Rendez-vous 15/16',1,'Ajout.',16,1),(6,'2016-07-05 15:08:44','6','L\'ircam',1,'Added.',40,1),(7,'2016-07-05 15:09:09','7','réseaux',1,'Added.',40,1),(8,'2016-07-05 15:09:16','7','réseaux',2,'Changed in_menus and keywords.',40,1),(9,'2016-07-05 15:10:10','8','réserver',1,'Added.',40,1),(10,'2016-07-05 15:10:38','6','L\'ircam',2,'Changed content, sub_title_fr and keywords.',40,1),(11,'2016-07-05 15:10:57','7','réseaux',2,'Changed content, sub_title_fr and keywords.',40,1),(12,'2016-07-05 15:11:22','9','candidater',1,'Added.',40,1),(13,'2016-07-05 15:11:40','10','être informé',1,'Added.',40,1),(14,'2016-07-05 15:11:56','11','venir à l\'Ircam',1,'Added.',40,1),(15,'2016-07-05 15:12:13','12','vous êtes',1,'Added.',40,1),(16,'2016-07-05 15:13:06','13','Offres d\'emploi et de stage',1,'Added.',40,1),(17,'2016-07-05 15:13:24','14','Contacts / Equipes',1,'Added.',40,1),(18,'2016-07-05 15:13:39','15','Espace Pro',1,'Added.',40,1),(19,'2016-07-05 15:13:50','16','Partenaires',1,'Added.',40,1),(20,'2016-07-05 15:14:02','17','A propos',1,'Added.',40,1),(21,'2016-07-05 15:14:15','18','Plan du site',1,'Added.',40,1),(22,'2016-07-05 16:22:35','10','être informé',2,'Changed sub_title_fr, photo_credits, photo_description, photo_featured_credits and keywords.',40,1),(23,'2016-07-05 16:22:53','10','être informé',2,'Changed keywords.',40,1),(24,'2016-07-06 08:18:08','6','L\'ircam',2,'Changed content, photo, photo_credits, photo_description and keywords.',40,1),(25,'2016-07-06 09:54:37','6','L\'ircam',2,'Changed content, photo, photo_featured, photo_featured_credits and keywords.',40,1),(26,'2016-07-06 09:57:55','6','L\'ircam',2,'Changed content, photo, photo_featured and keywords.',40,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_comment_flags`
--

DROP TABLE IF EXISTS `django_comment_flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_comment_flags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `flag` varchar(30) NOT NULL,
  `flag_date` datetime NOT NULL,
  `comment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_comment_flags_user_id_537f77a7_uniq` (`user_id`,`comment_id`,`flag`),
  KEY `django_comment_flags_comment_id_d8054933_fk_django_comments_id` (`comment_id`),
  KEY `django_comment_flags_327a6c43` (`flag`),
  CONSTRAINT `django_comment_flags_comment_id_d8054933_fk_django_comments_id` FOREIGN KEY (`comment_id`) REFERENCES `django_comments` (`id`),
  CONSTRAINT `django_comment_flags_user_id_f3f81f0a_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_comment_flags`
--

LOCK TABLES `django_comment_flags` WRITE;
/*!40000 ALTER TABLE `django_comment_flags` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_comment_flags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_comments`
--

DROP TABLE IF EXISTS `django_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_pk` longtext NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_email` varchar(254) NOT NULL,
  `user_url` varchar(200) NOT NULL,
  `comment` longtext NOT NULL,
  `submit_date` datetime NOT NULL,
  `ip_address` char(39) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL,
  `is_removed` tinyint(1) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `django_commen_content_type_id_c4afe962_fk_django_content_type_id` (`content_type_id`),
  KEY `django_comments_site_id_9dcf666e_fk_django_site_id` (`site_id`),
  KEY `django_comments_user_id_a0a440a1_fk_auth_user_id` (`user_id`),
  KEY `django_comments_submit_date_514ed2d9_uniq` (`submit_date`),
  CONSTRAINT `django_commen_content_type_id_c4afe962_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_comments_site_id_9dcf666e_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`),
  CONSTRAINT `django_comments_user_id_a0a440a1_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_comments`
--

LOCK TABLES `django_comments` WRITE;
/*!40000 ALTER TABLE `django_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (37,'admin','logentry'),(2,'auth','group'),(1,'auth','permission'),(3,'auth','user'),(18,'blog','blogcategory'),(17,'blog','blogpost'),(8,'conf','setting'),(4,'contenttypes','contenttype'),(9,'core','sitepermission'),(40,'custom','basicpage'),(38,'django_comments','comment'),(39,'django_comments','commentflag'),(27,'festival','artist'),(28,'festival','audio'),(31,'festival','featured'),(30,'festival','playlist'),(29,'festival','video'),(32,'festival','videocategory'),(20,'forms','field'),(22,'forms','fieldentry'),(19,'forms','form'),(21,'forms','formentry'),(23,'galleries','gallery'),(24,'galleries','galleryimage'),(12,'generic','assignedkeyword'),(11,'generic','keyword'),(13,'generic','rating'),(10,'generic','threadedcomment'),(33,'mezzanine_agenda','event'),(35,'mezzanine_agenda','eventcategory'),(34,'mezzanine_agenda','eventlocation'),(36,'mezzanine_agenda','eventprice'),(48,'organization','activity'),(43,'organization','department'),(46,'organization','link'),(47,'organization','linktype'),(41,'organization','organization'),(42,'organization','organizationtype'),(45,'organization','person'),(44,'organization','team'),(16,'pages','link'),(14,'pages','page'),(15,'pages','richtextpage'),(5,'redirects','redirect'),(6,'sessions','session'),(7,'sites','site'),(25,'twitter','query'),(26,'twitter','tweet');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=84 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2016-06-20 09:53:04'),(2,'auth','0001_initial','2016-06-20 09:53:07'),(3,'admin','0001_initial','2016-06-20 09:53:08'),(4,'admin','0002_logentry_remove_auto_add','2016-06-20 09:53:08'),(5,'contenttypes','0002_remove_content_type_name','2016-06-20 09:53:08'),(6,'auth','0002_alter_permission_name_max_length','2016-06-20 09:53:09'),(7,'auth','0003_alter_user_email_max_length','2016-06-20 09:53:09'),(8,'auth','0004_alter_user_username_opts','2016-06-20 09:53:09'),(9,'auth','0005_alter_user_last_login_null','2016-06-20 09:53:09'),(10,'auth','0006_require_contenttypes_0002','2016-06-20 09:53:09'),(11,'auth','0007_alter_validators_add_error_messages','2016-06-20 09:53:09'),(12,'sites','0001_initial','2016-06-20 09:53:09'),(13,'blog','0001_initial','2016-06-20 09:53:11'),(14,'blog','0002_auto_20150527_1555','2016-06-20 09:53:11'),(15,'blog','0003_auto_20151223_1313','2016-06-20 09:53:12'),(16,'conf','0001_initial','2016-06-20 09:53:13'),(17,'conf','0002_auto_20151223_1313','2016-06-20 09:53:13'),(18,'core','0001_initial','2016-06-20 09:53:14'),(19,'core','0002_auto_20150414_2140','2016-06-20 09:53:14'),(20,'django_comments','0001_initial','2016-06-20 09:53:15'),(21,'django_comments','0002_update_user_email_field_length','2016-06-20 09:53:15'),(22,'django_comments','0003_add_submit_date_index','2016-06-20 09:53:15'),(23,'sites','0002_alter_domain_unique','2016-06-20 09:53:15'),(24,'pages','0001_initial','2016-06-20 09:53:16'),(25,'pages','0002_auto_20141227_0224','2016-06-20 09:53:17'),(26,'pages','0003_auto_20150527_1555','2016-06-20 09:53:17'),(27,'pages','0004_auto_20151223_1313','2016-06-20 09:53:19'),(28,'mezzanine_agenda','0001_initial','2016-06-20 09:53:20'),(29,'mezzanine_agenda','0002_auto_20160224_1142','2016-06-20 09:53:20'),(30,'mezzanine_agenda','0003_auto_20160309_1621','2016-06-20 09:53:23'),(31,'mezzanine_agenda','0004_auto_20160331_1832','2016-06-20 09:53:23'),(32,'mezzanine_agenda','0005_auto_20160404_0043','2016-06-20 09:53:23'),(33,'mezzanine_agenda','0006_remove_event_featured','2016-06-20 09:53:23'),(34,'festival','0001_initial','2016-06-20 09:53:24'),(35,'festival','0002_auto_20160225_1602','2016-06-20 09:53:25'),(36,'festival','0003_auto_20160229_1430','2016-06-20 09:53:25'),(37,'festival','0004_auto_20160229_1630','2016-06-20 09:53:25'),(38,'festival','0005_auto_20160229_1636','2016-06-20 09:53:25'),(39,'festival','0006_auto_20160303_1442','2016-06-20 09:53:26'),(40,'festival','0007_auto_20160309_1441','2016-06-20 09:53:26'),(41,'festival','0008_auto_20160322_0018','2016-06-20 09:53:27'),(42,'festival','0009_auto_20160322_0021','2016-06-20 09:53:28'),(43,'festival','0010_playlist','2016-06-20 09:53:29'),(44,'festival','0011_auto_20160323_1159','2016-06-20 09:53:29'),(45,'festival','0012_auto_20160405_2351','2016-06-20 09:53:29'),(46,'festival','0013_auto_20160407_1432','2016-06-20 09:53:30'),(47,'festival','0014_auto_20160407_1433','2016-06-20 09:53:30'),(48,'festival','0015_auto_20160407_2249','2016-06-20 09:53:34'),(49,'festival','0016_auto_20160407_2255','2016-06-20 09:53:34'),(50,'festival','0017_auto_20160407_2256','2016-06-20 09:53:35'),(51,'festival','0018_auto_20160407_2301','2016-06-20 09:53:35'),(52,'festival','0019_auto_20160410_2148','2016-06-20 09:53:35'),(53,'festival','0020_auto_20160421_1059','2016-06-20 09:53:36'),(54,'festival','0021_delete_pagecategory','2016-06-20 09:53:36'),(55,'festival','0022_auto_20160517_1457','2016-06-20 09:53:37'),(56,'forms','0001_initial','2016-06-20 09:53:38'),(57,'forms','0002_auto_20141227_0224','2016-06-20 09:53:38'),(58,'forms','0003_emailfield','2016-06-20 09:53:39'),(59,'forms','0004_auto_20150517_0510','2016-06-20 09:53:39'),(60,'forms','0005_auto_20151223_1313','2016-06-20 09:53:42'),(61,'forms','0006_auto_20160407_2249','2016-06-20 09:53:42'),(62,'galleries','0001_initial','2016-06-20 09:53:42'),(63,'galleries','0002_auto_20141227_0224','2016-06-20 09:53:42'),(64,'galleries','0003_auto_20151223_1313','2016-06-20 09:53:43'),(65,'generic','0001_initial','2016-06-20 09:53:45'),(66,'generic','0002_auto_20141227_0224','2016-06-20 09:53:45'),(67,'mezzanine_agenda','0007_auto_20160410_2148','2016-06-20 09:53:46'),(68,'mezzanine_agenda','0008_auto_20160410_2149','2016-06-20 09:53:46'),(69,'mezzanine_agenda','0009_auto_20160410_2154','2016-06-20 09:53:46'),(70,'mezzanine_agenda','0010_eventlocation_external_id','2016-06-20 09:53:47'),(71,'mezzanine_agenda','0011_auto_20160410_2330','2016-06-20 09:53:47'),(72,'mezzanine_agenda','0012_auto_20160410_2336','2016-06-20 09:53:47'),(73,'mezzanine_agenda','0013_auto_20160510_1542','2016-06-20 09:53:48'),(74,'mezzanine_agenda','0014_event_brochure','2016-06-20 09:53:48'),(75,'redirects','0001_initial','2016-06-20 09:53:49'),(76,'sessions','0001_initial','2016-06-20 09:53:49'),(77,'twitter','0001_initial','2016-06-20 09:53:50'),(78,'custom','0001_initial','2016-07-05 13:58:32'),(80,'organization','0001_initial','2016-07-05 14:10:50'),(81,'custom','0002_auto_20160705_1559','2016-07-05 14:15:30'),(82,'custom','0003_auto_20160705_1702','2016-07-05 15:02:39'),(83,'custom','0004_auto_20160705_1810','2016-07-05 16:10:54');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_redirect`
--

DROP TABLE IF EXISTS `django_redirect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_redirect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `old_path` varchar(200) NOT NULL,
  `new_path` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_redirect_site_id_ac5dd16b_uniq` (`site_id`,`old_path`),
  KEY `django_redirect_91a0b591` (`old_path`),
  CONSTRAINT `django_redirect_site_id_c3e37341_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_redirect`
--

LOCK TABLES `django_redirect` WRITE;
/*!40000 ALTER TABLE `django_redirect` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_redirect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_de54fa62` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('3yjzvx7gxnq0p5jr5dkmuguufdbhzj5r','ZjYwMzg5ZDA0ZDA5MWI4ZGRhODZhZGE0NTZlMjAxOGMzN2ZiYTcxODp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6IjE1ZjdjZGY0ZWU1ZWJkMTU0ZmM4MGQ0N2VjYmJmNmE3MjRkMWQxMzciLCJfYXV0aF91c2VyX2lkIjoiMSJ9','2016-07-05 21:18:34'),('ip87zs48hc74etnzmarlputdis279hx4','ZTQ2NzQzNTQ0NDM3NzczODYwY2NjMzM3MzM3YjBmNThiYzUxMWI3ZTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9oYXNoIjoiMTVmN2NkZjRlZTVlYmQxNTRmYzgwZDQ3ZWNiYmY2YTcyNGQxZDEzNyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCJ9','2016-07-19 13:46:08'),('kma555z0eistn1p7mzy7mut26njls5os','ZTQ2NzQzNTQ0NDM3NzczODYwY2NjMzM3MzM3YjBmNThiYzUxMWI3ZTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9oYXNoIjoiMTVmN2NkZjRlZTVlYmQxNTRmYzgwZDQ3ZWNiYmY2YTcyNGQxZDEzNyIsIl9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCJ9','2016-07-04 11:36:42');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_site`
--

DROP TABLE IF EXISTS `django_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_site_domain_a2e37b91_uniq` (`domain`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_site`
--

LOCK TABLES `django_site` WRITE;
/*!40000 ALTER TABLE `django_site` DISABLE KEYS */;
INSERT INTO `django_site` VALUES (1,'example.com','example.com');
/*!40000 ALTER TABLE `django_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_artists`
--

DROP TABLE IF EXISTS `festival_artists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_artists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keywords_string` varchar(500) NOT NULL,
  `title` varchar(500) NOT NULL,
  `title_fr` varchar(500) DEFAULT NULL,
  `title_en` varchar(500) DEFAULT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `_meta_title` varchar(500) DEFAULT NULL,
  `description` longtext NOT NULL,
  `description_fr` longtext,
  `description_en` longtext,
  `gen_description` tinyint(1) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `status` int(11) NOT NULL,
  `publish_date` datetime DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `short_url` varchar(200) DEFAULT NULL,
  `in_sitemap` tinyint(1) NOT NULL,
  `content` longtext NOT NULL,
  `content_fr` longtext,
  `content_en` longtext,
  `bio` longtext NOT NULL,
  `bio_fr` longtext,
  `bio_en` longtext,
  `photo` varchar(1024) NOT NULL,
  `photo_credits` varchar(255) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  `photo_description` longtext NOT NULL,
  `photo_alignment` varchar(32) NOT NULL,
  `photo_featured` varchar(1024) NOT NULL,
  `photo_featured_credits` varchar(255) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `festival_artists_site_id_50fdeb52_fk_django_site_id` (`site_id`),
  KEY `festival_artists_76776489` (`publish_date`),
  CONSTRAINT `festival_artists_site_id_50fdeb52_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_artists`
--

LOCK TABLES `festival_artists` WRITE;
/*!40000 ALTER TABLE `festival_artists` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_artists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_artists_events`
--

DROP TABLE IF EXISTS `festival_artists_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_artists_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `artist_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `festival_artists_events_artist_id_7a228fd9_uniq` (`artist_id`,`event_id`),
  KEY `festival_artists__event_id_c8615747_fk_mezzanine_agenda_event_id` (`event_id`),
  CONSTRAINT `festival_artists__event_id_c8615747_fk_mezzanine_agenda_event_id` FOREIGN KEY (`event_id`) REFERENCES `mezzanine_agenda_event` (`id`),
  CONSTRAINT `festival_artists_event_artist_id_833ca1d3_fk_festival_artists_id` FOREIGN KEY (`artist_id`) REFERENCES `festival_artists` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_artists_events`
--

LOCK TABLES `festival_artists_events` WRITE;
/*!40000 ALTER TABLE `festival_artists_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_artists_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_audios`
--

DROP TABLE IF EXISTS `festival_audios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_audios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keywords_string` varchar(500) NOT NULL,
  `title` varchar(500) NOT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `_meta_title` varchar(500) DEFAULT NULL,
  `description` longtext NOT NULL,
  `gen_description` tinyint(1) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `status` int(11) NOT NULL,
  `publish_date` datetime DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `short_url` varchar(200) DEFAULT NULL,
  `in_sitemap` tinyint(1) NOT NULL,
  `content` longtext NOT NULL,
  `media_id` varchar(128) NOT NULL,
  `open_source_url` varchar(1024) NOT NULL,
  `closed_source_url` varchar(1024) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  `content_en` longtext,
  `content_fr` longtext,
  `description_en` longtext,
  `description_fr` longtext,
  `title_en` varchar(500) DEFAULT NULL,
  `title_fr` varchar(500) DEFAULT NULL,
  `poster_url` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `festival_audios_event_id_a27b685f_fk_mezzanine_agenda_event_id` (`event_id`),
  KEY `festival_audios_site_id_1fed3780_fk_django_site_id` (`site_id`),
  KEY `festival_audios_76776489` (`publish_date`),
  CONSTRAINT `festival_audios_event_id_a27b685f_fk_mezzanine_agenda_event_id` FOREIGN KEY (`event_id`) REFERENCES `mezzanine_agenda_event` (`id`),
  CONSTRAINT `festival_audios_site_id_1fed3780_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_audios`
--

LOCK TABLES `festival_audios` WRITE;
/*!40000 ALTER TABLE `festival_audios` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_audios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_audios_artists`
--

DROP TABLE IF EXISTS `festival_audios_artists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_audios_artists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `audio_id` int(11) NOT NULL,
  `artist_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `festival_audios_artists_audio_id_76a1f2bf_uniq` (`audio_id`,`artist_id`),
  KEY `festival_audios_artist_artist_id_36ce2489_fk_festival_artists_id` (`artist_id`),
  CONSTRAINT `festival_audios_artist_artist_id_36ce2489_fk_festival_artists_id` FOREIGN KEY (`artist_id`) REFERENCES `festival_artists` (`id`),
  CONSTRAINT `festival_audios_artists_audio_id_2ff0e9c8_fk_festival_audios_id` FOREIGN KEY (`audio_id`) REFERENCES `festival_audios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_audios_artists`
--

LOCK TABLES `festival_audios_artists` WRITE;
/*!40000 ALTER TABLE `festival_audios_artists` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_audios_artists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_featured`
--

DROP TABLE IF EXISTS `festival_featured`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_featured` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  `description` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_featured`
--

LOCK TABLES `festival_featured` WRITE;
/*!40000 ALTER TABLE `festival_featured` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_featured` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_featured_artists`
--

DROP TABLE IF EXISTS `festival_featured_artists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_featured_artists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `featured_id` int(11) NOT NULL,
  `artist_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `festival_featured_artists_featured_id_d3ea1a8f_uniq` (`featured_id`,`artist_id`),
  KEY `festival_featured_arti_artist_id_d06f2766_fk_festival_artists_id` (`artist_id`),
  CONSTRAINT `festival_featured_a_featured_id_dc7a42c5_fk_festival_featured_id` FOREIGN KEY (`featured_id`) REFERENCES `festival_featured` (`id`),
  CONSTRAINT `festival_featured_arti_artist_id_d06f2766_fk_festival_artists_id` FOREIGN KEY (`artist_id`) REFERENCES `festival_artists` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_featured_artists`
--

LOCK TABLES `festival_featured_artists` WRITE;
/*!40000 ALTER TABLE `festival_featured_artists` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_featured_artists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_featured_blogposts`
--

DROP TABLE IF EXISTS `festival_featured_blogposts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_featured_blogposts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `featured_id` int(11) NOT NULL,
  `blogpost_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `festival_featured_blogpost_featured_id_49f8847b_uniq` (`featured_id`,`blogpost_id`),
  KEY `festival_featured_blogp_blogpost_id_2e026bb2_fk_blog_blogpost_id` (`blogpost_id`),
  CONSTRAINT `festival_featured_b_featured_id_aae89f8a_fk_festival_featured_id` FOREIGN KEY (`featured_id`) REFERENCES `festival_featured` (`id`),
  CONSTRAINT `festival_featured_blogp_blogpost_id_2e026bb2_fk_blog_blogpost_id` FOREIGN KEY (`blogpost_id`) REFERENCES `blog_blogpost` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_featured_blogposts`
--

LOCK TABLES `festival_featured_blogposts` WRITE;
/*!40000 ALTER TABLE `festival_featured_blogposts` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_featured_blogposts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_featured_events`
--

DROP TABLE IF EXISTS `festival_featured_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_featured_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `featured_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `festival_featured_events_featured_id_de69ea4c_uniq` (`featured_id`,`event_id`),
  KEY `festival_featured_event_id_8d271d48_fk_mezzanine_agenda_event_id` (`event_id`),
  CONSTRAINT `festival_featured_e_featured_id_3ad1f022_fk_festival_featured_id` FOREIGN KEY (`featured_id`) REFERENCES `festival_featured` (`id`),
  CONSTRAINT `festival_featured_event_id_8d271d48_fk_mezzanine_agenda_event_id` FOREIGN KEY (`event_id`) REFERENCES `mezzanine_agenda_event` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_featured_events`
--

LOCK TABLES `festival_featured_events` WRITE;
/*!40000 ALTER TABLE `festival_featured_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_featured_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_featured_pages`
--

DROP TABLE IF EXISTS `festival_featured_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_featured_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `featured_id` int(11) NOT NULL,
  `page_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `festival_featured_page_featured_id_8988bf55_uniq` (`featured_id`,`page_id`),
  KEY `festival_featured_pages_page_id_e92a7221_fk_pages_page_id` (`page_id`),
  CONSTRAINT `festival_featured_p_featured_id_b055f56f_fk_festival_featured_id` FOREIGN KEY (`featured_id`) REFERENCES `festival_featured` (`id`),
  CONSTRAINT `festival_featured_pages_page_id_e92a7221_fk_pages_page_id` FOREIGN KEY (`page_id`) REFERENCES `pages_page` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_featured_pages`
--

LOCK TABLES `festival_featured_pages` WRITE;
/*!40000 ALTER TABLE `festival_featured_pages` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_featured_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_featured_playlists`
--

DROP TABLE IF EXISTS `festival_featured_playlists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_featured_playlists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `featured_id` int(11) NOT NULL,
  `playlist_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `festival_featured_playlists_featured_id_aa10c909_uniq` (`featured_id`,`playlist_id`),
  KEY `festival_featured_p_playlist_id_d092170f_fk_festival_playlist_id` (`playlist_id`),
  CONSTRAINT `festival_featured_p_featured_id_c9be5886_fk_festival_featured_id` FOREIGN KEY (`featured_id`) REFERENCES `festival_featured` (`id`),
  CONSTRAINT `festival_featured_p_playlist_id_d092170f_fk_festival_playlist_id` FOREIGN KEY (`playlist_id`) REFERENCES `festival_playlist` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_featured_playlists`
--

LOCK TABLES `festival_featured_playlists` WRITE;
/*!40000 ALTER TABLE `festival_featured_playlists` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_featured_playlists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_featured_videos`
--

DROP TABLE IF EXISTS `festival_featured_videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_featured_videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `featured_id` int(11) NOT NULL,
  `video_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `festival_featured_videos_featured_id_96398d4a_uniq` (`featured_id`,`video_id`),
  KEY `festival_featured_videos_video_id_d75fa16e_fk_festival_videos_id` (`video_id`),
  CONSTRAINT `festival_featured_v_featured_id_c3604d25_fk_festival_featured_id` FOREIGN KEY (`featured_id`) REFERENCES `festival_featured` (`id`),
  CONSTRAINT `festival_featured_videos_video_id_d75fa16e_fk_festival_videos_id` FOREIGN KEY (`video_id`) REFERENCES `festival_videos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_featured_videos`
--

LOCK TABLES `festival_featured_videos` WRITE;
/*!40000 ALTER TABLE `festival_featured_videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_featured_videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_playlist`
--

DROP TABLE IF EXISTS `festival_playlist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_playlist` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(512) NOT NULL,
  `description` longtext NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `festival_playlist_event_id_a78e4e6a_fk_mezzanine_agenda_event_id` (`event_id`),
  CONSTRAINT `festival_playlist_event_id_a78e4e6a_fk_mezzanine_agenda_event_id` FOREIGN KEY (`event_id`) REFERENCES `mezzanine_agenda_event` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_playlist`
--

LOCK TABLES `festival_playlist` WRITE;
/*!40000 ALTER TABLE `festival_playlist` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_playlist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_playlist_audios`
--

DROP TABLE IF EXISTS `festival_playlist_audios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_playlist_audios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `playlist_id` int(11) NOT NULL,
  `audio_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `festival_playlist_audios_playlist_id_60cf8a36_uniq` (`playlist_id`,`audio_id`),
  KEY `festival_playlist_audios_audio_id_409d0de7_fk_festival_audios_id` (`audio_id`),
  CONSTRAINT `festival_playlist_a_playlist_id_715e85b2_fk_festival_playlist_id` FOREIGN KEY (`playlist_id`) REFERENCES `festival_playlist` (`id`),
  CONSTRAINT `festival_playlist_audios_audio_id_409d0de7_fk_festival_audios_id` FOREIGN KEY (`audio_id`) REFERENCES `festival_audios` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_playlist_audios`
--

LOCK TABLES `festival_playlist_audios` WRITE;
/*!40000 ALTER TABLE `festival_playlist_audios` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_playlist_audios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_video_category`
--

DROP TABLE IF EXISTS `festival_video_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_video_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `festival_video_category_site_id_63fcd2e1_fk_django_site_id` (`site_id`),
  CONSTRAINT `festival_video_category_site_id_63fcd2e1_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_video_category`
--

LOCK TABLES `festival_video_category` WRITE;
/*!40000 ALTER TABLE `festival_video_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_video_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_videos`
--

DROP TABLE IF EXISTS `festival_videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keywords_string` varchar(500) NOT NULL,
  `title` varchar(500) NOT NULL,
  `title_fr` varchar(500) DEFAULT NULL,
  `title_en` varchar(500) DEFAULT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `_meta_title` varchar(500) DEFAULT NULL,
  `description` longtext NOT NULL,
  `description_fr` longtext,
  `description_en` longtext,
  `gen_description` tinyint(1) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `status` int(11) NOT NULL,
  `publish_date` datetime DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `short_url` varchar(200) DEFAULT NULL,
  `in_sitemap` tinyint(1) NOT NULL,
  `content` longtext NOT NULL,
  `content_fr` longtext,
  `content_en` longtext,
  `media_id` varchar(128) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  `closed_source_url` varchar(1024) NOT NULL,
  `open_source_url` varchar(1024) NOT NULL,
  `poster_url` varchar(1024) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `festival_video_event_id_8e3fd88d_fk_mezzanine_agenda_event_id` (`event_id`),
  KEY `festival_video_site_id_6702cf38_fk_django_site_id` (`site_id`),
  KEY `festival_video_76776489` (`publish_date`),
  KEY `festival_videos_b583a629` (`category_id`),
  CONSTRAINT `festival_vide_category_id_958ff9c1_fk_festival_video_category_id` FOREIGN KEY (`category_id`) REFERENCES `festival_video_category` (`id`),
  CONSTRAINT `festival_video_event_id_8e3fd88d_fk_mezzanine_agenda_event_id` FOREIGN KEY (`event_id`) REFERENCES `mezzanine_agenda_event` (`id`),
  CONSTRAINT `festival_video_site_id_6702cf38_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_videos`
--

LOCK TABLES `festival_videos` WRITE;
/*!40000 ALTER TABLE `festival_videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_videos_artists`
--

DROP TABLE IF EXISTS `festival_videos_artists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_videos_artists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `video_id` int(11) NOT NULL,
  `artist_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `festival_videos_artists_video_id_95e42728_uniq` (`video_id`,`artist_id`),
  KEY `festival_videos_artist_artist_id_2f90187b_fk_festival_artists_id` (`artist_id`),
  CONSTRAINT `festival_videos_artist_artist_id_2f90187b_fk_festival_artists_id` FOREIGN KEY (`artist_id`) REFERENCES `festival_artists` (`id`),
  CONSTRAINT `festival_videos_artists_video_id_b11ed9e9_fk_festival_videos_id` FOREIGN KEY (`video_id`) REFERENCES `festival_videos` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_videos_artists`
--

LOCK TABLES `festival_videos_artists` WRITE;
/*!40000 ALTER TABLE `festival_videos_artists` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_videos_artists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_field`
--

DROP TABLE IF EXISTS `forms_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `_order` int(11) DEFAULT NULL,
  `label` varchar(200) NOT NULL,
  `field_type` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  `choices` varchar(1000) NOT NULL,
  `default` varchar(2000) NOT NULL,
  `placeholder_text` varchar(100) NOT NULL,
  `help_text` varchar(100) NOT NULL,
  `form_id` int(11) NOT NULL,
  `choices_en` varchar(1000) DEFAULT NULL,
  `choices_fr` varchar(1000) DEFAULT NULL,
  `default_en` varchar(2000) DEFAULT NULL,
  `default_fr` varchar(2000) DEFAULT NULL,
  `help_text_en` varchar(100) DEFAULT NULL,
  `help_text_fr` varchar(100) DEFAULT NULL,
  `label_en` varchar(200) DEFAULT NULL,
  `label_fr` varchar(200) DEFAULT NULL,
  `placeholder_text_en` varchar(100) DEFAULT NULL,
  `placeholder_text_fr` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `forms_field_d6cba1ad` (`form_id`),
  CONSTRAINT `forms_field_form_id_9ca5dc7e_fk_forms_form_page_ptr_id` FOREIGN KEY (`form_id`) REFERENCES `forms_form` (`page_ptr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_field`
--

LOCK TABLES `forms_field` WRITE;
/*!40000 ALTER TABLE `forms_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_fieldentry`
--

DROP TABLE IF EXISTS `forms_fieldentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_fieldentry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_id` int(11) NOT NULL,
  `value` varchar(2000) DEFAULT NULL,
  `entry_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `forms_fieldentry_b64a62ea` (`entry_id`),
  CONSTRAINT `forms_fieldentry_entry_id_c4fdc570_fk_forms_formentry_id` FOREIGN KEY (`entry_id`) REFERENCES `forms_formentry` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_fieldentry`
--

LOCK TABLES `forms_fieldentry` WRITE;
/*!40000 ALTER TABLE `forms_fieldentry` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_fieldentry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_form`
--

DROP TABLE IF EXISTS `forms_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_form` (
  `page_ptr_id` int(11) NOT NULL,
  `content` longtext NOT NULL,
  `button_text` varchar(50) NOT NULL,
  `response` longtext NOT NULL,
  `send_email` tinyint(1) NOT NULL,
  `email_from` varchar(254) NOT NULL,
  `email_copies` varchar(200) NOT NULL,
  `email_subject` varchar(200) NOT NULL,
  `email_message` longtext NOT NULL,
  `button_text_en` varchar(50) DEFAULT NULL,
  `button_text_fr` varchar(50) DEFAULT NULL,
  `content_en` longtext,
  `content_fr` longtext,
  `email_message_en` longtext,
  `email_message_fr` longtext,
  `email_subject_en` varchar(200) DEFAULT NULL,
  `email_subject_fr` varchar(200) DEFAULT NULL,
  `response_en` longtext,
  `response_fr` longtext,
  PRIMARY KEY (`page_ptr_id`),
  CONSTRAINT `forms_form_page_ptr_id_d3bcbf3a_fk_pages_page_id` FOREIGN KEY (`page_ptr_id`) REFERENCES `pages_page` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_form`
--

LOCK TABLES `forms_form` WRITE;
/*!40000 ALTER TABLE `forms_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_formentry`
--

DROP TABLE IF EXISTS `forms_formentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_formentry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_time` datetime NOT NULL,
  `form_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `forms_formentry_form_id_d0f23912_fk_forms_form_page_ptr_id` (`form_id`),
  CONSTRAINT `forms_formentry_form_id_d0f23912_fk_forms_form_page_ptr_id` FOREIGN KEY (`form_id`) REFERENCES `forms_form` (`page_ptr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_formentry`
--

LOCK TABLES `forms_formentry` WRITE;
/*!40000 ALTER TABLE `forms_formentry` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_formentry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `galleries_gallery`
--

DROP TABLE IF EXISTS `galleries_gallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `galleries_gallery` (
  `page_ptr_id` int(11) NOT NULL,
  `content` longtext NOT NULL,
  `zip_import` varchar(100) NOT NULL,
  `content_en` longtext,
  `content_fr` longtext,
  PRIMARY KEY (`page_ptr_id`),
  CONSTRAINT `galleries_gallery_page_ptr_id_8562ba87_fk_pages_page_id` FOREIGN KEY (`page_ptr_id`) REFERENCES `pages_page` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `galleries_gallery`
--

LOCK TABLES `galleries_gallery` WRITE;
/*!40000 ALTER TABLE `galleries_gallery` DISABLE KEYS */;
/*!40000 ALTER TABLE `galleries_gallery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `galleries_galleryimage`
--

DROP TABLE IF EXISTS `galleries_galleryimage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `galleries_galleryimage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `_order` int(11) DEFAULT NULL,
  `file` varchar(200) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `gallery_id` int(11) NOT NULL,
  `description_en` varchar(1000) DEFAULT NULL,
  `description_fr` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `galleries_g_gallery_id_af12d3f5_fk_galleries_gallery_page_ptr_id` (`gallery_id`),
  CONSTRAINT `galleries_g_gallery_id_af12d3f5_fk_galleries_gallery_page_ptr_id` FOREIGN KEY (`gallery_id`) REFERENCES `galleries_gallery` (`page_ptr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `galleries_galleryimage`
--

LOCK TABLES `galleries_galleryimage` WRITE;
/*!40000 ALTER TABLE `galleries_galleryimage` DISABLE KEYS */;
/*!40000 ALTER TABLE `galleries_galleryimage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_assignedkeyword`
--

DROP TABLE IF EXISTS `generic_assignedkeyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generic_assignedkeyword` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `_order` int(11) DEFAULT NULL,
  `object_pk` int(11) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `keyword_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `generic_assig_content_type_id_3dd89a7f_fk_django_content_type_id` (`content_type_id`),
  KEY `generic_assignedkeyword_5c003bba` (`keyword_id`),
  CONSTRAINT `generic_assig_content_type_id_3dd89a7f_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `generic_assignedkeywor_keyword_id_44c17f9d_fk_generic_keyword_id` FOREIGN KEY (`keyword_id`) REFERENCES `generic_keyword` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_assignedkeyword`
--

LOCK TABLES `generic_assignedkeyword` WRITE;
/*!40000 ALTER TABLE `generic_assignedkeyword` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_assignedkeyword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_keyword`
--

DROP TABLE IF EXISTS `generic_keyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generic_keyword` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `generic_keyword_site_id_c5be0acc_fk_django_site_id` (`site_id`),
  CONSTRAINT `generic_keyword_site_id_c5be0acc_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_keyword`
--

LOCK TABLES `generic_keyword` WRITE;
/*!40000 ALTER TABLE `generic_keyword` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_keyword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_rating`
--

DROP TABLE IF EXISTS `generic_rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generic_rating` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` int(11) NOT NULL,
  `rating_date` datetime DEFAULT NULL,
  `object_pk` int(11) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `generic_ratin_content_type_id_eaf475fa_fk_django_content_type_id` (`content_type_id`),
  KEY `generic_rating_user_id_60020469_fk_auth_user_id` (`user_id`),
  CONSTRAINT `generic_ratin_content_type_id_eaf475fa_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `generic_rating_user_id_60020469_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_rating`
--

LOCK TABLES `generic_rating` WRITE;
/*!40000 ALTER TABLE `generic_rating` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_threadedcomment`
--

DROP TABLE IF EXISTS `generic_threadedcomment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generic_threadedcomment` (
  `comment_ptr_id` int(11) NOT NULL,
  `rating_count` int(11) NOT NULL,
  `rating_sum` int(11) NOT NULL,
  `rating_average` double NOT NULL,
  `by_author` tinyint(1) NOT NULL,
  `replied_to_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`comment_ptr_id`),
  KEY `D5c2cbe5d32cde8f103bcc4ab6ba0d0b` (`replied_to_id`),
  CONSTRAINT `D5c2cbe5d32cde8f103bcc4ab6ba0d0b` FOREIGN KEY (`replied_to_id`) REFERENCES `generic_threadedcomment` (`comment_ptr_id`),
  CONSTRAINT `generic_threadedco_comment_ptr_id_e208ed60_fk_django_comments_id` FOREIGN KEY (`comment_ptr_id`) REFERENCES `django_comments` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_threadedcomment`
--

LOCK TABLES `generic_threadedcomment` WRITE;
/*!40000 ALTER TABLE `generic_threadedcomment` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_threadedcomment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mezzanine_agenda_event`
--

DROP TABLE IF EXISTS `mezzanine_agenda_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mezzanine_agenda_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comments_count` int(11) NOT NULL,
  `keywords_string` varchar(500) NOT NULL,
  `rating_count` int(11) NOT NULL,
  `rating_sum` int(11) NOT NULL,
  `rating_average` double NOT NULL,
  `title` varchar(500) NOT NULL,
  `title_fr` varchar(500) DEFAULT NULL,
  `title_en` varchar(500) DEFAULT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `_meta_title` varchar(500) DEFAULT NULL,
  `description` longtext NOT NULL,
  `gen_description` tinyint(1) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `status` int(11) NOT NULL,
  `publish_date` datetime DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `short_url` varchar(200) DEFAULT NULL,
  `in_sitemap` tinyint(1) NOT NULL,
  `content` longtext NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime DEFAULT NULL,
  `facebook_event` bigint(20) DEFAULT NULL,
  `allow_comments` tinyint(1) NOT NULL,
  `featured_image` varchar(255) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content_en` longtext,
  `content_fr` longtext,
  `external_id` int(11) DEFAULT NULL,
  `featured_image_description` longtext NOT NULL,
  `featured_image_header` varchar(1024) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `description_en` longtext,
  `description_fr` longtext,
  `brochure` varchar(1024) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mezzanine_agenda_event_76776489` (`publish_date`),
  KEY `mezzanine_agenda_event_e274a5da` (`location_id`),
  KEY `mezzanine_agenda_event_9365d6e7` (`site_id`),
  KEY `mezzanine_agenda_event_e8701ad4` (`user_id`),
  KEY `mezzanine_agenda_event_6be37982` (`parent_id`),
  KEY `mezzanine_agenda_event_b583a629` (`category_id`),
  CONSTRAINT `mezzan_category_id_f9632aec_fk_mezzanine_agenda_eventcategory_id` FOREIGN KEY (`category_id`) REFERENCES `mezzanine_agenda_eventcategory` (`id`),
  CONSTRAINT `mezzan_location_id_79f17710_fk_mezzanine_agenda_eventlocation_id` FOREIGN KEY (`location_id`) REFERENCES `mezzanine_agenda_eventlocation` (`id`),
  CONSTRAINT `mezzanine_agenda_event_site_id_4a5df2ce_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`),
  CONSTRAINT `mezzanine_agenda_event_user_id_422b0aea_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`),
  CONSTRAINT `mezzanine_agenda_parent_id_0e3235d9_fk_mezzanine_agenda_event_id` FOREIGN KEY (`parent_id`) REFERENCES `mezzanine_agenda_event` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mezzanine_agenda_event`
--

LOCK TABLES `mezzanine_agenda_event` WRITE;
/*!40000 ALTER TABLE `mezzanine_agenda_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `mezzanine_agenda_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mezzanine_agenda_event_blog_posts`
--

DROP TABLE IF EXISTS `mezzanine_agenda_event_blog_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mezzanine_agenda_event_blog_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `blogpost_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mezzanine_agenda_event_blog_posts_event_id_5c0a6b6a_uniq` (`event_id`,`blogpost_id`),
  KEY `mezzanine_agenda_event__blogpost_id_76acb543_fk_blog_blogpost_id` (`blogpost_id`),
  CONSTRAINT `mezzanine_agenda__event_id_e64a5327_fk_mezzanine_agenda_event_id` FOREIGN KEY (`event_id`) REFERENCES `mezzanine_agenda_event` (`id`),
  CONSTRAINT `mezzanine_agenda_event__blogpost_id_76acb543_fk_blog_blogpost_id` FOREIGN KEY (`blogpost_id`) REFERENCES `blog_blogpost` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mezzanine_agenda_event_blog_posts`
--

LOCK TABLES `mezzanine_agenda_event_blog_posts` WRITE;
/*!40000 ALTER TABLE `mezzanine_agenda_event_blog_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `mezzanine_agenda_event_blog_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mezzanine_agenda_event_prices`
--

DROP TABLE IF EXISTS `mezzanine_agenda_event_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mezzanine_agenda_event_prices` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `event_id` int(11) NOT NULL,
  `eventprice_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `mezzanine_agenda_event_prices_event_id_2181d124_uniq` (`event_id`,`eventprice_id`),
  KEY `mezzani_eventprice_id_8d79c68b_fk_mezzanine_agenda_eventprice_id` (`eventprice_id`),
  CONSTRAINT `mezzani_eventprice_id_8d79c68b_fk_mezzanine_agenda_eventprice_id` FOREIGN KEY (`eventprice_id`) REFERENCES `mezzanine_agenda_eventprice` (`id`),
  CONSTRAINT `mezzanine_agenda__event_id_cfa89ea7_fk_mezzanine_agenda_event_id` FOREIGN KEY (`event_id`) REFERENCES `mezzanine_agenda_event` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mezzanine_agenda_event_prices`
--

LOCK TABLES `mezzanine_agenda_event_prices` WRITE;
/*!40000 ALTER TABLE `mezzanine_agenda_event_prices` DISABLE KEYS */;
/*!40000 ALTER TABLE `mezzanine_agenda_event_prices` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mezzanine_agenda_eventcategory`
--

DROP TABLE IF EXISTS `mezzanine_agenda_eventcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mezzanine_agenda_eventcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  `description` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mezzanine_agenda_eventcategory`
--

LOCK TABLES `mezzanine_agenda_eventcategory` WRITE;
/*!40000 ALTER TABLE `mezzanine_agenda_eventcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `mezzanine_agenda_eventcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mezzanine_agenda_eventlocation`
--

DROP TABLE IF EXISTS `mezzanine_agenda_eventlocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mezzanine_agenda_eventlocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `address` longtext NOT NULL,
  `mappable_location` varchar(128) NOT NULL,
  `lat` decimal(10,7) DEFAULT NULL,
  `lon` decimal(10,7) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  `description` longtext NOT NULL,
  `link` varchar(512) DEFAULT NULL,
  `description_en` longtext,
  `description_fr` longtext,
  `featured_name` varchar(512) DEFAULT NULL,
  `external_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `mezzanine_agenda_eventlocatio_site_id_aaa69136_fk_django_site_id` (`site_id`),
  CONSTRAINT `mezzanine_agenda_eventlocatio_site_id_aaa69136_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mezzanine_agenda_eventlocation`
--

LOCK TABLES `mezzanine_agenda_eventlocation` WRITE;
/*!40000 ALTER TABLE `mezzanine_agenda_eventlocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `mezzanine_agenda_eventlocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mezzanine_agenda_eventprice`
--

DROP TABLE IF EXISTS `mezzanine_agenda_eventprice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mezzanine_agenda_eventprice` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `unit` varchar(16) DEFAULT NULL,
  `value` double NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mezzanine_agenda_eventprice`
--

LOCK TABLES `mezzanine_agenda_eventprice` WRITE;
/*!40000 ALTER TABLE `mezzanine_agenda_eventprice` DISABLE KEYS */;
/*!40000 ALTER TABLE `mezzanine_agenda_eventprice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization_activity`
--

DROP TABLE IF EXISTS `organization_activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organization_activity` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date_begin` date DEFAULT NULL,
  `date_end` date DEFAULT NULL,
  `role` varchar(512) NOT NULL,
  `work` longtext NOT NULL,
  `person_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `organization_activity_a8452ca7` (`person_id`),
  CONSTRAINT `organization_activi_person_id_6be7474e_fk_organization_person_id` FOREIGN KEY (`person_id`) REFERENCES `organization_person` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_activity`
--

LOCK TABLES `organization_activity` WRITE;
/*!40000 ALTER TABLE `organization_activity` DISABLE KEYS */;
/*!40000 ALTER TABLE `organization_activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization_activity_teams`
--

DROP TABLE IF EXISTS `organization_activity_teams`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organization_activity_teams` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `activity_id` int(11) NOT NULL,
  `team_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `organization_activity_teams_activity_id_1c673181_uniq` (`activity_id`,`team_id`),
  KEY `organization_activity_t_team_id_1ad9296d_fk_organization_team_id` (`team_id`),
  CONSTRAINT `organization_ac_activity_id_74e130d5_fk_organization_activity_id` FOREIGN KEY (`activity_id`) REFERENCES `organization_activity` (`id`),
  CONSTRAINT `organization_activity_t_team_id_1ad9296d_fk_organization_team_id` FOREIGN KEY (`team_id`) REFERENCES `organization_team` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_activity_teams`
--

LOCK TABLES `organization_activity_teams` WRITE;
/*!40000 ALTER TABLE `organization_activity_teams` DISABLE KEYS */;
/*!40000 ALTER TABLE `organization_activity_teams` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization_department`
--

DROP TABLE IF EXISTS `organization_department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organization_department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  `description` longtext NOT NULL,
  `domain` varchar(255) NOT NULL,
  `weaving_class` varchar(64) NOT NULL,
  `organization_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `organization_department_26b2345e` (`organization_id`),
  CONSTRAINT `organiz_organization_id_460ed4f9_fk_organization_organization_id` FOREIGN KEY (`organization_id`) REFERENCES `organization_organization` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_department`
--

LOCK TABLES `organization_department` WRITE;
/*!40000 ALTER TABLE `organization_department` DISABLE KEYS */;
/*!40000 ALTER TABLE `organization_department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization_link`
--

DROP TABLE IF EXISTS `organization_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organization_link` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `url` varchar(200) NOT NULL,
  `link_type_id` int(11) NOT NULL,
  `person_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `organization_link_5fa7bec0` (`link_type_id`),
  KEY `organization_link_a8452ca7` (`person_id`),
  CONSTRAINT `organization_l_link_type_id_1f576256_fk_organization_linktype_id` FOREIGN KEY (`link_type_id`) REFERENCES `organization_linktype` (`id`),
  CONSTRAINT `organization_link_person_id_53629bcd_fk_organization_person_id` FOREIGN KEY (`person_id`) REFERENCES `organization_person` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_link`
--

LOCK TABLES `organization_link` WRITE;
/*!40000 ALTER TABLE `organization_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `organization_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization_linktype`
--

DROP TABLE IF EXISTS `organization_linktype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organization_linktype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(256) NOT NULL,
  `slug` varchar(256) NOT NULL,
  `ordering` int(10) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `organization_linktype_2dbcba41` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_linktype`
--

LOCK TABLES `organization_linktype` WRITE;
/*!40000 ALTER TABLE `organization_linktype` DISABLE KEYS */;
/*!40000 ALTER TABLE `organization_linktype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization_organization`
--

DROP TABLE IF EXISTS `organization_organization`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organization_organization` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  `description` longtext NOT NULL,
  `address` longtext NOT NULL,
  `postalcode` varchar(16) NOT NULL,
  `country` varchar(255) NOT NULL,
  `url` varchar(512) NOT NULL,
  `organization_type_id` int(11),
  PRIMARY KEY (`id`),
  KEY `organization_organization_8a291c53` (`organization_type_id`),
  CONSTRAINT `D4461ccf4916f97cb69265757540aad9` FOREIGN KEY (`organization_type_id`) REFERENCES `organization_organizationtype` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_organization`
--

LOCK TABLES `organization_organization` WRITE;
/*!40000 ALTER TABLE `organization_organization` DISABLE KEYS */;
/*!40000 ALTER TABLE `organization_organization` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization_organizationtype`
--

DROP TABLE IF EXISTS `organization_organizationtype`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organization_organizationtype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_organizationtype`
--

LOCK TABLES `organization_organizationtype` WRITE;
/*!40000 ALTER TABLE `organization_organizationtype` DISABLE KEYS */;
/*!40000 ALTER TABLE `organization_organizationtype` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization_person`
--

DROP TABLE IF EXISTS `organization_person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organization_person` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keywords_string` varchar(500) NOT NULL,
  `title` varchar(500) NOT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `_meta_title` varchar(500) DEFAULT NULL,
  `description` longtext NOT NULL,
  `gen_description` tinyint(1) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `status` int(11) NOT NULL,
  `publish_date` datetime DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `short_url` varchar(200) DEFAULT NULL,
  `in_sitemap` tinyint(1) NOT NULL,
  `content` longtext NOT NULL,
  `person_title` varchar(16) NOT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `bio` longtext NOT NULL,
  `photo` varchar(1024) NOT NULL,
  `photo_credits` varchar(255) DEFAULT NULL,
  `photo_alignment` varchar(32) NOT NULL,
  `photo_description` longtext NOT NULL,
  `photo_featured` varchar(1024) NOT NULL,
  `photo_featured_credits` varchar(255) DEFAULT NULL,
  `organization_id` int(11) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `organiz_organization_id_28133c66_fk_organization_organization_id` (`organization_id`),
  KEY `organization_person_site_id_f8f17ee8_fk_django_site_id` (`site_id`),
  KEY `organization_person_user_id_5a133c8a_fk_auth_user_id` (`user_id`),
  KEY `organization_person_76776489` (`publish_date`),
  CONSTRAINT `organiz_organization_id_28133c66_fk_organization_organization_id` FOREIGN KEY (`organization_id`) REFERENCES `organization_organization` (`id`),
  CONSTRAINT `organization_person_site_id_f8f17ee8_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`),
  CONSTRAINT `organization_person_user_id_5a133c8a_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_person`
--

LOCK TABLES `organization_person` WRITE;
/*!40000 ALTER TABLE `organization_person` DISABLE KEYS */;
/*!40000 ALTER TABLE `organization_person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `organization_team`
--

DROP TABLE IF EXISTS `organization_team`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `organization_team` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  `description` longtext NOT NULL,
  `department_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `organizatio_department_id_53381866_fk_organization_department_id` (`department_id`),
  CONSTRAINT `organizatio_department_id_53381866_fk_organization_department_id` FOREIGN KEY (`department_id`) REFERENCES `organization_department` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `organization_team`
--

LOCK TABLES `organization_team` WRITE;
/*!40000 ALTER TABLE `organization_team` DISABLE KEYS */;
/*!40000 ALTER TABLE `organization_team` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages_link`
--

DROP TABLE IF EXISTS `pages_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages_link` (
  `page_ptr_id` int(11) NOT NULL,
  PRIMARY KEY (`page_ptr_id`),
  CONSTRAINT `pages_link_page_ptr_id_37d469f7_fk_pages_page_id` FOREIGN KEY (`page_ptr_id`) REFERENCES `pages_page` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_link`
--

LOCK TABLES `pages_link` WRITE;
/*!40000 ALTER TABLE `pages_link` DISABLE KEYS */;
INSERT INTO `pages_link` VALUES (1),(2),(3),(4),(5);
/*!40000 ALTER TABLE `pages_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages_page`
--

DROP TABLE IF EXISTS `pages_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keywords_string` varchar(500) NOT NULL,
  `title` varchar(500) NOT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `_meta_title` varchar(500) DEFAULT NULL,
  `description` longtext NOT NULL,
  `gen_description` tinyint(1) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `status` int(11) NOT NULL,
  `publish_date` datetime DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `short_url` varchar(200) DEFAULT NULL,
  `in_sitemap` tinyint(1) NOT NULL,
  `_order` int(11) DEFAULT NULL,
  `in_menus` varchar(100) DEFAULT NULL,
  `titles` varchar(1000) DEFAULT NULL,
  `content_model` varchar(50) DEFAULT NULL,
  `login_required` tinyint(1) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  `_meta_title_en` varchar(500) DEFAULT NULL,
  `_meta_title_fr` varchar(500) DEFAULT NULL,
  `description_en` longtext,
  `description_fr` longtext,
  `title_en` varchar(500) DEFAULT NULL,
  `title_fr` varchar(500) DEFAULT NULL,
  `titles_en` varchar(1000) DEFAULT NULL,
  `titles_fr` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pages_page_6be37982` (`parent_id`),
  KEY `pages_page_9365d6e7` (`site_id`),
  KEY `pages_page_publish_date_eb7c8d46_uniq` (`publish_date`),
  CONSTRAINT `pages_page_parent_id_133fa4d3_fk_pages_page_id` FOREIGN KEY (`parent_id`) REFERENCES `pages_page` (`id`),
  CONSTRAINT `pages_page_site_id_47a43e5b_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_page`
--

LOCK TABLES `pages_page` WRITE;
/*!40000 ALTER TABLE `pages_page` DISABLE KEYS */;
INSERT INTO `pages_page` VALUES (1,'','Research','/research/',NULL,'Recherche',1,'2016-06-21 21:35:39','2016-06-21 21:35:39',2,'2016-06-21 21:35:39',NULL,NULL,0,0,'2','Research','link',0,NULL,1,NULL,NULL,'Recherche','Recherche','Research','Recherche','Research','Recherche'),(2,'','Creation','/creation/',NULL,'Création',1,'2016-06-21 21:36:25','2016-06-21 21:36:25',2,'2016-06-21 21:36:25',NULL,NULL,0,1,'2','Creation','link',0,NULL,1,NULL,NULL,'Création','Création','Creation','Création','Creation','Création'),(3,'','Transmission','/transmission/',NULL,'Transmission',1,'2016-06-21 21:36:51','2016-06-21 21:36:51',2,'2016-06-21 21:36:51',NULL,NULL,0,2,'2','Transmission','link',0,NULL,1,NULL,NULL,'Transmission','Transmission','Transmission','Transmission','Transmission','Transmission'),(4,'','Innovations','/innovations/',NULL,'Innovations',1,'2016-06-21 21:37:30','2016-06-21 21:37:30',2,'2016-06-21 21:37:30',NULL,NULL,0,3,'2','Innovations','link',0,NULL,1,NULL,NULL,'Innovations','Innovations','Innovations','Innovations','Innovations','Innovations'),(5,'','Rendez-vous 15/16','/rendez-vous/',NULL,'Rendez-vous 15/16',1,'2016-06-21 21:38:02','2016-06-21 21:38:02',2,'2016-06-21 21:38:02',NULL,NULL,0,4,'2','Rendez-vous 15/16','link',0,NULL,1,NULL,NULL,'Rendez-vous 15/16','Rendez-vous 15/16','Rendez-vous 15/16','Rendez-vous 15/16','Rendez-vous 15/16','Rendez-vous 15/16'),(6,'','L\'ircam','lircam',NULL,'Vbi curarum abiectis ponderibus aliis tamquam nodum et codicem difficillimum Caesarem convellere nisu valido cogitabat, eique deliberanti cum proximis clandestinis conloquiis et nocturnis qua vi, quibusve commentis id fieret, antequam effundendis rebus pertinacius incumberet confidentia, acciri mollioribus scriptis per simulationem tractatus publici nimis urgentis eundem placuerat Gallum, ut auxilio destitutus sine ullo interiret obstaculo.',1,'2016-07-05 15:08:44','2016-07-06 09:57:55',2,'2016-07-05 15:08:44',NULL,NULL,1,5,'1','L\'ircam','basicpage',0,NULL,1,NULL,NULL,'Vbi curarum abiectis ponderibus aliis tamquam nodum et codicem difficillimum Caesarem convellere nisu valido cogitabat, eique deliberanti cum proximis clandestinis conloquiis et nocturnis qua vi, quibusve commentis id fieret, antequam effundendis rebus pertinacius incumberet confidentia, acciri mollioribus scriptis per simulationem tractatus publici nimis urgentis eundem placuerat Gallum, ut auxilio destitutus sine ullo interiret obstaculo.','Vbi curarum abiectis ponderibus aliis tamquam nodum et codicem difficillimum Caesarem convellere nisu valido cogitabat, eique deliberanti cum proximis clandestinis conloquiis et nocturnis qua vi, quibusve commentis id fieret, antequam effundendis rebus pertinacius incumberet confidentia, acciri mollioribus scriptis per simulationem tractatus publici nimis urgentis eundem placuerat Gallum, ut auxilio destitutus sine ullo interiret obstaculo.','','L\'ircam','L\'ircam','L\'ircam'),(7,'','réseaux','reseaux',NULL,'Vbi curarum abiectis ponderibus aliis tamquam nodum et codicem difficillimum Caesarem convellere nisu valido cogitabat, eique deliberanti cum proximis clandestinis conloquiis et nocturnis qua vi, quibusve commentis id fieret, antequam effundendis rebus pertinacius incumberet confidentia, acciri mollioribus scriptis per simulationem tractatus publici nimis urgentis eundem placuerat Gallum, ut auxilio destitutus sine ullo interiret obstaculo.',1,'2016-07-05 15:09:09','2016-07-05 15:10:57',2,'2016-07-05 15:09:09',NULL,NULL,1,6,'1','réseaux','basicpage',0,NULL,1,NULL,NULL,'Vbi curarum abiectis ponderibus aliis tamquam nodum et codicem difficillimum Caesarem convellere nisu valido cogitabat, eique deliberanti cum proximis clandestinis conloquiis et nocturnis qua vi, quibusve commentis id fieret, antequam effundendis rebus pertinacius incumberet confidentia, acciri mollioribus scriptis per simulationem tractatus publici nimis urgentis eundem placuerat Gallum, ut auxilio destitutus sine ullo interiret obstaculo.','Vbi curarum abiectis ponderibus aliis tamquam nodum et codicem difficillimum Caesarem convellere nisu valido cogitabat, eique deliberanti cum proximis clandestinis conloquiis et nocturnis qua vi, quibusve commentis id fieret, antequam effundendis rebus pertinacius incumberet confidentia, acciri mollioribus scriptis per simulationem tractatus publici nimis urgentis eundem placuerat Gallum, ut auxilio destitutus sine ullo interiret obstaculo.','','réseaux','réseaux','réseaux'),(8,'','réserver','reserver',NULL,'Vbi curarum abiectis ponderibus aliis tamquam nodum et codicem difficillimum Caesarem convellere nisu valido cogitabat, eique deliberanti cum proximis clandestinis conloquiis et nocturnis qua vi, quibusve commentis id fieret, antequam effundendis rebus pertinacius incumberet confidentia, acciri mollioribus scriptis per simulationem tractatus publici nimis urgentis eundem placuerat Gallum, ut auxilio destitutus sine ullo interiret obstaculo.',1,'2016-07-05 15:10:10','2016-07-05 15:10:10',2,'2016-07-05 15:10:10',NULL,NULL,1,7,'1','réserver','basicpage',0,NULL,1,NULL,NULL,'Vbi curarum abiectis ponderibus aliis tamquam nodum et codicem difficillimum Caesarem convellere nisu valido cogitabat, eique deliberanti cum proximis clandestinis conloquiis et nocturnis qua vi, quibusve commentis id fieret, antequam effundendis rebus pertinacius incumberet confidentia, acciri mollioribus scriptis per simulationem tractatus publici nimis urgentis eundem placuerat Gallum, ut auxilio destitutus sine ullo interiret obstaculo.','Vbi curarum abiectis ponderibus aliis tamquam nodum et codicem difficillimum Caesarem convellere nisu valido cogitabat, eique deliberanti cum proximis clandestinis conloquiis et nocturnis qua vi, quibusve commentis id fieret, antequam effundendis rebus pertinacius incumberet confidentia, acciri mollioribus scriptis per simulationem tractatus publici nimis urgentis eundem placuerat Gallum, ut auxilio destitutus sine ullo interiret obstaculo.','','réserver','réserver','réserver'),(9,'','candidater','candidater',NULL,'lorem',1,'2016-07-05 15:11:21','2016-07-05 15:11:22',2,'2016-07-05 15:11:21',NULL,NULL,1,8,'1','candidater','basicpage',0,NULL,1,NULL,NULL,'lorem','lorem','','candidater','candidater','candidater'),(10,'','être informé','etre-informe',NULL,'lorem',1,'2016-07-05 15:11:40','2016-07-05 16:22:53',2,'2016-07-05 15:11:40',NULL,NULL,1,9,'1','être informé','basicpage',0,NULL,1,NULL,NULL,'lorem','lorem','','être informé','être informé','être informé'),(11,'','venir à l\'Ircam','venir-a-lircam',NULL,'lorem',1,'2016-07-05 15:11:56','2016-07-05 15:11:56',2,'2016-07-05 15:11:56',NULL,NULL,1,10,'1','venir à l\'Ircam','basicpage',0,NULL,1,NULL,NULL,'lorem','lorem','','venir à l\'Ircam','venir à l\'Ircam','venir à l\'Ircam'),(12,'','vous êtes','vous-etes',NULL,'lorem',1,'2016-07-05 15:12:13','2016-07-05 15:12:13',2,'2016-07-05 15:12:13',NULL,NULL,1,11,'1','vous êtes','basicpage',0,NULL,1,NULL,NULL,'lorem','lorem','','vous êtes','vous êtes','vous êtes'),(13,'','Offres d\'emploi et de stage','offres-demploi-et-de-stage',NULL,'Vbi curarum abiectis ponderibus aliis tamquam nodum et codicem difficillimum Caesarem convellere nisu valido cogitabat, eique deliberanti cum proximis clandestinis conloquiis et nocturnis qua vi, quibusve commentis id fieret, antequam effundendis rebus pertinacius incumberet confidentia, acciri mollioribus scriptis per simulationem tractatus publici nimis urgentis eundem placuerat Gallum, ut auxilio destitutus sine ullo interiret obstaculo.',1,'2016-07-05 15:13:06','2016-07-05 15:13:06',2,'2016-07-05 15:13:06',NULL,NULL,1,12,'3','Offres d\'emploi et de stage','basicpage',0,NULL,1,NULL,NULL,'Vbi curarum abiectis ponderibus aliis tamquam nodum et codicem difficillimum Caesarem convellere nisu valido cogitabat, eique deliberanti cum proximis clandestinis conloquiis et nocturnis qua vi, quibusve commentis id fieret, antequam effundendis rebus pertinacius incumberet confidentia, acciri mollioribus scriptis per simulationem tractatus publici nimis urgentis eundem placuerat Gallum, ut auxilio destitutus sine ullo interiret obstaculo.','Vbi curarum abiectis ponderibus aliis tamquam nodum et codicem difficillimum Caesarem convellere nisu valido cogitabat, eique deliberanti cum proximis clandestinis conloquiis et nocturnis qua vi, quibusve commentis id fieret, antequam effundendis rebus pertinacius incumberet confidentia, acciri mollioribus scriptis per simulationem tractatus publici nimis urgentis eundem placuerat Gallum, ut auxilio destitutus sine ullo interiret obstaculo.','','Offres d\'emploi et de stage','Offres d\'emploi et de stage','Offres d\'emploi et de stage'),(14,'','Contacts / Equipes','contacts-equipes',NULL,'lorem',1,'2016-07-05 15:13:23','2016-07-05 15:13:23',2,'2016-07-05 15:13:23',NULL,NULL,1,13,'3','Contacts / Equipes','basicpage',0,NULL,1,NULL,NULL,'lorem','lorem','','Contacts / Equipes','Contacts / Equipes','Contacts / Equipes'),(15,'','Espace Pro','espace-pro',NULL,'lorem',1,'2016-07-05 15:13:39','2016-07-05 15:13:39',2,'2016-07-05 15:13:39',NULL,NULL,1,14,'3','Espace Pro','basicpage',0,NULL,1,NULL,NULL,'lorem','lorem','','Espace Pro','Espace Pro','Espace Pro'),(16,'','Partenaires','partenaires',NULL,'lorem',1,'2016-07-05 15:13:50','2016-07-05 15:13:50',2,'2016-07-05 15:13:50',NULL,NULL,1,15,'3','Partenaires','basicpage',0,NULL,1,NULL,NULL,'lorem','lorem','','Partenaires','Partenaires','Partenaires'),(17,'','A propos','a-propos',NULL,'lorem',1,'2016-07-05 15:14:02','2016-07-05 15:14:02',2,'2016-07-05 15:14:02',NULL,NULL,1,16,'3','A propos','basicpage',0,NULL,1,NULL,NULL,'lorem','lorem','','A propos','A propos','A propos'),(18,'','Plan du site','plan-du-site',NULL,'lorem',1,'2016-07-05 15:14:15','2016-07-05 15:14:15',2,'2016-07-05 15:14:15',NULL,NULL,1,17,'3','Plan du site','basicpage',0,NULL,1,NULL,NULL,'lorem','lorem','','Plan du site','Plan du site','Plan du site');
/*!40000 ALTER TABLE `pages_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages_richtextpage`
--

DROP TABLE IF EXISTS `pages_richtextpage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages_richtextpage` (
  `page_ptr_id` int(11) NOT NULL,
  `content` longtext NOT NULL,
  `content_en` longtext,
  `content_fr` longtext,
  PRIMARY KEY (`page_ptr_id`),
  CONSTRAINT `pages_richtextpage_page_ptr_id_8ca99b83_fk_pages_page_id` FOREIGN KEY (`page_ptr_id`) REFERENCES `pages_page` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_richtextpage`
--

LOCK TABLES `pages_richtextpage` WRITE;
/*!40000 ALTER TABLE `pages_richtextpage` DISABLE KEYS */;
/*!40000 ALTER TABLE `pages_richtextpage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `twitter_query`
--

DROP TABLE IF EXISTS `twitter_query`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `twitter_query` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(10) NOT NULL,
  `value` varchar(140) NOT NULL,
  `interested` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `twitter_query`
--

LOCK TABLES `twitter_query` WRITE;
/*!40000 ALTER TABLE `twitter_query` DISABLE KEYS */;
/*!40000 ALTER TABLE `twitter_query` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `twitter_tweet`
--

DROP TABLE IF EXISTS `twitter_tweet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `twitter_tweet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `remote_id` varchar(50) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `text` longtext,
  `profile_image_url` varchar(200) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `retweeter_profile_image_url` varchar(200) DEFAULT NULL,
  `retweeter_user_name` varchar(100) DEFAULT NULL,
  `retweeter_full_name` varchar(100) DEFAULT NULL,
  `query_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `twitter_tweet_query_id_bd42b699_fk_twitter_query_id` (`query_id`),
  CONSTRAINT `twitter_tweet_query_id_bd42b699_fk_twitter_query_id` FOREIGN KEY (`query_id`) REFERENCES `twitter_query` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `twitter_tweet`
--

LOCK TABLES `twitter_tweet` WRITE;
/*!40000 ALTER TABLE `twitter_tweet` DISABLE KEYS */;
/*!40000 ALTER TABLE `twitter_tweet` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-07-06 13:21:12
