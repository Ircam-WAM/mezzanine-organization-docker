-- MySQL dump 10.16  Distrib 10.1.10-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db    Database: manifeste
-- ------------------------------------------------------
-- Server version	10.1.10-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group__permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id` (`permission_id`),
  CONSTRAINT `auth_group__permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permission_group_id_689710a9a73b7457_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  CONSTRAINT `auth__content_type_id_508cf46651277a81_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=110 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add permission',1,'add_permission'),(2,'Can change permission',1,'change_permission'),(3,'Can delete permission',1,'delete_permission'),(4,'Can add group',2,'add_group'),(5,'Can change group',2,'change_group'),(6,'Can delete group',2,'delete_group'),(7,'Can add user',3,'add_user'),(8,'Can change user',3,'change_user'),(9,'Can delete user',3,'delete_user'),(10,'Can add content type',4,'add_contenttype'),(11,'Can change content type',4,'change_contenttype'),(12,'Can delete content type',4,'delete_contenttype'),(13,'Can add redirect',5,'add_redirect'),(14,'Can change redirect',5,'change_redirect'),(15,'Can delete redirect',5,'delete_redirect'),(16,'Can add session',6,'add_session'),(17,'Can change session',6,'change_session'),(18,'Can delete session',6,'delete_session'),(19,'Can add site',7,'add_site'),(20,'Can change site',7,'change_site'),(21,'Can delete site',7,'delete_site'),(22,'Can add Setting',8,'add_setting'),(23,'Can change Setting',8,'change_setting'),(24,'Can delete Setting',8,'delete_setting'),(25,'Can add Site permission',9,'add_sitepermission'),(26,'Can change Site permission',9,'change_sitepermission'),(27,'Can delete Site permission',9,'delete_sitepermission'),(28,'Can add Comment',10,'add_threadedcomment'),(29,'Can change Comment',10,'change_threadedcomment'),(30,'Can delete Comment',10,'delete_threadedcomment'),(31,'Can add Keyword',11,'add_keyword'),(32,'Can change Keyword',11,'change_keyword'),(33,'Can delete Keyword',11,'delete_keyword'),(34,'Can add assigned keyword',12,'add_assignedkeyword'),(35,'Can change assigned keyword',12,'change_assignedkeyword'),(36,'Can delete assigned keyword',12,'delete_assignedkeyword'),(37,'Can add Rating',13,'add_rating'),(38,'Can change Rating',13,'change_rating'),(39,'Can delete Rating',13,'delete_rating'),(40,'Can add Page',14,'add_page'),(41,'Can change Page',14,'change_page'),(42,'Can delete Page',14,'delete_page'),(43,'Can add Rich text page',15,'add_richtextpage'),(44,'Can change Rich text page',15,'change_richtextpage'),(45,'Can delete Rich text page',15,'delete_richtextpage'),(46,'Can add Link',16,'add_link'),(47,'Can change Link',16,'change_link'),(48,'Can delete Link',16,'delete_link'),(49,'Can add Blog post',17,'add_blogpost'),(50,'Can change Blog post',17,'change_blogpost'),(51,'Can delete Blog post',17,'delete_blogpost'),(52,'Can add Blog Category',18,'add_blogcategory'),(53,'Can change Blog Category',18,'change_blogcategory'),(54,'Can delete Blog Category',18,'delete_blogcategory'),(55,'Can add Form',19,'add_form'),(56,'Can change Form',19,'change_form'),(57,'Can delete Form',19,'delete_form'),(58,'Can add Field',20,'add_field'),(59,'Can change Field',20,'change_field'),(60,'Can delete Field',20,'delete_field'),(61,'Can add Form entry',21,'add_formentry'),(62,'Can change Form entry',21,'change_formentry'),(63,'Can delete Form entry',21,'delete_formentry'),(64,'Can add Form field entry',22,'add_fieldentry'),(65,'Can change Form field entry',22,'change_fieldentry'),(66,'Can delete Form field entry',22,'delete_fieldentry'),(67,'Can add Gallery',23,'add_gallery'),(68,'Can change Gallery',23,'change_gallery'),(69,'Can delete Gallery',23,'delete_gallery'),(70,'Can add Image',24,'add_galleryimage'),(71,'Can change Image',24,'change_galleryimage'),(72,'Can delete Image',24,'delete_galleryimage'),(73,'Can add Twitter query',25,'add_query'),(74,'Can change Twitter query',25,'change_query'),(75,'Can delete Twitter query',25,'delete_query'),(76,'Can add Tweet',26,'add_tweet'),(77,'Can change Tweet',26,'change_tweet'),(78,'Can delete Tweet',26,'delete_tweet'),(79,'Can add festival event',27,'add_festivalevent'),(80,'Can change festival event',27,'change_festivalevent'),(81,'Can delete festival event',27,'delete_festivalevent'),(82,'Can add artist',28,'add_artist'),(83,'Can change artist',28,'change_artist'),(84,'Can delete artist',28,'delete_artist'),(85,'Can add video',29,'add_video'),(86,'Can change video',29,'change_video'),(87,'Can delete video',29,'delete_video'),(88,'Can add event category',30,'add_eventcategory'),(89,'Can change event category',30,'change_eventcategory'),(90,'Can delete event category',30,'delete_eventcategory'),(91,'Can add page category',31,'add_pagecategory'),(92,'Can change page category',31,'change_pagecategory'),(93,'Can delete page category',31,'delete_pagecategory'),(94,'Can add Event',32,'add_event'),(95,'Can change Event',32,'change_event'),(96,'Can delete Event',32,'delete_event'),(97,'Can add Event Location',33,'add_eventlocation'),(98,'Can change Event Location',33,'change_eventlocation'),(99,'Can delete Event Location',33,'delete_eventlocation'),(100,'Can add log entry',34,'add_logentry'),(101,'Can change log entry',34,'change_logentry'),(102,'Can delete log entry',34,'delete_logentry'),(103,'Can add comment',35,'add_comment'),(104,'Can change comment',35,'change_comment'),(105,'Can delete comment',35,'delete_comment'),(106,'Can moderate comments',35,'can_moderate'),(107,'Can add comment flag',36,'add_commentflag'),(108,'Can change comment flag',36,'change_commentflag'),(109,'Can delete comment flag',36,'delete_commentflag');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$24000$By0OQRkbgmm2$+aiXlgKElwts1Sy9UOpuAT5gZLWUB8vk7m0wlWkk6I4=','2016-03-03 13:00:15',1,'admin','','','root@example.com',1,1,'2016-02-25 04:02:38');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_4b5ed4ffdb8fd9b0_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_u_permission_id_384b62483d7071f0_fk_auth_permission_id` (`permission_id`),
  CONSTRAINT `auth_user_u_permission_id_384b62483d7071f0_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissi_user_id_7f0938558328534a_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_blogcategory`
--

DROP TABLE IF EXISTS `blog_blogcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_blogcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  `title_en` varchar(500) DEFAULT NULL,
  `title_fr` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_blogcategory_site_id_1565b70d240d75b_fk_django_site_id` (`site_id`),
  CONSTRAINT `blog_blogcategory_site_id_1565b70d240d75b_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_blogcategory`
--

LOCK TABLES `blog_blogcategory` WRITE;
/*!40000 ALTER TABLE `blog_blogcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_blogcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_blogpost`
--

DROP TABLE IF EXISTS `blog_blogpost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_blogpost` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comments_count` int(11) NOT NULL,
  `keywords_string` varchar(500) NOT NULL,
  `rating_count` int(11) NOT NULL,
  `rating_sum` int(11) NOT NULL,
  `rating_average` double NOT NULL,
  `title` varchar(500) NOT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `_meta_title` varchar(500) DEFAULT NULL,
  `description` longtext NOT NULL,
  `gen_description` tinyint(1) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `status` int(11) NOT NULL,
  `publish_date` datetime DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `short_url` varchar(200) DEFAULT NULL,
  `in_sitemap` tinyint(1) NOT NULL,
  `content` longtext NOT NULL,
  `allow_comments` tinyint(1) NOT NULL,
  `featured_image` varchar(255) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `_meta_title_en` varchar(500) DEFAULT NULL,
  `_meta_title_fr` varchar(500) DEFAULT NULL,
  `content_en` longtext,
  `content_fr` longtext,
  `description_en` longtext,
  `description_fr` longtext,
  `title_en` varchar(500) DEFAULT NULL,
  `title_fr` varchar(500) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `blog_blogpost_site_id_3cd2a8869a3bc877_fk_django_site_id` (`site_id`),
  KEY `blog_blogpost_user_id_3d08a741310d8f6f_fk_auth_user_id` (`user_id`),
  KEY `blog_blogpost_publish_date_1015da2554a8e97f_uniq` (`publish_date`),
  CONSTRAINT `blog_blogpost_site_id_3cd2a8869a3bc877_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`),
  CONSTRAINT `blog_blogpost_user_id_3d08a741310d8f6f_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_blogpost`
--

LOCK TABLES `blog_blogpost` WRITE;
/*!40000 ALTER TABLE `blog_blogpost` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_blogpost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_blogpost_categories`
--

DROP TABLE IF EXISTS `blog_blogpost_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_blogpost_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blogpost_id` int(11) NOT NULL,
  `blogcategory_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `blogpost_id` (`blogpost_id`,`blogcategory_id`),
  KEY `blog_bl_blogcategory_id_5c987a15b9426892_fk_blog_blogcategory_id` (`blogcategory_id`),
  CONSTRAINT `blog_bl_blogcategory_id_5c987a15b9426892_fk_blog_blogcategory_id` FOREIGN KEY (`blogcategory_id`) REFERENCES `blog_blogcategory` (`id`),
  CONSTRAINT `blog_blogpost_c_blogpost_id_11545014277324dc_fk_blog_blogpost_id` FOREIGN KEY (`blogpost_id`) REFERENCES `blog_blogpost` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_blogpost_categories`
--

LOCK TABLES `blog_blogpost_categories` WRITE;
/*!40000 ALTER TABLE `blog_blogpost_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_blogpost_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_blogpost_related_posts`
--

DROP TABLE IF EXISTS `blog_blogpost_related_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_blogpost_related_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_blogpost_id` int(11) NOT NULL,
  `to_blogpost_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `from_blogpost_id` (`from_blogpost_id`,`to_blogpost_id`),
  KEY `blog_blogpos_to_blogpost_id_48f773544ff96fa5_fk_blog_blogpost_id` (`to_blogpost_id`),
  CONSTRAINT `blog_blogp_from_blogpost_id_161efba073ba4d90_fk_blog_blogpost_id` FOREIGN KEY (`from_blogpost_id`) REFERENCES `blog_blogpost` (`id`),
  CONSTRAINT `blog_blogpos_to_blogpost_id_48f773544ff96fa5_fk_blog_blogpost_id` FOREIGN KEY (`to_blogpost_id`) REFERENCES `blog_blogpost` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_blogpost_related_posts`
--

LOCK TABLES `blog_blogpost_related_posts` WRITE;
/*!40000 ALTER TABLE `blog_blogpost_related_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_blogpost_related_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conf_setting`
--

DROP TABLE IF EXISTS `conf_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conf_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `value` varchar(2000) NOT NULL,
  `site_id` int(11) NOT NULL,
  `value_en` varchar(2000) DEFAULT NULL,
  `value_fr` varchar(2000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `conf_setting_site_id_3971204fedfdfec8_fk_django_site_id` (`site_id`),
  CONSTRAINT `conf_setting_site_id_3971204fedfdfec8_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conf_setting`
--

LOCK TABLES `conf_setting` WRITE;
/*!40000 ALTER TABLE `conf_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `conf_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `core_sitepermission`
--

DROP TABLE IF EXISTS `core_sitepermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `core_sitepermission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `core_sitepermission_user_id_d964e296aed9970_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `core_sitepermission`
--

LOCK TABLES `core_sitepermission` WRITE;
/*!40000 ALTER TABLE `core_sitepermission` DISABLE KEYS */;
/*!40000 ALTER TABLE `core_sitepermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `core_sitepermission_sites`
--

DROP TABLE IF EXISTS `core_sitepermission_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `core_sitepermission_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sitepermission_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sitepermission_id` (`sitepermission_id`,`site_id`),
  KEY `core_sitepermission_s_site_id_6dd5fffb45435677_fk_django_site_id` (`site_id`),
  CONSTRAINT `cor_sitepermission_id_64c924a870a6a554_fk_core_sitepermission_id` FOREIGN KEY (`sitepermission_id`) REFERENCES `core_sitepermission` (`id`),
  CONSTRAINT `core_sitepermission_s_site_id_6dd5fffb45435677_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `core_sitepermission_sites`
--

LOCK TABLES `core_sitepermission_sites` WRITE;
/*!40000 ALTER TABLE `core_sitepermission_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `core_sitepermission_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `djang_content_type_id_697914295151027a_fk_django_content_type_id` (`content_type_id`),
  KEY `django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id` (`user_id`),
  CONSTRAINT `djang_content_type_id_697914295151027a_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=127 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (1,'2016-02-25 12:52:02','1','Programme',1,'',16,1),(2,'2016-02-25 12:52:49','2','Artistes',1,'',16,1),(3,'2016-02-25 13:06:47','3','Vidéos',1,'',16,1),(4,'2016-02-25 13:07:09','3','Vidéos',2,'Modifié slug.',16,1),(5,'2016-02-25 14:42:59','4','Infos/Réservations',1,'',15,1),(6,'2016-02-25 14:43:49','4','Infos/Réservations',2,'Modifié content_fr, content_en, slug, description_fr, description_en et keywords.',15,1),(7,'2016-02-25 14:44:42','5','Académie',1,'',15,1),(8,'2016-02-25 14:47:57','2','CHRISTINA BRANCO',1,'',28,1),(9,'2016-02-25 14:49:31','3','CHRISTINA BRANCO',1,'',28,1),(10,'2016-02-25 14:50:08','4','CHRISTINA BRANCO',1,'',28,1),(11,'2016-02-25 14:52:24','1','Test',1,'',29,1),(12,'2016-02-25 15:06:27','5','CHRISTINA BRANCO',1,'',28,1),(13,'2016-02-29 10:23:31','6','Expositions',1,'',15,1),(14,'2016-02-29 10:23:44','7','Sciences',1,'',15,1),(15,'2016-02-29 10:23:52','6','Expositions',2,'Modifié title_en et keywords.',15,1),(16,'2016-02-29 10:28:44','5','CHRISTINA BRANCO',2,'Modifié keywords, bio_fr et bio_en.',28,1),(17,'2016-02-29 10:29:48','5','CHRISTINA BRANCO',2,'Modifié keywords, bio_fr, bio_en et photo.',28,1),(18,'2016-02-29 10:30:24','5','CHRISTINA BRANCO',2,'Modifié keywords, bio_fr, bio_en, photo et photo_credits.',28,1),(19,'2016-02-29 15:00:35','8','Partenaires',1,'Ajout.',15,1),(20,'2016-02-29 16:23:35','6','THIERRY DE MEY',1,'Ajout.',28,1),(21,'2016-02-29 16:27:01','6','THIERRY DE MEY',2,'Modification de title_en, description_fr, description_en, keywords, content_fr, bio_fr, bio_en, photo_credits et featured.',28,1),(22,'2016-02-29 16:28:30','6','THIERRY DE MEY',2,'Modification de keywords, bio_fr, bio_en et featured.',28,1),(23,'2016-02-29 16:28:49','6','THIERRY DE MEY',2,'Modification de description_fr, keywords, bio_fr et bio_en.',28,1),(24,'2016-02-29 16:44:10','6','THIERRY DE MEY',2,'Modification de description_fr, gen_description, keywords, bio_fr et bio_en.',28,1),(25,'2016-02-29 16:44:21','6','THIERRY DE MEY',2,'Modification de description_en, keywords, bio_fr et bio_en.',28,1),(26,'2016-02-29 16:44:58','6','THIERRY DE MEY',2,'Modification de keywords, bio_fr, bio_en et photo.',28,1),(27,'2016-02-29 16:47:07','6','THIERRY DE MEY',2,'Modification de keywords, bio_fr, bio_en et photo.',28,1),(28,'2016-02-29 16:47:37','6','THIERRY DE MEY',2,'Modification de keywords, bio_fr, bio_en, photo et featured.',28,1),(29,'2016-02-29 16:49:42','6','THIERRY DE MEY',2,'Modification de keywords, bio_fr, bio_en et photo.',28,1),(30,'2016-02-29 17:03:02','6','THIERRY DE MEY',2,'Modification de keywords, bio_fr, bio_en et photo.',28,1),(31,'2016-02-29 17:03:51','6','THIERRY DE MEY',2,'Modification de keywords, bio_fr, bio_en et photo.',28,1),(32,'2016-02-29 17:05:08','6','THIERRY DE MEY',2,'Modification de keywords, bio_fr, bio_en, photo et photo_featured.',28,1),(33,'2016-02-29 17:19:00','7','LAURENT MARIUSSE',1,'Ajout.',28,1),(34,'2016-02-29 17:20:43','7','LAURENT MARIUSSE',2,'Modification de keywords, bio_fr, bio_en, photo, photo_credits et photo_alignment.',28,1),(35,'2016-02-29 17:23:21','7','LAURENT MARIUSSE',2,'Modification de keywords, bio_fr, bio_en et photo.',28,1),(36,'2016-02-29 17:23:47','5','CHRISTINA BRANCO',3,'',28,1),(37,'2016-02-29 17:24:59','6','THIERRY DE MEY',2,'Modification de description_fr, keywords, bio_fr, bio_en, photo et photo_featured.',28,1),(38,'2016-02-29 17:25:29','7','LAURENT MARIUSSE',2,'Modification de keywords, bio_fr, bio_en et photo.',28,1),(39,'2016-02-29 17:28:27','8','YAN MARESZ',1,'Ajout.',28,1),(40,'2016-02-29 17:31:02','8','YAN MARESZ',2,'Modification de keywords, bio_fr, photo, photo_credits, featured et photo_featured.',28,1),(41,'2016-02-29 17:34:27','7','LAURENT MARIUSSE',2,'Modification de keywords, bio_fr, bio_en, photo, featured et photo_featured.',28,1),(42,'2016-02-29 17:41:56','9','STEVEN SCHICK',1,'Ajout.',28,1),(43,'2016-02-29 17:42:32','9','STEVEN SCHICK',2,'Modification de keywords, bio_fr, bio_en, photo_alignment et photo_featured.',28,1),(44,'2016-02-29 17:44:09','9','STEVEN SCHICK',2,'Modification de keywords, bio_fr, bio_en, featured et photo_featured.',28,1),(45,'2016-02-29 17:44:40','9','STEVEN SCHICK',2,'Modification de keywords, bio_fr, bio_en et photo_featured.',28,1),(46,'2016-02-29 17:45:43','6','THIERRY DE MEY',2,'Modification de keywords, bio_fr, bio_en, photo et photo_featured.',28,1),(47,'2016-02-29 17:46:09','7','LAURENT MARIUSSE',2,'Modification de keywords, bio_fr, bio_en, photo et photo_featured.',28,1),(48,'2016-02-29 17:51:15','10','REMMY CANEDO',1,'Ajout.',28,1),(49,'2016-02-29 17:53:30','10','REMMY CANEDO',2,'Modification de description_en, keywords, bio_fr et bio_en.',28,1),(50,'2016-02-29 17:55:53','6','THIERRY DE MEY',2,'Modification de keywords, bio_fr, bio_en, photo et photo_featured.',28,1),(51,'2016-02-29 18:10:59','6','THIERRY DE MEY',2,'Modification de description_fr, keywords, bio_fr, bio_en, photo et photo_featured.',28,1),(52,'2016-02-29 18:13:55','7','LAURENT MARIUSSE',2,'Modification de description_fr, keywords, bio_fr, bio_en, photo et photo_featured.',28,1),(53,'2016-02-29 18:14:24','6','THIERRY DE MEY',2,'Modification de keywords, bio_fr, bio_en, photo et photo_featured.',28,1),(54,'2016-02-29 18:16:39','9','STEVEN SCHICK',2,'Modification de keywords, bio_fr, bio_en et photo_featured.',28,1),(55,'2016-02-29 18:20:05','6','THIERRY DE MEY',2,'Modification de keywords, bio_fr, bio_en, photo et photo_featured.',28,1),(56,'2016-02-29 18:20:45','7','LAURENT MARIUSSE',2,'Modification de keywords, bio_fr, bio_en, photo et photo_featured.',28,1),(57,'2016-02-29 18:21:33','9','STEVEN SCHICK',2,'Modification de keywords, bio_fr, bio_en et photo_featured.',28,1),(58,'2016-02-29 18:22:21','10','REMMY CANEDO',2,'Modification de keywords, bio_fr et bio_en.',28,1),(59,'2016-02-29 18:25:53','11','AURELIANO CATTANEO',1,'Ajout.',28,1),(60,'2016-02-29 18:30:21','12','DANIEL D\'ADAMO',1,'Ajout.',28,1),(61,'2016-02-29 18:34:18','13','LAURENT DURUPT',1,'Ajout.',28,1),(62,'2016-02-29 18:38:41','14','ENSEMBLE INTERCONTEMPORAIN',1,'Ajout.',28,1),(63,'2016-03-01 11:20:22','13','LAURENT DURUPT',2,'Modification de keywords, bio_fr, bio_en, photo et photo_credits.',28,1),(64,'2016-03-01 11:21:44','13','LAURENT DURUPT',2,'Modification de keywords, bio_fr, bio_en, photo, featured et photo_featured.',28,1),(65,'2016-03-01 11:24:50','7','LAURENT MARIUSSE',2,'Modification de keywords, bio_fr, bio_en, photo, photo_credits et photo_featured.',28,1),(66,'2016-03-01 11:25:23','7','LAURENT MARIUSSE',2,'Modification de keywords, bio_fr, bio_en et photo_featured.',28,1),(67,'2016-03-01 11:26:07','8','YAN MARESZ',2,'Modification de keywords, bio_fr, photo et photo_featured.',28,1),(68,'2016-03-01 11:29:27','10','REMMY CANEDO',2,'Modification de keywords, bio_fr, bio_en, photo, photo_credits, featured et photo_featured.',28,1),(69,'2016-03-01 11:29:43','10','REMMY CANEDO',2,'Modification de keywords, bio_fr, bio_en, photo, photo_alignment et photo_featured.',28,1),(70,'2016-03-01 11:29:58','10','REMMY CANEDO',2,'Modification de keywords, bio_fr, bio_en, photo, photo_alignment et photo_featured.',28,1),(71,'2016-03-01 11:32:26','11','AURELIANO CATTANEO',2,'Modification de keywords, bio_fr, bio_en, photo, photo_credits, featured et photo_featured.',28,1),(72,'2016-03-01 11:35:27','12','DANIEL D\'ADAMO',2,'Modification de keywords, bio_fr, bio_en, photo, photo_credits et photo_featured.',28,1),(73,'2016-03-01 11:36:08','12','DANIEL D\'ADAMO',2,'Modification de keywords, bio_fr, bio_en, photo, photo_credits et photo_featured.',28,1),(74,'2016-03-01 11:36:29','12','DANIEL D\'ADAMO',2,'Modification de keywords, bio_fr, bio_en et photo_featured.',28,1),(75,'2016-03-01 11:43:04','14','ENSEMBLE INTERCONTEMPORAIN',2,'Modification de keywords, bio_fr, bio_en et photo_featured.',28,1),(76,'2016-03-01 11:48:12','15','BEAT FURRER',1,'Ajout.',28,1),(77,'2016-03-01 11:49:41','15','BEAT FURRER',2,'Modification de keywords, bio_fr, bio_en, photo et photo_featured.',28,1),(78,'2016-03-01 11:51:00','16','THOMAS HAUERT',1,'Ajout.',28,1),(79,'2016-03-01 11:53:45','16','THOMAS HAUERT',2,'Modification de description_fr, description_en, keywords, bio_fr et bio_en.',28,1),(80,'2016-03-01 11:56:38','16','THOMAS HAUERT',2,'Modification de keywords, bio_fr, bio_en et photo_featured.',28,1),(81,'2016-03-01 12:14:29','17','MAURO LANZA',1,'Ajout.',28,1),(82,'2016-03-01 12:18:05','17','MAURO LANZA',2,'Modification de keywords, bio_fr, bio_en et photo_featured.',28,1),(83,'2016-03-01 12:23:28','18','PHILIPPE LEROUX',1,'Ajout.',28,1),(84,'2016-03-01 12:27:53','18','PHILIPPE LEROUX',2,'Modification de keywords, bio_fr, bio_en et photo_featured.',28,1),(85,'2016-03-01 12:37:58','19','DONATIENNE MICHEL-DANSAC',1,'Ajout.',28,1),(86,'2016-03-01 12:43:11','20','MARCO MOMI',1,'Ajout.',28,1),(87,'2016-03-01 12:49:52','20','MARCO MOMI',2,'Modification de keywords, bio_fr, bio_en, photo, photo_credits et photo_featured.',28,1),(88,'2016-03-01 12:54:27','21','EMANUELE PALUMBO',1,'Ajout.',28,1),(89,'2016-03-01 13:04:29','22','JÉRÔME THOMAS',1,'Ajout.',28,1),(90,'2016-03-01 13:07:53','22','JÉRÔME THOMAS',2,'Modification de keywords, bio_fr, bio_en et photo_featured.',28,1),(91,'2016-03-01 15:05:48','23','SALVATORE SCIARRINO',1,'Ajout.',28,1),(92,'2016-03-01 15:13:03','24','MARIANGELA VACATELLO',1,'Ajout.',28,1),(93,'2016-03-01 15:18:26','25','JAMES WOOD',1,'Ajout.',28,1),(94,'2016-03-01 15:28:08','25','JAMES WOOD',2,'Modification de keywords, bio_fr, bio_en, photo, photo_credits et photo_featured.',28,1),(95,'2016-03-01 15:35:02','26','JOHANNA ZIMMER',1,'Ajout.',28,1),(96,'2016-03-01 15:42:59','27','GÉRARD PESSON',1,'Ajout.',28,1),(97,'2016-03-01 16:03:20','28','REBECCA SAUNDERS',1,'Ajout.',28,1),(98,'2016-03-01 16:16:09','29','PHILIPPE MANOURY',1,'Ajout.',28,1),(99,'2016-03-01 16:19:09','30','XAVIER LE ROY',1,'Ajout.',28,1),(100,'2016-03-01 16:21:04','30','XAVIER LE ROY',2,'Modification de keywords, bio_fr, bio_en, photo, photo_credits et photo_featured.',28,1),(101,'2016-03-01 16:28:55','31','OLIVIER CADIOT',1,'Ajout.',28,1),(102,'2016-03-01 16:30:47','32','CLOTILDE HESMES',1,'Ajout.',28,1),(103,'2016-03-01 16:34:06','33','LAURENT POITNERAUX',1,'Ajout.',28,1),(104,'2016-03-01 16:37:45','34','BENOÎT DELBECQ',1,'Ajout.',28,1),(105,'2016-03-01 16:48:29','35','TOMAS BORDALEJO',1,'Ajout.',28,1),(106,'2016-03-01 16:58:21','36','HEINER GOEBBELS',1,'Ajout.',28,1),(107,'2016-03-01 17:28:14','37','JULIEN LEROY',1,'Ajout.',28,1),(108,'2016-03-01 17:52:05','38','ORCHESTRE PHILHARMONIQUE DE RADIO FRANCE',1,'Ajout.',28,1),(109,'2016-03-01 18:04:36','39','DYLAN CORLAY',1,'Ajout.',28,1),(110,'2016-03-02 12:26:10','4','Infos/Réservations',2,'Modification de content_fr, content_en, description_fr, description_en et keywords.',15,1),(111,'2016-03-02 12:28:43','39','DYLAN CORLAY',2,'Modification de keywords, bio_fr, bio_en et photo_featured.',28,1),(112,'2016-03-02 12:29:07','39','DYLAN CORLAY',2,'Modification de keywords, bio_fr, bio_en et photo_featured.',28,1),(113,'2016-03-02 17:52:22','4','Infos/Réservations',2,'Modification de content_fr, content_en, description_en et keywords.',15,1),(114,'2016-03-02 17:52:42','4','Infos/Réservations',2,'Modification de content_fr, content_en, description_fr, description_en et keywords.',15,1),(115,'2016-03-02 17:52:53','4','Infos/Réservations',2,'Modification de content_fr, content_en, description_fr, description_en et keywords.',15,1),(116,'2016-03-02 17:54:37','4','Infos/Réservations',2,'Modification de content_fr, content_en, description_fr, description_en et keywords.',15,1),(117,'2016-03-02 17:59:26','8','Partenaires',2,'Modification de in_menus et keywords.',15,1),(118,'2016-03-02 18:01:47','9','Espace presse',1,'Ajout.',15,1),(119,'2016-03-02 18:02:05','10','Soutenir l\'Ircam',1,'Ajout.',15,1),(120,'2016-03-02 18:02:23','11','Contacts / Équipes',1,'Ajout.',15,1),(121,'2016-03-02 18:03:05','12','Lieux',1,'Ajout.',15,1),(122,'2016-03-02 18:23:34','5','Académie',2,'Modification de keywords.',15,1),(123,'2016-03-03 11:54:46','5','Académie',2,'Modification de content_fr et keywords.',15,1),(124,'2016-03-03 11:55:58','5','Académie',2,'Modification de content_fr et keywords.',15,1),(125,'2016-03-03 11:57:17','5','Académie',2,'Modification de content_fr et keywords.',15,1),(126,'2016-03-03 11:57:35','5','Académie',2,'Modification de content_fr et keywords.',15,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_comment_flags`
--

DROP TABLE IF EXISTS `django_comment_flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_comment_flags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `flag` varchar(30) NOT NULL,
  `flag_date` datetime NOT NULL,
  `comment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_comment_flags_user_id_c7a132a641f11c1_uniq` (`user_id`,`comment_id`,`flag`),
  KEY `django_comment__comment_id_26f904a7f2b4c55_fk_django_comments_id` (`comment_id`),
  KEY `django_comment_flags_327a6c43` (`flag`),
  CONSTRAINT `django_comment__comment_id_26f904a7f2b4c55_fk_django_comments_id` FOREIGN KEY (`comment_id`) REFERENCES `django_comments` (`id`),
  CONSTRAINT `django_comment_flags_user_id_1442753a03512f4c_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_comment_flags`
--

LOCK TABLES `django_comment_flags` WRITE;
/*!40000 ALTER TABLE `django_comment_flags` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_comment_flags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_comments`
--

DROP TABLE IF EXISTS `django_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_pk` longtext NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_email` varchar(254) NOT NULL,
  `user_url` varchar(200) NOT NULL,
  `comment` longtext NOT NULL,
  `submit_date` datetime NOT NULL,
  `ip_address` char(39) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL,
  `is_removed` tinyint(1) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `djang_content_type_id_39798e235626a505_fk_django_content_type_id` (`content_type_id`),
  KEY `django_comments_site_id_48b7896f6ea83216_fk_django_site_id` (`site_id`),
  KEY `django_comments_user_id_20e3794dfd3a7b1e_fk_auth_user_id` (`user_id`),
  CONSTRAINT `djang_content_type_id_39798e235626a505_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_comments_site_id_48b7896f6ea83216_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`),
  CONSTRAINT `django_comments_user_id_20e3794dfd3a7b1e_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_comments`
--

LOCK TABLES `django_comments` WRITE;
/*!40000 ALTER TABLE `django_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_45f3b1d93ec8c61c_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (34,'admin','logentry'),(2,'auth','group'),(1,'auth','permission'),(3,'auth','user'),(18,'blog','blogcategory'),(17,'blog','blogpost'),(8,'conf','setting'),(4,'contenttypes','contenttype'),(9,'core','sitepermission'),(35,'django_comments','comment'),(36,'django_comments','commentflag'),(28,'festival','artist'),(30,'festival','eventcategory'),(27,'festival','festivalevent'),(31,'festival','pagecategory'),(29,'festival','video'),(20,'forms','field'),(22,'forms','fieldentry'),(19,'forms','form'),(21,'forms','formentry'),(23,'galleries','gallery'),(24,'galleries','galleryimage'),(12,'generic','assignedkeyword'),(11,'generic','keyword'),(13,'generic','rating'),(10,'generic','threadedcomment'),(32,'mezzanine_agenda','event'),(33,'mezzanine_agenda','eventlocation'),(16,'pages','link'),(14,'pages','page'),(15,'pages','richtextpage'),(5,'redirects','redirect'),(6,'sessions','session'),(7,'sites','site'),(25,'twitter','query'),(26,'twitter','tweet');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=54 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2016-02-25 04:02:09'),(2,'auth','0001_initial','2016-02-25 04:02:11'),(3,'admin','0001_initial','2016-02-25 04:02:12'),(4,'contenttypes','0002_remove_content_type_name','2016-02-25 04:02:12'),(5,'auth','0002_alter_permission_name_max_length','2016-02-25 04:02:12'),(6,'auth','0003_alter_user_email_max_length','2016-02-25 04:02:12'),(7,'auth','0004_alter_user_username_opts','2016-02-25 04:02:12'),(8,'auth','0005_alter_user_last_login_null','2016-02-25 04:02:12'),(9,'auth','0006_require_contenttypes_0002','2016-02-25 04:02:12'),(10,'sites','0001_initial','2016-02-25 04:02:12'),(11,'blog','0001_initial','2016-02-25 04:02:13'),(12,'blog','0002_auto_20150527_1555','2016-02-25 04:02:14'),(13,'blog','0003_auto_20151223_1313','2016-02-25 04:02:15'),(14,'conf','0001_initial','2016-02-25 04:02:15'),(15,'conf','0002_auto_20151223_1313','2016-02-25 04:02:15'),(16,'core','0001_initial','2016-02-25 04:02:15'),(17,'core','0002_auto_20150414_2140','2016-02-25 04:02:16'),(18,'django_comments','0001_initial','2016-02-25 04:02:17'),(19,'django_comments','0002_update_user_email_field_length','2016-02-25 04:02:17'),(20,'mezzanine_agenda','0001_initial','2016-02-25 04:02:18'),(21,'mezzanine_agenda','0002_auto_20160224_1142','2016-02-25 04:02:18'),(22,'festival','0001_initial','2016-02-25 04:02:19'),(23,'festival','0002_auto_20160224_1243','2016-02-25 04:02:20'),(24,'festival','0003_auto_20160224_1835','2016-02-25 04:02:22'),(25,'festival','0004_auto_20160225_0352','2016-02-25 04:02:23'),(26,'festival','0005_auto_20160225_0500','2016-02-25 04:02:25'),(27,'pages','0001_initial','2016-02-25 04:02:26'),(28,'forms','0001_initial','2016-02-25 04:02:27'),(29,'forms','0002_auto_20141227_0224','2016-02-25 04:02:27'),(30,'forms','0003_emailfield','2016-02-25 04:02:27'),(31,'forms','0004_auto_20150517_0510','2016-02-25 04:02:27'),(32,'forms','0005_auto_20151223_1313','2016-02-25 04:02:30'),(33,'galleries','0001_initial','2016-02-25 04:02:31'),(34,'galleries','0002_auto_20141227_0224','2016-02-25 04:02:31'),(35,'galleries','0003_auto_20151223_1313','2016-02-25 04:02:32'),(36,'generic','0001_initial','2016-02-25 04:02:33'),(37,'generic','0002_auto_20141227_0224','2016-02-25 04:02:33'),(38,'pages','0002_auto_20141227_0224','2016-02-25 04:02:34'),(39,'pages','0003_auto_20150527_1555','2016-02-25 04:02:34'),(40,'pages','0004_auto_20151223_1313','2016-02-25 04:02:35'),(41,'redirects','0001_initial','2016-02-25 04:02:36'),(42,'sessions','0001_initial','2016-02-25 04:02:36'),(43,'twitter','0001_initial','2016-02-25 04:02:36'),(44,'festival','0006_auto_20160225_0503','2016-02-25 04:04:01'),(45,'festival','0007_auto_20160225_1214','2016-02-25 11:14:53'),(46,'festival','0008_auto_20160225_1218','2016-02-25 11:19:01'),(47,'festival','0002_auto_20160225_1602','2016-02-25 15:02:15'),(48,'admin','0002_logentry_remove_auto_add','2016-02-29 14:39:29'),(49,'auth','0007_alter_validators_add_error_messages','2016-02-29 14:39:29'),(50,'sites','0002_alter_domain_unique','2016-02-29 14:39:39'),(51,'festival','0003_auto_20160229_1430','2016-02-29 14:57:42'),(52,'festival','0004_auto_20160229_1630','2016-02-29 16:57:45'),(53,'festival','0005_auto_20160229_1636','2016-02-29 17:14:11');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_redirect`
--

DROP TABLE IF EXISTS `django_redirect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_redirect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `old_path` varchar(200) NOT NULL,
  `new_path` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `site_id` (`site_id`,`old_path`),
  KEY `django_redirect_91a0b591` (`old_path`),
  CONSTRAINT `django_redirect_site_id_121a4403f653e524_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_redirect`
--

LOCK TABLES `django_redirect` WRITE;
/*!40000 ALTER TABLE `django_redirect` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_redirect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_de54fa62` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('4992lmew41r5wt3umc76j48kwl8nhgoi','OTIzYmI2NWNmNzk4NTlhMTY3MTEzNmUyN2ExY2YxN2Q2YTlhNDRlZDp7Il9hdXRoX3VzZXJfaGFzaCI6IjEzMWQ0MzM1M2U5NGZiNmNmMmJkMzg0YjExZTI4YjEwMmFkZTY0Y2YiLCJfYXV0aF91c2VyX2lkIjoiMSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCJ9','2016-03-17 10:31:37'),('5hj1b2mhuzxsq1dfpekthmg924xu2g98','YzM5YTYwMjdhOGM2NTI2OTAwYTM2YzFhMDZmMWNjZDRjNjg4NThiODp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6IjEzMWQ0MzM1M2U5NGZiNmNmMmJkMzg0YjExZTI4YjEwMmFkZTY0Y2YiLCJfbGFuZ3VhZ2UiOiJmciIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=','2016-03-15 18:04:44'),('d2ylfrdchr5svd1lqy86661twp27ptj8','YzM5YTYwMjdhOGM2NTI2OTAwYTM2YzFhMDZmMWNjZDRjNjg4NThiODp7Il9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaGFzaCI6IjEzMWQ0MzM1M2U5NGZiNmNmMmJkMzg0YjExZTI4YjEwMmFkZTY0Y2YiLCJfbGFuZ3VhZ2UiOiJmciIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=','2016-03-16 12:29:11'),('hdcojjw510vty1ot1j6ve5if67tpffdg','NWJlODRhODQ0MjIyMjFiYTA3ZDljYzI2ZWI1NGEzZGI2ZmE0ODY5ZTp7Il9hdXRoX3VzZXJfaGFzaCI6IjJiZmU2MGM0ZTk0YjM2MDNiZDRiNzE3Y2NlOTNiN2IwYWM5YWQ4YTYiLCJfYXV0aF91c2VyX2JhY2tlbmQiOiJtZXp6YW5pbmUuY29yZS5hdXRoX2JhY2tlbmRzLk1lenphbmluZUJhY2tlbmQiLCJfYXV0aF91c2VyX2lkIjoiMSJ9','2016-03-14 09:55:39'),('l5feuac4jdhnnqqcwqteuntt7zba54pj','ZDkwMTJiMWM1NDM0NGY3Njg5NWI3YTQ2ZWVmOWRlMzNkNjFkODYyMDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoibWV6emFuaW5lLmNvcmUuYXV0aF9iYWNrZW5kcy5NZXp6YW5pbmVCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMTMxZDQzMzUzZTk0ZmI2Y2YyYmQzODRiMTFlMjhiMTAyYWRlNjRjZiIsIl9sYW5ndWFnZSI6ImZyIn0=','2016-03-14 15:10:36'),('ohch7p7kwpm8m079a0m2dfr1f37czise','OTIzYmI2NWNmNzk4NTlhMTY3MTEzNmUyN2ExY2YxN2Q2YTlhNDRlZDp7Il9hdXRoX3VzZXJfaGFzaCI6IjEzMWQ0MzM1M2U5NGZiNmNmMmJkMzg0YjExZTI4YjEwMmFkZTY0Y2YiLCJfYXV0aF91c2VyX2lkIjoiMSIsIl9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCJ9','2016-03-17 13:00:15'),('p0ilzzph8xmdhak3m4am95frimg1flz7','NjIwMWE5NWJkMGZkY2ZiNTQ3NjE0NTQ5ODU5ODA4NmY4MjNmNjkzMTp7Il9sYW5ndWFnZSI6ImZyIiwiX2F1dGhfdXNlcl9oYXNoIjoiMmJmZTYwYzRlOTRiMzYwM2JkNGI3MTdjY2U5M2I3YjBhYzlhZDhhNiIsIl9hdXRoX3VzZXJfYmFja2VuZCI6Im1lenphbmluZS5jb3JlLmF1dGhfYmFja2VuZHMuTWV6emFuaW5lQmFja2VuZCIsIl9hdXRoX3VzZXJfaWQiOiIxIn0=','2016-03-10 14:43:36'),('pzc5qheknqm8e9gmok7p90u1q9rihlxv','MGRiYTMxYjg1NWFhN2UyZjBlZDQyNmY0ZmJlYjM5MWFjMTA2NDJiNzp7Il9hdXRoX3VzZXJfaGFzaCI6IjEzMWQ0MzM1M2U5NGZiNmNmMmJkMzg0YjExZTI4YjEwMmFkZTY0Y2YiLCJfbGFuZ3VhZ2UiOiJmciIsIl9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoibWV6emFuaW5lLmNvcmUuYXV0aF9iYWNrZW5kcy5NZXp6YW5pbmVCYWNrZW5kIn0=','2016-03-14 18:38:57'),('uvyzl4pio1ql48zo60bcketh1ph98b3a','ZWMxNjk4ZjE0MGRmZDZkYjk5OTc3YTU0YzkyODJjMGYzYTViNTU3ODp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoibWV6emFuaW5lLmNvcmUuYXV0aF9iYWNrZW5kcy5NZXp6YW5pbmVCYWNrZW5kIiwiX2F1dGhfdXNlcl9oYXNoIjoiMTMxZDQzMzUzZTk0ZmI2Y2YyYmQzODRiMTFlMjhiMTAyYWRlNjRjZiJ9','2016-03-14 14:57:53');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_site`
--

DROP TABLE IF EXISTS `django_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_site_domain_a2e37b91_uniq` (`domain`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_site`
--

LOCK TABLES `django_site` WRITE;
/*!40000 ALTER TABLE `django_site` DISABLE KEYS */;
INSERT INTO `django_site` VALUES (1,'example.com','example.com');
/*!40000 ALTER TABLE `django_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_artists`
--

DROP TABLE IF EXISTS `festival_artists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_artists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `photo` varchar(1024) NOT NULL,
  `photo_credits` varchar(255) DEFAULT NULL,
  `bio` longtext NOT NULL,
  `bio_en` longtext,
  `bio_fr` longtext,
  `description` longtext NOT NULL,
  `description_en` longtext,
  `description_fr` longtext,
  `featured` tinyint(1) NOT NULL,
  `_meta_title` varchar(500) DEFAULT NULL,
  `content` longtext NOT NULL,
  `created` datetime DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `gen_description` tinyint(1) NOT NULL,
  `in_sitemap` tinyint(1) NOT NULL,
  `keywords_string` varchar(500) NOT NULL,
  `publish_date` datetime DEFAULT NULL,
  `short_url` varchar(200) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `status` int(11) NOT NULL,
  `title` varchar(500) NOT NULL,
  `updated` datetime DEFAULT NULL,
  `content_en` longtext,
  `content_fr` longtext,
  `title_en` varchar(500) DEFAULT NULL,
  `title_fr` varchar(500) DEFAULT NULL,
  `photo_description` longtext NOT NULL,
  `photo_alignment` varchar(32) NOT NULL,
  `photo_featured` varchar(1024) NOT NULL,
  `photo_featured_credits` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `festival_artists_76776489` (`publish_date`),
  KEY `festival_artists_9365d6e7` (`site_id`),
  CONSTRAINT `festival_artists_site_id_4d352837add8db1a_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_artists`
--

LOCK TABLES `festival_artists` WRITE;
/*!40000 ALTER TABLE `festival_artists` DISABLE KEYS */;
INSERT INTO `festival_artists` VALUES (6,'uploads/images/photos/thierry_de_mey.jpg','Thierry De Mey © Thibault Grégoire','<p>Thierry De Mey is a composer and film director. His work follows his intuition of movement, \"refusing to conceive rythym as a simple combination of lengths of time within a temporal frame, but as a system that generates leaps and falls and new developments\". A part of his production is intended for dance and cinema. For the choreographers A.T. De Keersmaeker, W. Vandekeybus, and M.A. De Mey, the issue is not composing, but working together on the invention of “formal strategies”.</p>\n<p>An active educator, Thierry De Mey has headed the <em>cursus de composition chorégraphique P.A.R.T.S. </em>program in Brusselles since its establishment and, since 2005, has been a part of the artistic directors of Charleroi/Danses.</p>\n<p>Futher information <a href=\"http://www.charleroi-danses.be/en/59-contacts/artistes/artistes-associes/2122-therry-de-mey1\">Thierry De Mey</a></p>','<p>Thierry De Mey is a composer and film director. His work follows his intuition of movement, \"refusing to conceive rythym as a simple combination of lengths of time within a temporal frame, but as a system that generates leaps and falls and new developments\". A part of his production is intended for dance and cinema. For the choreographers A.T. De Keersmaeker, W. Vandekeybus, and M.A. De Mey, the issue is not composing, but working together on the invention of “formal strategies”.</p>\n<p>An active educator, Thierry De Mey has headed the <em>cursus de composition chorégraphique P.A.R.T.S. </em>program in Brusselles since its establishment and, since 2005, has been a part of the artistic directors of Charleroi/Danses.</p>\n<p>Futher information <a href=\"http://www.charleroi-danses.be/en/59-contacts/artistes/artistes-associes/2122-therry-de-mey1\">Thierry De Mey</a></p>','<p>Thierry De Mey est compositeur et réalisateur de films. Son travail est guidé par l\'intuition du mouvement : « refuser de concevoir le rythme comme simple combinatoire de durées à l\'intérieur d\'une grille temporelle, mais bien comme système générateur d\'élans, de chutes et de développements nouveaux ». Une partie de sa production est destinée à la danse et au cinéma. Pour les chorégraphes A. T. De Keersmaeker, W. Vandekeybus et M. A. De Mey, il n\'est pas compositeur mais collaborateur dans l\'invention de « stratégies formelles ».</p>\n<p>Exerçant une intense activité pédagogique, il dirige notamment le cursus de composition chorégraphique P.A.R.T.S. à Bruxelles depuis sa fondation et, depuis 2005, fait partie de la direction artistique de Charleroi Danses.</p>\n<p>Plus d\'informations sur <a href=\"http://www.charleroi-danses.be/en/59-contacts/artistes/artistes-associes/2122-therry-de-mey1\">Thierry De Mey</a></p>','Thierry De Mey is a composer and film director. His work follows his intuition of movement.','Thierry De Mey is a composer and film director. His work follows his intuition of movement.','Thierry De Mey est compositeur et réalisateur de films. Son travail est guidé par l\'intuition du mouvement...',1,'','','2016-02-29 16:23:35',NULL,0,1,'','2016-02-29 14:56:13','',1,'thierry-de-mey',2,'THIERRY DE MEY','2016-02-29 18:20:05','','','THIERRY DE MEY','THIERRY DE MEY','','left','uploads/images/photos/thierry_de_mey.jpg',''),(7,'','','<p>In 1994, Laurent Mariusse began studying at the CNSMD de Lyon, specializing in contemporary music. His encounters with composers such as Pierre Boulez, Peter Eötvos, Daniel Tosi, and François-Bernard Mâche were decisive in his future career. He worked with composers Marie Hélène Fournier, François Nicolas, Yves Prin, Jean Philippe Calvin, Pierre Jodlowski, and Emmanuel Séjourné on the premiere of works for solo percussion.</p>\n<p><img alt=\"Laurent Mariusse © Thierry Wagner\" height=\"667\" src=\"/media/uploads/images/photos/laurent_mariusse_3.jpg\" width=\"1000\"></p>\n<p>Musician seeking multidisciplinary situations, he has premiered music for theater and musical theater, notably in collaboration with Yves Prin. A fan of improvised music, he has performed with OMax software for improvisation perfected by Gérard Assayag and the composer François Nicolas. Mariusse also improvises music for animated films with the trio USB.</p>\n<p>Futher information <a href=\"http://laurentmariusse.com/\">Laurent Mariusse</a></p>','<p>In 1994, Laurent Mariusse began studying at the CNSMD de Lyon, specializing in contemporary music. His encounters with composers such as Pierre Boulez, Peter Eötvos, Daniel Tosi, and François-Bernard Mâche were decisive in his future career. He worked with composers Marie Hélène Fournier, François Nicolas, Yves Prin, Jean Philippe Calvin, Pierre Jodlowski, and Emmanuel Séjourné on the premiere of works for solo percussion.</p>\n<p><img alt=\"Laurent Mariusse © Thierry Wagner\" height=\"667\" src=\"/media/uploads/images/photos/laurent_mariusse_3.jpg\" width=\"1000\"></p>\n<p>Musician seeking multidisciplinary situations, he has premiered music for theater and musical theater, notably in collaboration with Yves Prin. A fan of improvised music, he has performed with OMax software for improvisation perfected by Gérard Assayag and the composer François Nicolas. Mariusse also improvises music for animated films with the trio USB.</p>\n<p>Futher information <a href=\"http://laurentmariusse.com/\">Laurent Mariusse</a></p>','<p>Laurent Mariusse intègre en 1994 le CNSMD de Lyon, s\'orientant vers une spécialité musique contemporaine. Il côtoie les compositeurs Pierre Boulez, Peter Eötvos, Daniel Tosi, François-Bernard Mâche, des rencontres décisives dans l\'orientation de sa carrière. Il collabore avec les compositeurs Marie Hélène Fournier, François Nicolas, Jean Philippe Calvin, Pierre Jodlowski, Emmanuel Séjourné à la création de pièces pour percussion solo.</p>\n<p><img alt=\"Laurent Mariusse © Thierry Wagner\" height=\"667\" src=\"/media/uploads/images/photos/laurent_mariusse_3.jpg\" width=\"1000\"></p>\n<p>Musicien en quête de pluridisciplinarité, il crée musiques de scènes et spectacles musicaux, notamment en collaboration avec Yves Prin ou Philippe Morier-Genoud. Passionné de musiques improvisées, il joue avec le logiciel d\'improvisation OMax mis au point par Gérard Assayag et le compositeur François Nicolas, et improvise sur des films d’animation avec le trio USB.</p>\n<p>Plus d\'informations sur <a href=\"http://laurentmariusse.com/\">Laurent Mariusse</a></p>','In 1994, Laurent Mariusse began studying at the CNSMD de Lyon, specializing in contemporary music. His encounters with composers such as Pierre Boulez, Peter Eötvos, Daniel Tosi, and François-Bernard Mâche.','In 1994, Laurent Mariusse began studying at the CNSMD de Lyon, specializing in contemporary music. His encounters with composers such as Pierre Boulez, Peter Eötvos, Daniel Tosi, and François-Bernard Mâche.','Laurent Mariusse intègre en 1994 le CNSMD de Lyon, s\'orientant vers une spécialité musique contemporaine. Il côtoie les compositeurs Pierre Boulez, Peter Eötvos, Daniel Tosi, François-Bernard Mâche...',1,'','','2016-02-29 17:19:00',NULL,0,1,'','2016-02-29 15:52:17','',1,'laurent-mariusse',2,'LAURENT MARIUSSE','2016-03-01 11:25:23','','','LAURENT MARIUSSE','LAURENT MARIUSSE','','','uploads/images/photos/laurent_mariusse_1.jpg',''),(8,'uploads/images/photos/yan_maresz.jpg','Yan Maresz © Guillaume Chauvin','<p>Yan Maresz studied piano and percussion in Monte Carlo before teaching himself rock and jazz guitar. He was the student, orchestrator, and arranger of guitarist John McLaughlin, studied jazz at Berklee College of Music (1984-1986), studied composition at the Juilliard School, and completed his training with David Diamond (1992). Maresz followed the Cursus program at IRCAM with Tristan Murail in 1993. An active instructor, Maresz was a composer in residence at the Strasbourg conservatory in 2003-04, guest professor at McGill University in Montreal in 2004-05, a composition instructor at IRCAM from 2006 to 2011, and currently teaches orchestration and electroacoustics and the CNSMD de Paris and the CRR de Boulogne-Billancourt.</p>','<p>Yan Maresz studied piano and percussion in Monte Carlo before teaching himself rock and jazz guitar. He was the student, orchestrator, and arranger of guitarist John McLaughlin, studied jazz at Berklee College of Music (1984-1986), studied composition at the Juilliard School, and completed his training with David Diamond (1992). Maresz followed the Cursus program at IRCAM with Tristan Murail in 1993. An active instructor, Maresz was a composer in residence at the Strasbourg conservatory in 2003-04, guest professor at McGill University in Montreal in 2004-05, a composition instructor at IRCAM from 2006 to 2011, and currently teaches orchestration and electroacoustics and the CNSMD de Paris and the CRR de Boulogne-Billancourt.</p>','<p>Yan Maresz étudie le piano et la percussion à Monte-Carlo puis se consacre à la guitare rock et jazz en autodidacte. Il est élève, orchestrateur et arrangeur du guitariste John McLaughlin, étudie le jazz au Berklee College of Music (1984-1986) puis s\'oriente vers la composition en intégrant la Juilliard School et complète sa formation avec David Diamond (1992). Il suit le cursus de composition et d\'informatique musicale de l\'Ircam auprès de Tristan Murail (1993).</p>\n<p>Maresz enseigne activement : compositeur en résidence au conservatoire de Strasbourg (2003-2004), professeur invité à l\'université McGill à Montréal (2004-2005), il enseigne la composition à l\'Ircam (2006-2011) et est actuellement professeur d\'orchestration et d\'électroacoustique au Conservatoire de Paris et au CRR de Boulogne-Billancourt.</p>','Yan Maresz studied piano and percussion in Monte Carlo before teaching himself rock and jazz guitar. He was the student, orchestrator, and arranger of guitarist John McLaughlin','Yan Maresz studied piano and percussion in Monte Carlo before teaching himself rock and jazz guitar. He was the student, orchestrator, and arranger of guitarist John McLaughlin','Yan Maresz étudie le piano et la percussion à Monte-Carlo puis se consacre à la guitare rock et jazz en autodidacte. Il est élève, orchestrateur et arrangeur du guitariste John McLaughlin',1,'','','2016-02-29 17:28:27',NULL,0,1,'','2016-02-29 16:01:00','',1,'yan-maresz',2,'YAN MARESZ','2016-03-01 11:26:07','','','YAN MARESZ','YAN MARESZ','','left','uploads/images/photos/yan_maresz.jpg',''),(9,'','','<p>For over 30 years, Steven Schick has been the champion of contemporary percussion music, both for his work as a performer and as a teacher. Schick has commissioned and premiered over a hundred works for his family of instruments.</p>\n<p><img alt=\"Steven Schick © Bill Dean\" height=\"667\" src=\"/media/uploads/images/photos/steven_schick_3.jpg\" width=\"1000\"></p>\n<p>Appointed music professor at the Univserity of California, San Diego, he was a percussionist with Bang On A Can All-Stars in New York from 1992 to 2002 and artistic director for the Centre International de Percussion de Genève in Switzerland from 2000 to 2004. He founded ans is the artistic director of the percussion ensemble <em>red fish blue fish</em>. Since 2007, he has been the musical director and conductor of La Jolla Symphony and Chorus, and, since 2011, the artistic director of the San Francisco Contemporary Music Players.</p>\n<p>Futher information <a href=\"http://lajollasymphony.com/about/conductors.php\">Steven Schick</a></p>','<p>For over 30 years, Steven Schick has been the champion of contemporary percussion music, both for his work as a performer and as a teacher. Schick has commissioned and premiered over a hundred works for his family of instruments.</p>\n<p><img alt=\"Steven Schick © Bill Dean\" height=\"667\" src=\"/media/uploads/images/photos/steven_schick_3.jpg\" width=\"1000\"></p>\n<p>Appointed music professor at the Univserity of California, San Diego, he was a percussionist with Bang On A Can All-Stars in New York from 1992 to 2002 and artistic director for the Centre International de Percussion de Genève in Switzerland from 2000 to 2004. He founded ans is the artistic director of the percussion ensemble <em>red fish blue fish</em>. Since 2007, he has been the musical director and conductor of La Jolla Symphony and Chorus, and, since 2011, the artistic director of the San Francisco Contemporary Music Players.</p>\n<p>Futher information <a href=\"http://lajollasymphony.com/about/conductors.php\">Steven Schick</a></p>','<p>Depuis plus de trente ans, Steven Schick se fait le champion de la musique contemporaine pour percussions, tant par son activité d\'interprète que par son métier de pédagogue, passant commande et créant plus d\'une centaine d\'œuvres pour sa famille d\'instruments.</p>\n<p><img alt=\"Steven Schick © Bill Dean\" height=\"667\" src=\"/media/uploads/images/photos/steven_schick_3.jpg\" width=\"1000\"></p>\n<p>Titulaire d\'un poste de professeur de musique à l\'université de Californie à San Diego, il fut percussionniste du Bang on a can All-Stars de New York City de 1992-2002, ainsi que directeur artistique du Centre international de percussion de Genève (Suisse) de 2000 à 2004. Il fonde et assure la direction artistique de l\'ensemble de percussions <em>red fish blue fish</em>. Depuis 2007, il est directeur musical et chef du La Jolla Symphony and Chorus, et, depuis 2011, directeur artistique des San Francisco Contemporary Music Players.</p>\n<p>Plus d\'informations sur <a href=\"http://lajollasymphony.com/about/conductors.php\">Steven Schick</a></p>','For over 30 years, Steven Schick has been the champion of contemporary percussion music, both for his work as a performer and as a teacher.','For over 30 years, Steven Schick has been the champion of contemporary percussion music, both for his work as a performer and as a teacher.','Depuis plus de trente ans, Steven Schick se fait le champion de la musique contemporaine pour percussions, tant par son activité d\'interprète que par son métier de pédagogue',0,'','','2016-02-29 17:41:55',NULL,0,1,'','2016-02-29 16:08:52','',1,'steven-schick',2,'STEVEN SCHICK','2016-02-29 18:21:33','','','','STEVEN SCHICK','','','uploads/images/photos/steven_schick_5.jpg',''),(10,'uploads/images/photos/remmy_canedo.jpg','Remmy Canedo © Hyunjun Hong, 2012','<p>Remmy Canedo is a composer, visual programmer, and performer. His work explors manipulation and deformation of audiovisual material in real-time. He currently dedicates his time to algorithmic composition in real-time, generating interactive networks that depend on the compositional process, performers, and audio-visual elements for the creation of multi-form music.</p>\n<p>Remmy Canedo studied initially in Chili, his home country, before being awarded a DAAD scholarship in 2009, allowing him to study in Stuttgart, Germany with Oliver Schneller, Piet Meyer, and Marco Stroppa.</p>\n<p>Futher information <a href=\"https://vimeo.com/remmycanedo\">Remmy Canedo</a></p>','<p>Remmy Canedo is a composer, visual programmer, and performer. His work explors manipulation and deformation of audiovisual material in real-time. He currently dedicates his time to algorithmic composition in real-time, generating interactive networks that depend on the compositional process, performers, and audio-visual elements for the creation of multi-form music.</p>\n<p>Remmy Canedo studied initially in Chili, his home country, before being awarded a DAAD scholarship in 2009, allowing him to study in Stuttgart, Germany with Oliver Schneller, Piet Meyer, and Marco Stroppa.</p>\n<p>Futher information <a href=\"https://vimeo.com/remmycanedo\">Remmy Canedo</a></p>','<p>Remmy Canedo est compositeur, programmateur visuel et performer. Son travail explore la manipulation et la déformation du matériel audiovisuel en temps réel. Actuellement, il se consacre essentiellement à la composition algorithmique en temps réel, générant des réseaux interactifs qui impliquent le processus de composition, les interprètes et les éléments audiovisuels pour la création d\'une musique multiforme.</p>\n<p>Remmy Canedo s\'est d\'abord formé dans son pays, le Chili, avant de bénéficier d\'une bourse du DAAD en 2009 pour poursuivre ses études en Allemagne, et plus particulièrement à Stuttgart, auprès d\'Oliver Schneller, Piet Meyer et Marco Stroppa.</p>\n<p>Plus d\'informations sur <a href=\"https://vimeo.com/remmycanedo\">Remmy Canedo</a></p>','Remmy Canedo is a composer, visual programmer, and performer. His work explors manipulation and deformation of audiovisual material in real-time.','Remmy Canedo is a composer, visual programmer, and performer. His work explors manipulation and deformation of audiovisual material in real-time.','Remmy Canedo est compositeur, programmateur visuel et performer. Son travail explore la manipulation et la déformation du matériel audiovisuel en temps réel.',1,'','','2016-02-29 17:51:15',NULL,0,1,'','2016-02-29 16:22:40','',1,'remmy-canedo',2,'REMMY CANEDO','2016-03-01 11:29:58','','','','REMMY CANEDO','','left','uploads/images/photos/remmy_canedo_featured.jpg',''),(11,'uploads/images/photos/aureliano_cattaneo.jpg','Aureliona Cattaneo © Lucía Núñez García','<p>Aureliano Cattaneo studied piano and composition at the conservatories in Plaisance and Milan, before studying under Gérard Grisey and Mauricio Sotelo. Despite his love for chamber music, he never neglected other genres such as voice for which he recently wrote important works such as his opera <em>Le philosophe dans le labyrinthe</em> (2005), his second collaboration with the poet Eduardo Sanguinetti after <em>Minotaurus dreaming</em> (2003), followed by <em>parole di settembre </em>(2013) set again to Sanguineti’s poems. Since 2008, he has become interested in orchestra, as seen in <em>Violinkonzert</em> (2008) and <em>Selfportrait with orchestra</em> (2010).</p>\n<p>Since 2010, Aureliano has taught at the ESMUC (Escuela Superior de Musica de Catalunya) in Barcelona.</p>\n<p>Futher information <a href=\"http://aurelianocattaneo.com/\">Aureliano Cattaneo</a></p>','<p>Aureliano Cattaneo studied piano and composition at the conservatories in Plaisance and Milan, before studying under Gérard Grisey and Mauricio Sotelo. Despite his love for chamber music, he never neglected other genres such as voice for which he recently wrote important works such as his opera <em>Le philosophe dans le labyrinthe</em> (2005), his second collaboration with the poet Eduardo Sanguinetti after <em>Minotaurus dreaming</em> (2003), followed by <em>parole di settembre </em>(2013) set again to Sanguineti’s poems. Since 2008, he has become interested in orchestra, as seen in <em>Violinkonzert</em> (2008) and <em>Selfportrait with orchestra</em> (2010).</p>\n<p>Since 2010, Aureliano has taught at the ESMUC (Escuela Superior de Musica de Catalunya) in Barcelona.</p>\n<p>Futher information <a href=\"http://aurelianocattaneo.com/\">Aureliano Cattaneo</a></p>','<p>Aureliano Cattaneo étudie le piano et la composition dans les conservatoires de Plaisance et Milan, avant de se perfectionner auprès de Gérard Grisey et Mauricio Sotelo. Faisant montre d\'un goût certain pour la musique de chambre, il ne néglige pas les autres genres, comme la voix pour laquelle il a écrit ces dernières années des œuvres d\'importance, telles que son opéra <em>Le philosophe dans le labyrinthe</em> (2005), deuxième collaboration avec le poète Eduardo Sanguinetti après <em>Minotaurus dreaming</em> (2003), suivi de <em>parole di settembre </em>(2013)<em>, </em>à nouveau sur des poèmes de Sanguinetti. Depuis 2008, il s\'intéresse à l\'orchestre, comme en témoignent <em>Violinkonzert</em> (2008) et <em>Selfportrait with orchestra</em> (2010).</p>\n<p>Aureliano enseigne depuis 2010 à l’ESMUC (Escuela Superior de Musica de Catalunya) de Barcelone.</p>\n<p>Plus d\'informations sur <a href=\"http://aurelianocattaneo.com/\">Aureliano Cattaneo</a></p>','Aureliano Cattaneo studied piano and composition at the conservatories in Plaisance and Milan, before studying under Gérard Grisey and Mauricio Sotelo.','Aureliano Cattaneo studied piano and composition at the conservatories in Plaisance and Milan, before studying under Gérard Grisey and Mauricio Sotelo.','Aureliano Cattaneo étudie le piano et la composition dans les conservatoires de Plaisance et Milan, avant de se perfectionner auprès de Gérard Grisey et Mauricio Sotelo.',1,'','','2016-02-29 18:25:53',NULL,0,1,'','2016-02-29 16:58:42','',1,'aureliano-cattaneo',2,'AURELIANO CATTANEO','2016-03-01 11:32:26','','','','AURELIANO CATTANEO','','left','uploads/images/photos/aureliano_cattaneo_featured.jpg',''),(12,'','','<p>Daniel D\'Adamo studied composition in his native Buenos Aires, before moving to France in 1992. He studied composition with Philippe Manoury at the CNSMD de Lyon and then followed the Cursus program at IRCAM where he was able to benefit from the advice of Tristan Murail and Brian Ferneyhough. In 1997, he was a resident at the Villa Médicis where he created the festival Musica XXI. During 2007-2008, Daniel D\'Adamo was a composer in residence at Royaumont, a residence he extended with the commission from the Ensemble Philidor for instruments from the 17<sup>th</sup> century. Daniel D\'Adamo never neglected teaching: firstly as a professor in analaysis at the CNSMD de Paris then at the conservatory in Tours (where he founded and coordinated the Atelier Contemporain). He has taught composition at the conservatory in Reims since 2009.</p>\n<p>Futher information <a href=\"http://www.danieldadamo.com/site/MAIN.html\">Daniel D\'Adamo</a></p>\n<p><img alt=\"Daniel D\'Adamo © Guillaume Chauvin\" height=\"664\" src=\"/media/uploads/images/photos/daniel_d_adamo_2.jpg\" width=\"1000\"></p>','<p>Daniel D\'Adamo studied composition in his native Buenos Aires, before moving to France in 1992. He studied composition with Philippe Manoury at the CNSMD de Lyon and then followed the Cursus program at IRCAM where he was able to benefit from the advice of Tristan Murail and Brian Ferneyhough. In 1997, he was a resident at the Villa Médicis where he created the festival Musica XXI. During 2007-2008, Daniel D\'Adamo was a composer in residence at Royaumont, a residence he extended with the commission from the Ensemble Philidor for instruments from the 17<sup>th</sup> century. Daniel D\'Adamo never neglected teaching: firstly as a professor in analaysis at the CNSMD de Paris then at the conservatory in Tours (where he founded and coordinated the Atelier Contemporain). He has taught composition at the conservatory in Reims since 2009.</p>\n<p>Futher information <a href=\"http://www.danieldadamo.com/site/MAIN.html\">Daniel D\'Adamo</a></p>\n<p><img alt=\"Daniel D\'Adamo © Guillaume Chauvin\" height=\"664\" src=\"/media/uploads/images/photos/daniel_d_adamo_2.jpg\" width=\"1000\"></p>','<p>Daniel D\'Adamo débute sa formation à Buenos Aires, avant de s’installer en France en 1992. Il y intègre la classe de composition de Philippe Manoury au CNSMD de Lyon puis suit le Cursus de composition et d\'informatique musicale de l\'Ircam et bénéficie des conseils de Tristan Murail et Brian Ferneyhough. En 1997, il est pensionnaire à la Villa Médicis où il fonde le festival Musica XXI. En 2007-2008, Daniel D\'Adamo est compositeur en résidence à Royaumont, résidence qu\'il prolonge, dans le cadre d\'une commande de l\'Ensemble Philidor pour instruments du XVII<sup>e</sup> siècle. Daniel D\'Adamo n\'a jamais négligé la pédagogie : d\'abord professeur d\'analyse au Conservatoire national supérieur de musique et de danse de Paris puis au conservatoire de Tours (où il fonde et coordonne l\'Atelier Contemporain), il est professeur de composition au conservatoire de Reims depuis 2009.</p>\n<p>Plus d\'informations sur <a href=\"http://www.danieldadamo.com/site/MAIN.html\">Daniel D\'Adamo</a></p>\n<p><img alt=\"Daniel D\'Adamo © Guillaume Chauvin\" height=\"664\" src=\"/media/uploads/images/photos/daniel_d_adamo_2.jpg\" width=\"1000\"></p>','Daniel D\'Adamo studied composition in his native Buenos Aires, before moving to France in 1992. He studied composition with Philippe Manoury at the CNSMD de Lyon...','Daniel D\'Adamo studied composition in his native Buenos Aires, before moving to France in 1992. He studied composition with Philippe Manoury at the CNSMD de Lyon...','Daniel D\'Adamo débute sa formation à Buenos Aires, avant de s’installer en France en 1992. Il y intègre la classe de composition de Philippe Manoury au CNSMD de Lyon...',0,'','','2016-02-29 18:30:20',NULL,0,1,'','2016-02-29 17:00:22','',1,'daniel-dadamo',2,'DANIEL D\'ADAMO','2016-03-01 11:36:29','','','','DANIEL D\'ADAMO','','left','uploads/images/photos/daniel_d_adamo_featured.jpg',''),(13,'uploads/images/photos/laurent_durupt_4.jpg','Laurent Durupt © Marikel Lahana','<p>Composer and pianist, Laurent Durupt has studied piano under Hugues Leclère, Pascal Devoyon, Bruno Rigutto, Nicholas Angelich, and Henri Barda and composition under Frédéric Durieux, Luis Naon, Allain Gaussin, and Philippe Leroux. In 2011-2013, he followed the Cursus program at IRCAM.</p>\n<p>Laruent Durupt founded the duo Links with his brother and the ensemble Links with other artists. As a pianist, Laurent is quite active in the European contemporary music scene. He has also performed as a solist with the video artist Hicham Berrade in a series of performances called <em>Présage</em>.</p>\n<p>Resident at the Villa Médicis in 2013-2014, Laurent Durupt teaches piano today at the CNSMD de Paris ane electronic composition at the Université de Marne-La-Vallée.</p>\n<p>Futher information <a href=\"http://www.laurentdurupt.com/\">Laurent Durupt</a></p>','<p>Composer and pianist, Laurent Durupt has studied piano under Hugues Leclère, Pascal Devoyon, Bruno Rigutto, Nicholas Angelich, and Henri Barda and composition under Frédéric Durieux, Luis Naon, Allain Gaussin, and Philippe Leroux. In 2011-2013, he followed the Cursus program at IRCAM.</p>\n<p>Laruent Durupt founded the duo Links with his brother and the ensemble Links with other artists. As a pianist, Laurent is quite active in the European contemporary music scene. He has also performed as a solist with the video artist Hicham Berrade in a series of performances called <em>Présage</em>.</p>\n<p>Resident at the Villa Médicis in 2013-2014, Laurent Durupt teaches piano today at the CNSMD de Paris ane electronic composition at the Université de Marne-La-Vallée.</p>\n<p>Futher information <a href=\"http://www.laurentdurupt.com/\">Laurent Durupt</a></p>','<p>Compositeur et pianiste de formation, Laurent Durupt compte parmi ses professeurs Hugues Leclère, Pascal Devoyon, Bruno Rigutto, Nicholas Angelich et Henri Barda pour le piano, et Frédéric Durieux, Luis Naon, Allain Gaussin et Philippe Leroux pour la composition. En 2011-2013, il suit le Cursus de composition et d\'informatique musicale de l\'Ircam.</p>\n<p>Fondateur, avec son frère percussionniste, du duo Links et de l\'ensemble Links avec d\'autres artistes, le pianiste Laurent Durupt est actif sur la scène européenne contemporaine. Il se produit également en soliste ainsi qu\'avec le vidéaste Hicham Berrada, dans des performances intitulées <em>Présage</em>.</p>\n<p>Pensionnaire à la Villa Médicis en 2013-2014, Laurent Durupt enseigne aujourd\'hui le piano au Conservatoire national supérieur de musique et de danse de Paris et la composition électronique à l\'université de Marne-la-Vallée.</p>\n<p>Plus d\'informations <a href=\"http://www.laurentdurupt.com/\">Laurent Durupt</a></p>','Composer and pianist, Laurent Durupt has studied piano under Hugues Leclère, Pascal Devoyon, Bruno Rigutto, Nicholas Angelich, and Henri Barda...','Composer and pianist, Laurent Durupt has studied piano under Hugues Leclère, Pascal Devoyon, Bruno Rigutto, Nicholas Angelich, and Henri Barda...','Compositeur et pianiste de formation, Laurent Durupt compte parmi ses professeurs Hugues Leclère, Pascal Devoyon, Bruno Rigutto, Nicholas Angelich et Henri Barda pour le piano...',1,'','','2016-02-29 18:34:18',NULL,0,1,'','2016-02-29 17:04:30','',1,'laurent-durupt',2,'LAURENT DURUPT','2016-03-01 11:21:43','','','','LAURENT DURUPT','','left','uploads/images/photos/laurent_durupt_4.jpg',''),(14,'','','<p>Futher information <a href=\"http://www.ensembleinter.com/en/new-home-en.php\">Ensemble intercontemporain</a></p>\n<p><img alt=\"Ensemble intercontemporain © Aymeric Warmé-Janville, 2007\" height=\"669\" src=\"/media/uploads/images/photos/eic.jpg\" width=\"1000\"></p>','<p>Futher information <a href=\"http://www.ensembleinter.com/en/new-home-en.php\">Ensemble intercontemporain</a></p>\n<p><img alt=\"Ensemble intercontemporain © Aymeric Warmé-Janville, 2007\" height=\"669\" src=\"/media/uploads/images/photos/eic.jpg\" width=\"1000\"></p>','<p>Créé par Pierre Boulez en 1976, l\'Ensemble intercontemporain réunit 31 solistes partageant une passion pour la musique du vingtième siècle à aujourd\'hui.? Constitués en groupe permanent, ils participent aux missions de diffusion, de transmission et de création fixées par les statuts de l\'Ensemble. Sous la direction de Matthias Pintscher, ils collaborent, aux côtés des compositeurs, à l\'exploration des techniques instrumentales ainsi qu\'à des projets associant musique, danse, théâtre, cinéma, vidéo et arts plastiques. En collaboration avec l\'Ircam, l\'Ensemble participe à des projets incluant des nouvelles techniques liées au son.?Les activités de formation des jeunes musiciens ainsi que les nombreuses actions de sensibilisation traduisent un engagement profond au service de la transmission.</p>\n<p>Plus d\'informations sur l\'<a href=\"http://www.ensembleinter.com/fr/\">Ensemble intercontemporain</a></p>\n<p><img alt=\"Ensemble intercontemporain © Aymeric Warmé-Janville, 2007\" height=\"669\" src=\"/media/uploads/images/photos/eic.jpg\" width=\"1000\"></p>','Créé par Pierre Boulez en 1976, l\'Ensemble intercontemporain réunit 31 solistes partageant une passion pour la musique du vingtième siècle à aujourd\'hui.','','Créé par Pierre Boulez en 1976, l\'Ensemble intercontemporain réunit 31 solistes partageant une passion pour la musique du vingtième siècle à aujourd\'hui.',0,'','','2016-02-29 18:38:41',NULL,0,1,'','2016-02-29 17:08:42','',1,'ensemble-intercontemporain',2,'ENSEMBLE INTERCONTEMPORAIN','2016-03-01 11:43:04','','','','ENSEMBLE INTERCONTEMPORAIN','','left','uploads/images/photos/eic_featured.jpg',''),(15,'uploads/images/photos/beat_furrer.jpg','Beat Furrer © David Furrer, 2014','<p>A trained pianist, Beat Furrer moved to 1975 to study composition with Roman Haubenstock-Ramati. In 1985, he founded the ensemble Klangforum Wien where he was the artistic directior until 1992. Since then, he has taught at the University of Graz.</p>\n<p>The visual arts, literature, and jazz form the background for his first works. Certain techniques belong to visual processes: overlapping layers that focus on an object while revisiting the structure, chiaroscuro effects… A tendancy to leave certain elements unsecured or to let figures develop independently are marks of his writing. The voice, from noised babbling to proper language, plays a major role in Furrer\'s music.</p>\n<p>Futher information <a href=\"http://www.beatfurrer.com/\">Beat Furrer</a></p>','<p>A trained pianist, Beat Furrer moved to 1975 to study composition with Roman Haubenstock-Ramati. In 1985, he founded the ensemble Klangforum Wien where he was the artistic directior until 1992. Since then, he has taught at the University of Graz.</p>\n<p>The visual arts, literature, and jazz form the background for his first works. Certain techniques belong to visual processes: overlapping layers that focus on an object while revisiting the structure, chiaroscuro effects… A tendancy to leave certain elements unsecured or to let figures develop independently are marks of his writing. The voice, from noised babbling to proper language, plays a major role in Furrer\'s music.</p>\n<p>Futher information <a href=\"http://www.beatfurrer.com/\">Beat Furrer</a></p>','<p>Pianiste de formation, Beat Furrer s\'installe à Vienne en 1975 pour étudier la composition avec Roman Haubenstock-Ramati. En 1985, il crée l\'ensemble Klangforum Wien dont il assure la direction artistique jusqu\'en 1992. Depuis cette date, il enseigne à l\'université de Graz.</p>\n<p>Arts plastiques, littérature et jazz forment l\'arrière-plan d\'où naissent ses premières œuvres. Certaines techniques s\'apparentent par analogie aux procédés plastiques : superposition de couches qui cernent un objet en revisitant une même structure, effets de clairs-obscurs… La tendance à laisser certains éléments non-fixés, ou à laisser se développer les figures de manière autonome, reste une marque de son écriture. La voix, du balbutiement bruité au langage constitué, occupe une place décisive dans sa musique.</p>\n<p>Plus d\'informations sur <a href=\"http://www.beatfurrer.com/\">Beat Furrer</a></p>','A trained pianist, Beat Furrer moved to 1975 to study composition with Roman Haubenstock-Ramati. In 1985, he founded the ensemble Klangforum Wien...','A trained pianist, Beat Furrer moved to 1975 to study composition with Roman Haubenstock-Ramati. In 1985, he founded the ensemble Klangforum Wien...','Pianiste de formation, Beat Furrer s\'installe à Vienne en 1975 pour étudier la composition avec Roman Haubenstock-Ramati. En 1985, il crée l\'ensemble Klangforum Wien...',0,'','','2016-03-01 11:48:12',NULL,0,1,'','2016-03-01 10:18:08','',1,'beat-furrer',2,'BEAT FURRER','2016-03-01 11:49:41','','','','BEAT FURRER','','left','uploads/images/photos/beat_furrer_featured.jpg',''),(16,'','','<p>Following his studies at the Rotterdam Dance Academy, Hauert moved to Brussels in 1991. He danced in Anne Teresa De Keersmaeker\'s company, and then with Gonnie Heggen, David Zambrano, and Pierre Droulers. In 1998, he founded the ZOO company where the work develops through research on movement, with a focus on writing based on improvisation, exploring the tension between freedom and constraint, the individual and a group, order and disorder, form and shapelessness. The company created 15 performances. In parallel, Thomas signs choreographers for Mozambicans dancers, for CanDoCo, a dance company for handicapped, and non-handicapped, dancers, as well as for the P.A.R.T.S. school in Brussels.</p>\n<p>Futher information <a href=\"http://www.zoo-thomashauert.be\">Thomas Hauert</a></p>\n<p><img alt=\"Thomas Hauert © Thibault grégoire\" height=\"630\" src=\"/media/uploads/images/photos/thomas_hauert.jpg\" width=\"945\"></p>','<p>Following his studies at the Rotterdam Dance Academy, Hauert moved to Brussels in 1991. He danced in Anne Teresa De Keersmaeker\'s company, and then with Gonnie Heggen, David Zambrano, and Pierre Droulers. In 1998, he founded the ZOO company where the work develops through research on movement, with a focus on writing based on improvisation, exploring the tension between freedom and constraint, the individual and a group, order and disorder, form and shapelessness. The company created 15 performances. In parallel, Thomas signs choreographers for Mozambicans dancers, for CanDoCo, a dance company for handicapped, and non-handicapped, dancers, as well as for the P.A.R.T.S. school in Brussels.</p>\n<p>Futher information <a href=\"http://www.zoo-thomashauert.be\">Thomas Hauert</a></p>\n<p><img alt=\"Thomas Hauert © Thibault grégoire\" height=\"630\" src=\"/media/uploads/images/photos/thomas_hauert.jpg\" width=\"945\"></p>','<p>Après ses études à l\'Académie de Rotterdam, le Suisse Thomas Hauert s\'installe à Bruxelles en 1991. Il danse dans la compagnie d\'Anne Teresa De Keersmaeker, puis collabore avec Gonnie Heggen, David Zambrano et Pierre Droulers. En 1998, il fonde sa compagnie ZOO dont le travail se développe à partir d\'une recherche sur le mouvement, avec un intérêt pour une écriture basée sur l\'improvisation, explorant la tension entre liberté et contrainte, individu et groupe, ordre et désordre, forme et informe. Naîtront ainsi une quinzaine de spectacles. En parallèle, Thomas signe encore des chorégraphies pour des danseurs mozambicains, pour CanDoCo, compagnie de danseurs invalides ou non, ainsi que pour l’école bruxelloise P.A.R.T.S. (où il enseigne régulièrement).</p>\n<p>Plus d\'informations sur <a href=\"http://www.zoo-thomashauert.be\">Thomas Hauert</a></p>\n<p><img alt=\"Thomas Hauert © Thibault grégoire\" height=\"630\" src=\"/media/uploads/images/photos/thomas_hauert.jpg\" width=\"945\"></p>','Following his studies at the Rotterdam Dance Academy, Hauert moved to Brussels in 1991. He danced in Anne Teresa De Keersmaeker\'s company, and then with Gonnie Heggen, David Zambrano, and Pierre Droulers.','Following his studies at the Rotterdam Dance Academy, Hauert moved to Brussels in 1991. He danced in Anne Teresa De Keersmaeker\'s company, and then with Gonnie Heggen, David Zambrano, and Pierre Droulers.','Après ses études à l\'Académie de Rotterdam, le Suisse Thomas Hauert s\'installe à Bruxelles en 1991. Il danse dans la compagnie d\'Anne Teresa De Keersmaeker, puis collabore avec Gonnie Heggen, David Zambrano et Pierre Droulers.',0,'','','2016-03-01 11:51:00',NULL,0,1,'','2016-03-01 10:24:05','',1,'thomas-hauert',2,'THOMAS HAUERT','2016-03-01 11:56:38','','','','THOMAS HAUERT','','left','uploads/images/photos/thomas_hauert_featured.jpg',''),(17,'','','<p>Mauro Lanza studied piano, writing, and musicology in Venice before studying under Brian Ferneyhough, Salvatore Sciarrino, and Gérard Grisey. Quite playful and often malicious, both demanding and aloof, his music combines traditional instruments, electro-acoustic elements, and an array of toy instruments and amazing machines. Mauro Lanza has a strong propensity for multidisciplinary projects, collaborating with the choreographer Angelin Preljocaj or the video artist Paolo Pachini.</p>\n<p><img alt=\"Mauro Lanza © DR\" height=\"662\" src=\"/media/uploads/images/photos/mauro_lanza.jpg\" width=\"1000\"></p>\n<p>Mauro Lanza has taught at McGill University and IRCAM; he regularly teaches master classes at the conservatories in Paris, Cagliari, and Cuneo. He participates in research carried out at IRCAM in the domains of synthesis through physical models and computer-assisted composition.</p>\n<p>Futher information <a href=\"https://soundcloud.com/maurolanza\">Mauro Lanza</a></p>','<p>Mauro Lanza studied piano, writing, and musicology in Venice before studying under Brian Ferneyhough, Salvatore Sciarrino, and Gérard Grisey. Quite playful and often malicious, both demanding and aloof, his music combines traditional instruments, electro-acoustic elements, and an array of toy instruments and amazing machines. Mauro Lanza has a strong propensity for multidisciplinary projects, collaborating with the choreographer Angelin Preljocaj or the video artist Paolo Pachini.</p>\n<p><img alt=\"Mauro Lanza © DR\" height=\"662\" src=\"/media/uploads/images/photos/mauro_lanza.jpg\" width=\"1000\"></p>\n<p>Mauro Lanza has taught at McGill University and IRCAM; he regularly teaches master classes at the conservatories in Paris, Cagliari, and Cuneo. He participates in research carried out at IRCAM in the domains of synthesis through physical models and computer-assisted composition.</p>\n<p>Futher information <a href=\"https://soundcloud.com/maurolanza\">Mauro Lanza</a></p>','<p>Mauro Lanza étudie le piano, l\'écriture et la musicologie à Venise puis se forme auprès de Brian Ferneyhough, Salvatore Sciarrino et Gérard Grisey. Très joueuse et souvent malicieuse, à la fois exigeante et distanciée, sa musique mêle instrumentarium traditionnel, électroacoustique et tout un éventail d\'instruments jouets et de machines étonnantes. Mauro Lanza témoigne d\'un fort penchant pour la pluridisciplinarité, collaborant avec le chorégraphe Angelin Preljocaj ou le vidéaste Paolo Pachini.</p>\n<p><img alt=\"Mauro Lanza © DR\" height=\"662\" src=\"/media/uploads/images/photos/mauro_lanza.jpg\" width=\"1000\"></p>\n<p>Mauro Lanza a enseigné à l\'université McGill et à l\'Ircam et donne régulièrement des master classes aux conservatoires de Paris, Cagliari et Cuneo. Il s\'associe aux recherches de l\'Ircam dans les domaines de la synthèse par modèles physiques et de la composition assistée par ordinateur.</p>\n<p>Plus d\'informations sur <a href=\"https://soundcloud.com/maurolanza\">Mauro Lanza</a></p>','Mauro Lanza studied piano, writing, and musicology in Venice before studying under Brian Ferneyhough, Salvatore Sciarrino, and Gérard Grisey.','Mauro Lanza studied piano, writing, and musicology in Venice before studying under Brian Ferneyhough, Salvatore Sciarrino, and Gérard Grisey.','Mauro Lanza étudie le piano, l\'écriture et la musicologie à Venise puis se forme auprès de Brian Ferneyhough, Salvatore Sciarrino et Gérard Grisey.',0,'','','2016-03-01 12:14:29',NULL,0,1,'','2016-03-01 10:44:59','',1,'mauro-lanza',2,'MAURO LANZA','2016-03-01 12:18:05','','','','MAURO LANZA','','left','uploads/images/photos/mauro_lanza_featured.jpg',''),(18,'','','<p>Philippe Leroux began at the CNSMD de Paris in 1978, studying under I. Malec, C. Ballif, P. Schaeffer, and G. Reibel. He also studied with O. Messiaen, F. Donatoni, B. Jolas, J.C. Eloy, and I. Xenakis.</p>\n<p><img alt=\"Philippe Leroux © Joël Perrot\" height=\"749\" src=\"/media/uploads/images/photos/philippe_leroux.jpg\" width=\"1000\"></p>\n<p>His catalogue includes over 70 chamber, symphonic, acoustomatic, and vocal works, with or without electronics (Philippe Leroux is a frequent visitor at IRCAM). Neglecting neither humour nor emotion, Philippe Leroux cultivates an aesthetic made up of movements, using systems created using polyrythmic and polymetric circles, creating a feeling of rhythmic freedom found in speech. Philippe Leroux is also interested in poetry and theater, sometimes neglecting the meaning in favor of the text\'s musicality.</p>\n<p>Futher information <a href=\"http://lerouxcomposition.com/en/index.html\">Philippe Leroux</a></p>','<p>Philippe Leroux began at the CNSMD de Paris in 1978, studying under I. Malec, C. Ballif, P. Schaeffer, and G. Reibel. He also studied with O. Messiaen, F. Donatoni, B. Jolas, J.C. Eloy, and I. Xenakis.</p>\n<p><img alt=\"Philippe Leroux © Joël Perrot\" height=\"749\" src=\"/media/uploads/images/photos/philippe_leroux.jpg\" width=\"1000\"></p>\n<p>His catalogue includes over 70 chamber, symphonic, acoustomatic, and vocal works, with or without electronics (Philippe Leroux is a frequent visitor at IRCAM). Neglecting neither humour nor emotion, Philippe Leroux cultivates an aesthetic made up of movements, using systems created using polyrythmic and polymetric circles, creating a feeling of rhythmic freedom found in speech. Philippe Leroux is also interested in poetry and theater, sometimes neglecting the meaning in favor of the text\'s musicality.</p>\n<p>Futher information <a href=\"http://lerouxcomposition.com/en/index.html\">Philippe Leroux</a></p>','<p>Philippe Leroux intègre le Conservatoire national supérieur de musique et de danse de Paris en 1978, dans les classes d\'I. Malec, C. Ballif, P. Schaeffer et G. Reibel. Il étudie également avec O. Messiaen, F. Donatoni, B. Jolas, J.-C. Eloy et I. Xenakis.</p>\n<p><img alt=\"Philippe Leroux © Joël Perrot\" height=\"749\" src=\"/media/uploads/images/photos/philippe_leroux.jpg\" width=\"1000\"></p>\n<p>Son catalogue comprend plus de 70 œuvres chambristes, symphoniques, acousmatiques et vocales, avec ou sans électronique (c\'est un habitué de l\'Ircam). Ne négligeant ni l\'humour ni l\'émotion, Philippe Leroux cultive une esthétique faite de mouvements, ayant notamment recours à des systèmes élaborés sur des cycles polyrythmiques et polymétriques – dégageant un sentiment de grande liberté rythmique, à la manière de la parole. Au reste, Philippe Leroux ne cache pas son intérêt pour la poétique et le théâtre – négligeant parfois le sens au profit de la musicalité du texte.</p>\n<p>Plus d\'informations sur <a href=\"http://lerouxcomposition.com/fr/index.html\">Philippe Leroux</a></p>','Philippe Leroux began at the CNSMD de Paris in 1978, studying under I. Malec, C. Ballif, P. Schaeffer, and G. Reibel.','Philippe Leroux began at the CNSMD de Paris in 1978, studying under I. Malec, C. Ballif, P. Schaeffer, and G. Reibel.','Philippe Leroux intègre le Conservatoire national supérieur de musique et de danse de Paris en 1978, dans les classes d\'I. Malec, C. Ballif, P. Schaeffer et G. Reibel.',0,'','','2016-03-01 12:23:28',NULL,0,1,'','2016-03-01 10:54:02','',1,'philippe-leroux',2,'PHILIPPE LEROUX','2016-03-01 12:27:53','','','','PHILIPPE LEROUX','','left','uploads/images/photos/philippe_leroux_featured.jpg',''),(19,'','','<p>Donatienne Michel-Dansac is a singer, which for her, is another way of talking. She does not sing, she speaks. When she sings, she speaks slower, of course, and when she speaks, she thinks she\'s singing: making music from a text. She thinks therefore. This is hard work and nobody sees that she is working.</p>\n<p>Donatienne studied at the CNSMD de Paris where she was awarded the Prix de chant in 1990. Since 1993, a close collaboration with IRCAM enabled her to premiere numerous works by composers such as Philippe Manoury, Pascal Dusapin, Luca Francesconi, Fausto Romitelli, Mauro Lanza, Georges Aperghis, and Philippe Leroux. She also performes Baroque French, Italian, and German music in addition to the Romantic and Classical repertoires.</p>\n<p><img alt=\"Donatienne Michel-Dansac © Jean Radel, Académie de France à Rome Villa Medici\" height=\"665\" src=\"/media/uploads/images/photos/donatienne_michel_dansac.jpg\" width=\"1000\"></p>','<p>Donatienne Michel-Dansac is a singer, which for her, is another way of talking. She does not sing, she speaks. When she sings, she speaks slower, of course, and when she speaks, she thinks she\'s singing: making music from a text. She thinks therefore. This is hard work and nobody sees that she is working.</p>\n<p>Donatienne studied at the CNSMD de Paris where she was awarded the Prix de chant in 1990. Since 1993, a close collaboration with IRCAM enabled her to premiere numerous works by composers such as Philippe Manoury, Pascal Dusapin, Luca Francesconi, Fausto Romitelli, Mauro Lanza, Georges Aperghis, and Philippe Leroux. She also performes Baroque French, Italian, and German music in addition to the Romantic and Classical repertoires.</p>\n<p><img alt=\"Donatienne Michel-Dansac © Jean Radel, Académie de France à Rome Villa Medici\" height=\"665\" src=\"/media/uploads/images/photos/donatienne_michel_dansac.jpg\" width=\"1000\"></p>','<p>Donatienne Michel-Dansac est chanteuse, ce qui pour elle est une autre possibilité de dire. Donc elle ne chante pas, elle parle. Quand elle chante, elle parle plus lentement, forcément, et quand elle parle, elle pense qu\'elle chante : ça fait la musique d\'un texte. Elle pense donc. C\'est beaucoup de travail et personne ne s\'aperçoit qu\'elle travaille. </p>\n<p>Elle a étudié au Conservatoire de Paris où elle obtient son Prix de chant en 1990. Une étroite collaboration avec l\'Ircam depuis 1993 lui a permis de créer de nombreuses œuvres nouvelles (Philippe Manoury, Pascal Dusapin, Luca Francesconi, Fausto Romitelli, Mauro Lanza, Georges Aperghis, Philippe Leroux…). Elle interprète également la musique baroque française, italienne et allemande, les répertoires romantique et classique.</p>\n<p><img alt=\"Donatienne Michel-Dansac © Jean Radel, Académie de France à Rome Villa Medici\" height=\"665\" src=\"/media/uploads/images/photos/donatienne_michel_dansac.jpg\" width=\"1000\"></p>','Donatienne Michel-Dansac is a singer, which for her, is another way of talking. She does not sing, she speaks. When she sings, she speaks slower...','Donatienne Michel-Dansac is a singer, which for her, is another way of talking. She does not sing, she speaks. When she sings, she speaks slower...','Donatienne Michel-Dansac est chanteuse, ce qui pour elle est une autre possibilité de dire. Donc elle ne chante pas, elle parle. Quand elle chante, elle parle plus lentement...',0,'','','2016-03-01 12:37:58',NULL,0,1,'','2016-03-01 11:04:44','',1,'donatienne-michel-dansac',2,'DONATIENNE MICHEL-DANSAC','2016-03-01 12:37:58','','','','DONATIENNE MICHEL-DANSAC','','left','uploads/images/photos/donatienne_michel_dansac_featured.jpg',''),(20,'uploads/images/photos/marco_momi.jpg','Marco Momi © Maurizio Rellini','<p>While Italian by birth, Marco Momi is, above all, from a musical thought point of view European. Passionate about composition after his class with Fabio Cifariello Ciardi, the time he spent in Darmstadt was decisive; as were the years he spent studying in The Hague (Netherlands) and in IRCAM\'s Cursus program with Yan Maresz. \"My path has never seemed very clear or very linear to me, be it my training or my aesthetic progression. I was lucky to meet and study with composers far from my genetic characteristics, with whom I sometimes had very difficult, but always honest, relationships. I never tried to find teachers with a sensibility similar to my own. This let me be freer.\"</p>\n<p>Futher information <a href=\"http://marcomomi.com/\">Marco Momi</a></p>','<p>While Italian by birth, Marco Momi is, above all, from a musical thought point of view European. Passionate about composition after his class with Fabio Cifariello Ciardi, the time he spent in Darmstadt was decisive; as were the years he spent studying in The Hague (Netherlands) and in IRCAM\'s Cursus program with Yan Maresz. \"My path has never seemed very clear or very linear to me, be it my training or my aesthetic progression. I was lucky to meet and study with composers far from my genetic characteristics, with whom I sometimes had very difficult, but always honest, relationships. I never tried to find teachers with a sensibility similar to my own. This let me be freer.\"</p>\n<p>Futher information <a href=\"http://marcomomi.com/\">Marco Momi</a></p>','<p>Bien qu\'Italien de naissance, Marco Momi sera avant tout un Européen du point de vue de la pensée musicale : passionné pour la composition après son passage dans la classe de Fabio Cifariello Ciardi, le séjour qu\'il fait à Darmstadt sera déterminant, de même que ses années d\'étude à La Haye (Pays-Bas) ou le Cursus de l\'Ircam, auprès de Yan Maresz. « Mon parcours, dit-il, ne me semble ni très clair ni très linéaire, que ce soit dans ma formation ou mon cheminement esthétique. J\'ai eu la chance de rencontrer et d\'étudier avec des compositeurs très éloignés de mes caractéristiques génétiques, avec lesquels j\'ai entretenu des rapports parfois durs, mais toujours sincères. Je n\'ai jamais cherché chez mes professeurs une sensibilité similaire à la mienne. Ça m\'a permis d\'être plus libre. »</p>\n<p>Plus d\'informations sur <a href=\"http://marcomomi.com/\">Marco Momi</a></p>','While Italian by birth, Marco Momi is, above all, from a musical thought point of view European. Passionate about composition after his class with Fabio Cifariello Ciardi...','While Italian by birth, Marco Momi is, above all, from a musical thought point of view European. Passionate about composition after his class with Fabio Cifariello Ciardi...','Bien qu\'Italien de naissance, Marco Momi sera avant tout un Européen du point de vue de la pensée musicale : passionné pour la composition après son passage dans la classe de Fabio Cifariello Ciardi...',0,'','','2016-03-01 12:43:11',NULL,0,1,'','2016-03-01 11:12:31','',1,'marco-momi',2,'MARCO MOMI','2016-03-01 12:49:52','','','','MARCO MOMI','','left','uploads/images/photos/marco_momi_featured.jpg',''),(21,'','','<p>The Italian Emanuele Palumbo studied composition with Gabriele Manca at the Milan Conservatory and at the CNSMD de Paris with Gérard Pesson. In his music, he often questions the specialization of the work carried out by the musician and the composer. Using accessories (specially equipped bows, mutes, picks wrapped in felt) that he makes himself, Palumbo creates inhabitual playing styles and new sounds. The instrumental ensemble becomes a venue filled with a new aura.</p>\n<p>Futher information <a href=\"https://soundcloud.com/emanuele-palumbo\">Emanuele Palumbo</a></p>','<p>The Italian Emanuele Palumbo studied composition with Gabriele Manca at the Milan Conservatory and at the CNSMD de Paris with Gérard Pesson. In his music, he often questions the specialization of the work carried out by the musician and the composer. Using accessories (specially equipped bows, mutes, picks wrapped in felt) that he makes himself, Palumbo creates inhabitual playing styles and new sounds. The instrumental ensemble becomes a venue filled with a new aura.</p>\n<p>Futher information <a href=\"https://soundcloud.com/emanuele-palumbo\">Emanuele Palumbo</a></p>','<p>L\'Italien Emanuele Palumbo étudie la composition avec Gabriele Manca au conservatoire de Milan puis au Conservatoire de Paris avec Gérard Pesson. Dans sa musique, il s\'interroge souvent sur la spécialisation du travail de l\'instrumentiste et du compositeur. En utilisant des accessoires (comme des archets avec spires de gomme, des sourdines, des plectres enveloppés de feutrine) qu\'il fabrique lui-même, il crée des modes de jeux inhabituels pour obtenir des sonorités nouvelles. L\'ensemble instrumental devient ainsi un lieu chargé d\'une nouvelle aura.</p>\n<p>Plus d\'informations sur <a href=\"https://soundcloud.com/emanuele-palumbo\">Emanuele Palumbo</a></p>','The Italian Emanuele Palumbo studied composition with Gabriele Manca at the Milan Conservatory and at the CNSMD de Paris with Gérard Pesson.','The Italian Emanuele Palumbo studied composition with Gabriele Manca at the Milan Conservatory and at the CNSMD de Paris with Gérard Pesson.','L\'Italien Emanuele Palumbo étudie la composition avec Gabriele Manca au conservatoire de Milan puis au Conservatoire de Paris avec Gérard Pesson.',0,'','','2016-03-01 12:54:27',NULL,0,1,'','2016-03-01 11:24:12','',1,'emanuele-palumbo',2,'EMANUELE PALUMBO','2016-03-01 12:54:27','','','','EMANUELE PALUMBO','','left','',''),(22,'','','<p>Jérome Thomas learned the art of circus and juggling with Annie Fratellini before studying the art of cabaret. At an early age, he became interested in jazz and has worked with a number of musicians including Bernard Lubat, Carlo Rizzo, Marc Perronne, Pascal Lloret, Alfred Spirli, Jacques Higelin, and Andy Aimler. These encounters led him to practice the art of improvisation.</p>\n<p><img alt=\"Jérôme Thomas © Christophe Raynaud de Lage\" height=\"668\" src=\"/media/uploads/images/photos/jerome_thomas.jpg\" width=\"1000\"></p>\n<p>Since then, Jérôme Thomas has performed in a wide range of formats, working with musicians and choreographers. In 1992, he founded ARMO (Atelier de Recherche en Manipulation d\'Objets)/Cie Jérôme Thomas, with which he has created several performances that have toured France and abroad. This provides the ideal setting for his research on improvisation and the relationship between juggling and music, between theater and circus, working on movement and the manipulation of objects.</p>\n<p>Futher information <a href=\"http://jerome-thomas.fr/\">Jérôme Thomas</a></p>','<p>Jérome Thomas learned the art of circus and juggling with Annie Fratellini before studying the art of cabaret. At an early age, he became interested in jazz and has worked with a number of musicians including Bernard Lubat, Carlo Rizzo, Marc Perronne, Pascal Lloret, Alfred Spirli, Jacques Higelin, and Andy Aimler. These encounters led him to practice the art of improvisation.</p>\n<p><img alt=\"Jérôme Thomas © Christophe Raynaud de Lage\" height=\"668\" src=\"/media/uploads/images/photos/jerome_thomas.jpg\" width=\"1000\"></p>\n<p>Since then, Jérôme Thomas has performed in a wide range of formats, working with musicians and choreographers. In 1992, he founded ARMO (Atelier de Recherche en Manipulation d\'Objets)/Cie Jérôme Thomas, with which he has created several performances that have toured France and abroad. This provides the ideal setting for his research on improvisation and the relationship between juggling and music, between theater and circus, working on movement and the manipulation of objects.</p>\n<p>Futher information <a href=\"http://jerome-thomas.fr/\">Jérôme Thomas</a></p>','<p>Jongleur formé au cirque, avec Annie Fratellini, et au cabaret, Jérôme Thomas s\'oriente très tôt vers le jazz et collabore avec de nombreux musiciens : Bernard Lubat, Carlo Rizzo, Marc Perronne, Pascal Lloret, Alfred Spirli, Jacques Higelin, Andy Aimler… Ces rencontres l\'orientent vers une pratique de l\'improvisation.</p>\n<p><img alt=\"Jérôme Thomas © Christophe Raynaud de Lage\" height=\"668\" src=\"/media/uploads/images/photos/jerome_thomas.jpg\" width=\"1000\"></p>\n<p>De là, il se produit dans des spectacles de toute forme, collaborant avec des musiciens et des chorégraphes. En 1992, il fonde ARMO (Atelier de recherche en manipulation d\'objets)/Cie Jérôme Thomas, avec lequel il crée de nombreux spectacles qui tournent en France et à l\'étranger. C\'est le cadre idéal à ses recherches sur l\'improvisation et la relation entre jonglage et musique, mais aussi entre théâtre et cirque, en travaillant le mouvement et la manipulation d\'objets.</p>\n<p>Plus d\'informations sur <a href=\"http://jerome-thomas.fr/\">Jérôme Thomas</a></p>','Jérome Thomas learned the art of circus and juggling with Annie Fratellini before studying the art of cabaret. At an early age, he became interested in jazz and has worked with a number of musicians...','Jérome Thomas learned the art of circus and juggling with Annie Fratellini before studying the art of cabaret. At an early age, he became interested in jazz and has worked with a number of musicians...','Jongleur formé au cirque, avec Annie Fratellini, et au cabaret, Jérôme Thomas s\'oriente très tôt vers le jazz et collabore avec de nombreux musiciens...',0,'','','2016-03-01 13:04:29',NULL,0,1,'','2016-03-01 11:34:55','',1,'jérôme-thomas',2,'JÉRÔME THOMAS','2016-03-01 13:07:53','','','','JÉRÔME THOMAS','','left','uploads/images/photos/jerome_thomas_featured.jpg',''),(23,'','','<p>Futher information <a href=\"http://www.salvatoresciarrino.eu/Data/index_eng.html\">Salvatore Sciarrino</a></p>\n<p><img alt=\"Salvatore Sciarrino © Luca Carrà, RaiTrade\" height=\"652\" src=\"/media/uploads/images/photos/salvatore_sciarrino_6.jpg\" width=\"1000\"></p>','<p>Futher information <a href=\"http://www.salvatoresciarrino.eu/Data/index_eng.html\">Salvatore Sciarrino</a></p>\n<p><img alt=\"Salvatore Sciarrino © Luca Carrà, RaiTrade\" height=\"652\" src=\"/media/uploads/images/photos/salvatore_sciarrino_6.jpg\" width=\"1000\"></p>','<p>Bien qu\'affirmant sa filiation avec l\'avant-garde, Salvatore Sciarrino se revendique dans une continuité historique. Son catalogue ne présente pas de rupture mais une évolution vers une « écologie » de l\'écoute et du son. On parle dès ses débuts d\'un « son Sciarrino ». Sa musique est intimiste, concentrée et raffinée, construite sur des principes de microvariations de structures sonores constituées de timbres recherchés et de souffle. Il organise ses œuvres comme on trace les lignes d’un dessin, estompe les sons, fusionne les couleurs, joue avec la lumière.</p>\n<p>La voix occupe une place majeure dans son œuvre, avec des expériences sur l\'émission vocale ou, plus récemment, une écriture centrée sur une continuité mélodique liée à la psychologie des personnages.</p>\n<p>Plus d\'informations sur <a href=\"http://www.salvatoresciarrino.eu/Data/index_eng.html\">Salvatore Sciarrino</a></p>\n<p><img alt=\"Salvatore Sciarrino © Luca Carrà, RaiTrade\" height=\"652\" src=\"/media/uploads/images/photos/salvatore_sciarrino_6.jpg\" width=\"1000\"></p>','Bien qu\'affirmant sa filiation avec l\'avant-garde, Salvatore Sciarrino se revendique dans une continuité historique. Son catalogue ne présente pas de rupture mais une évolution vers une « écologie » de l\'écoute et du son.','','Bien qu\'affirmant sa filiation avec l\'avant-garde, Salvatore Sciarrino se revendique dans une continuité historique. Son catalogue ne présente pas de rupture mais une évolution vers une « écologie » de l\'écoute et du son.',0,'','','2016-03-01 15:05:48',NULL,0,1,'','2016-03-01 13:32:44','',1,'salvatore-sciarrino',2,'SALVATORE SCIARRINO','2016-03-01 15:05:48','','','','SALVATORE SCIARRINO','','left','uploads/images/photos/salvatore_sciarrino_featured.jpg',''),(24,'','','<p>Born in 1982 in Naples to a family of musicians, Mariangela Vacatello began the piano at the age of 4 and studied at the Imola Academy, at the Milan Conservatory, and at the Royal Academy of Music in London with Christopher Elton. She also took a number of master classes with leading artists and had her first success at 14, performing Liszt\'s <em>Piano Concerto No. 1</em> in Milan. Since then, she has has an international career, performing as a soloist, with orchestras (under the baton of conductors such as Krystof Penderecky, Gustav Kuhn, Andris Nelsons, Gerard Korsten, Daniel Kawka, Michael Tabachnik), performing chamber music (with artists including Rocco Filippini, Gary Hoffman, Ilya Grubert, Francesco Tamiati, the Ysaye and Takacs quartets).</p>\n<p>Futher information <a href=\"http://www.mariangelavacatello.com/\">Mariangela Vacatello</a></p>\n<p><img alt=\"Mariangela Vacatello © Davide Cerati\" height=\"667\" src=\"/media/uploads/images/photos/mariangela_vacatello.jpg\" width=\"1000\"></p>','<p>Born in 1982 in Naples to a family of musicians, Mariangela Vacatello began the piano at the age of 4 and studied at the Imola Academy, at the Milan Conservatory, and at the Royal Academy of Music in London with Christopher Elton. She also took a number of master classes with leading artists and had her first success at 14, performing Liszt\'s <em>Piano Concerto No. 1</em> in Milan. Since then, she has has an international career, performing as a soloist, with orchestras (under the baton of conductors such as Krystof Penderecky, Gustav Kuhn, Andris Nelsons, Gerard Korsten, Daniel Kawka, Michael Tabachnik), performing chamber music (with artists including Rocco Filippini, Gary Hoffman, Ilya Grubert, Francesco Tamiati, the Ysaye and Takacs quartets).</p>\n<p>Futher information <a href=\"http://www.mariangelavacatello.com/\">Mariangela Vacatello</a></p>\n<p><img alt=\"Mariangela Vacatello © Davide Cerati\" height=\"667\" src=\"/media/uploads/images/photos/mariangela_vacatello.jpg\" width=\"1000\"></p>','<p>Née en 1982 à Naples dans une famille de musicien, Mariangela Vacatello commence le piano à quatre ans et étudie à l\'Académie d\'Imola, au conservatoire de Milan et à l\'Académie royale de musique de Londres avec Christopher Elton. Elle suit également des master classes avec des artistes de premier plan et remporte son premier succès à l\'âge de quatorze ans, dans le <em>Concerto pour piano no. 1</em> de Liszt à Milan. Depuis, elle fait une carrière de concertiste internationale, en solo, avec orchestre (sous la direction de chefs tels que Krzysztof Penderecki, Gustav Kuhn, Andris Nelsons, Gerard Korsten, Daniel Kawka, Michel Tabachnik) ou en musique de chambre (avec des artistes comme Rocco Filippini, Gary Hoffman, Ilya Grubert, Francesco Tamiati, les Quatuors Ysaye ou Takacs).</p>\n<p>Plus d\'informations sur <a href=\"http://www.mariangelavacatello.com/\">Mariangela Vacatello</a></p>\n<p><img alt=\"Mariangela Vacatello © Davide Cerati\" height=\"667\" src=\"/media/uploads/images/photos/mariangela_vacatello.jpg\" width=\"1000\"></p>','Born in 1982 in Naples to a family of musicians, Mariangela Vacatello began the piano at the age of 4 and studied at the Imola Academy, at the Milan Conservatory, and at the Royal Academy of Music in London...','Born in 1982 in Naples to a family of musicians, Mariangela Vacatello began the piano at the age of 4 and studied at the Imola Academy, at the Milan Conservatory, and at the Royal Academy of Music in London...','Née en 1982 à Naples dans une famille de musicien, Mariangela Vacatello commence le piano à quatre ans et étudie à l\'Académie d\'Imola, au conservatoire de Milan et à l\'Académie royale de musique de Londres...',0,'','','2016-03-01 15:13:03',NULL,0,1,'','2016-03-01 13:39:42','',1,'mariangela-vacatello',2,'MARIANGELA VACATELLO','2016-03-01 15:13:03','','','','MARIANGELA VACATELLO','','left','uploads/images/photos/mariangela_vacatello_featured.jpg',''),(25,'uploads/images/photos/james_wood.jpg','James Wood © Rosi Arndt','<p>James Wood studied composition with Nadia Boulanger in Paris before going on to study music at Cambridge University where he was an organ scholar. He then went on to study percussion and conducting at the Royal Academy of Music in London. Today, he is known for his activities as a composer, conductor, and percussionist, performing a wide range of works from Medieval to contemporary music.</p>\n<p>The composer\'s catalogue, touching a variety of genres, revealing the breadth of his taste. Since 1996, he has become more and more involved in the world of computer music and electro-acoustic works, as seen in <em>Mountain Language</em> (1998), commissioned by IRCAM, and his work for musical theater, <em>Jodo</em> (1998-99). From 2002 to 2005, he composed a large-scale opera based on the life and visions of Hildegarde de Bingen.</p>\n<p>Futher information <a href=\"http://choroi.net/\">James Wood</a></p>','<p>James Wood studied composition with Nadia Boulanger in Paris before going on to study music at Cambridge University where he was an organ scholar. He then went on to study percussion and conducting at the Royal Academy of Music in London. Today, he is known for his activities as a composer, conductor, and percussionist, performing a wide range of works from Medieval to contemporary music.</p>\n<p>The composer\'s catalogue, touching a variety of genres, revealing the breadth of his taste. Since 1996, he has become more and more involved in the world of computer music and electro-acoustic works, as seen in <em>Mountain Language</em> (1998), commissioned by IRCAM, and his work for musical theater, <em>Jodo</em> (1998-99). From 2002 to 2005, he composed a large-scale opera based on the life and visions of Hildegarde de Bingen.</p>\n<p>Futher information <a href=\"http://choroi.net/\">James Wood</a></p>','<p>James Wood se forme à la composition avec Nadia Boulanger à Paris, étudie la musique à Cambridge où il travaille l\'orgue, et apprend les percussions et la direction à l\'Académie royale de musique de Londres. Aujourd\'hui, il est connu pour ses activités de compositeur, chef et percussionniste virtuose, qui couvrent un large éventail de répertoire, du Moyen Âge à aujourd\'hui.</p>\n<p>Touchant tous les genres, son catalogue de compositeur révèle la variété de ses goûts. Depuis 1996, il s\'investit de plus en plus dans le monde de l\'informatique musicale et de l\'électroacoustique, comme en témoigne <em>Mountain Language</em> (1998), commande de l\'Ircam, et son œuvre de théâtre musical <em>Jodo</em> (1998-1999). Entre 2002 et 2005, il compose un opéra d\'envergure, d\'après la vie et les visions d\'Hildegarde de Bingen.</p>\n<p>Plus d\'informations sur <a href=\"http://choroi.net/\">James Wood</a></p>','James Wood studied composition with Nadia Boulanger in Paris before going on to study music at Cambridge University where he was an organ scholar.','James Wood studied composition with Nadia Boulanger in Paris before going on to study music at Cambridge University where he was an organ scholar.','James Wood se forme à la composition avec Nadia Boulanger à Paris, étudie la musique à Cambridge où il travaille l\'orgue, et apprend les percussions et la direction à l\'Académie royale de musique de Londres.',0,'','','2016-03-01 15:18:25',NULL,0,1,'','2016-03-01 13:49:00','',1,'james-wood',2,'JAMES WOOD','2016-03-01 15:28:08','','','','JAMES WOOD','','left','uploads/images/photos/james_wood_featured.jpg',''),(26,'','','<p>Johanna Zimmer began music with the piano, organ, and singing. In 2001, she studied music at the University of Stuttgart. In parallel, she studied singing with Ulrike Sonntag, and then with Renée Morloc (singing) and Marie Helle (performance). Zimmer has performed oratorios as a solo artist (Bach, Haendel, Mendelssohn, Brahms, Fauré), has a decided fluency in the contemporary repertoire (Lachenmann, Crumb, Nono), and has premiered works by Mike Svoboda, Bernd Asmus, and Jean-Pierre Leguay. She has had extensive stage experience with the Ensemble v.act (conducted by Angelika Luz), notabley in the theatrical project on Schoenberg’s <em>Pierrot Lunaire</em> at the Staatsoper Stuttgart.</p>\n<p>A member of the ensemble SWR Vocal of Stuttgart from 2011 to 2014, she joined the Neue Vocalsolisten in 2014.</p>\n<p>Futher information <a href=\"http://johanna-zimmer.com/\">Johanna Zimmer</a></p>\n<p><img alt=\"Johanna Zimmer © Michael Zimmer\" height=\"667\" src=\"/media/uploads/images/photos/johanna_zimmer.jpg\" width=\"1000\"></p>','<p>Johanna Zimmer began music with the piano, organ, and singing. In 2001, she studied music at the University of Stuttgart. In parallel, she studied singing with Ulrike Sonntag, and then with Renée Morloc (singing) and Marie Helle (performance). Zimmer has performed oratorios as a solo artist (Bach, Haendel, Mendelssohn, Brahms, Fauré), has a decided fluency in the contemporary repertoire (Lachenmann, Crumb, Nono), and has premiered works by Mike Svoboda, Bernd Asmus, and Jean-Pierre Leguay. She has had extensive stage experience with the Ensemble v.act (conducted by Angelika Luz), notabley in the theatrical project on Schoenberg’s <em>Pierrot Lunaire</em> at the Staatsoper Stuttgart.</p>\n<p>A member of the ensemble SWR Vocal of Stuttgart from 2011 to 2014, she joined the Neue Vocalsolisten in 2014.</p>\n<p>Futher information <a href=\"http://johanna-zimmer.com/\">Johanna Zimmer</a></p>\n<p><img alt=\"Johanna Zimmer © Michael Zimmer\" height=\"667\" src=\"/media/uploads/images/photos/johanna_zimmer.jpg\" width=\"1000\"></p>','<p>Johanna Zimmer débute la musique avec le piano, l\'orgue et le chant. En 2001, elle étudie la musique à l\'Université de Stuttgart. En parallèle, elle se forme au chant avec Ulrike Sonntag, puis Renée Morloc (chant) et Marie Helle (scène).</p>\n<p>Elle se produit en soliste dans le domaine de l\'oratorio (Bach, Haendel, Mendelssohn, Brahms, Fauré). Manifestant une prédilection pour le répertoire contemporain (Lachenmann, Crumb, Nono), elle crée des œuvres de Mike Svoboda, Bernd Asmus ou Jean-Pierre Leguay. Avec l\'Ensemble v.act (direction Angelika Luz), elle fait l\'expérience de la scène, notamment dans un projet scénique autour du <em>Pierrot Lunaire</em> de Schoenberg au Staatsoper Stuttgart.</p>\n<p>Membre de l\'ensemble vocal SWR Vocal de Stuttgart de 2011 à 2014, elle intègre les Neue Vocalsolisten en 2014.</p>\n<p>Plus d\'informations sur <a href=\"http://johanna-zimmer.com/\">Johanna Zimmer</a></p>\n<p><img alt=\"Johanna Zimmer © Michael Zimmer\" height=\"667\" src=\"/media/uploads/images/photos/johanna_zimmer.jpg\" width=\"1000\"></p>','Johanna Zimmer began music with the piano, organ, and singing. In 2001, she studied music at the University of Stuttgart. In parallel, she studied singing with Ulrike Sonntag...','Johanna Zimmer began music with the piano, organ, and singing. In 2001, she studied music at the University of Stuttgart. In parallel, she studied singing with Ulrike Sonntag...','Johanna Zimmer débute la musique avec le piano, l\'orgue et le chant. En 2001, elle étudie la musique à l\'Université de Stuttgart. En parallèle, elle se forme au chant avec Ulrike Sonntag...',0,'','','2016-03-01 15:35:01',NULL,0,1,'','2016-03-01 14:02:17','',1,'johanna-zimmer',2,'JOHANNA ZIMMER','2016-03-01 15:35:01','','','','JOHANNA ZIMMER','','left','uploads/images/photos/johanna_zimmer_featured.jpg',''),(27,'uploads/images/photos/gerard_pesson.jpg','Gérard Pesson © C. Daguet / Editions Henry Lemoine','<p>Gérard Pesson studied literature and musicology at the Sorbonne, and then at the CNSMD de Paris before founding the contemporary music journal <em>Entretemps </em>in 1986. His opera <em>Forever Valley</em>, with a libretto by Marie Redonnet, premiered in 2000 at the Théâtre des Amandiers in Nanterre. In 2004 the Éditions Van Dieren published his journal <em>Cran d\'arrêt du beau temps</em>. His opera <em>Pastorale</em>, based on <em>L\'Astrée </em>by Honoré d\'Urfé, premiered in 2006 (stage premiere in 2009 at the Théâtre du Châtelet). His first recording, performed by the ensemble Fa, was released in 1996 by Accord/Una corda. Another recording, <em>Mes béatitudes</em>, an ensemble of works produced by æon in 2001 performed by the Ensemble Recherche won an award from the Académie Charles Cros. Gérard Pesson has been a composition professor at CNSMD de Paris since 2006.</p>\n<p>Futher information <a href=\"http://www.henry-lemoine.com/en/compositeurs/fiche/gerard-pesson\">Gérard Pesson</a></p>','<p>Gérard Pesson studied literature and musicology at the Sorbonne, and then at the CNSMD de Paris before founding the contemporary music journal <em>Entretemps </em>in 1986. His opera <em>Forever Valley</em>, with a libretto by Marie Redonnet, premiered in 2000 at the Théâtre des Amandiers in Nanterre. In 2004 the Éditions Van Dieren published his journal <em>Cran d\'arrêt du beau temps</em>. His opera <em>Pastorale</em>, based on <em>L\'Astrée </em>by Honoré d\'Urfé, premiered in 2006 (stage premiere in 2009 at the Théâtre du Châtelet). His first recording, performed by the ensemble Fa, was released in 1996 by Accord/Una corda. Another recording, <em>Mes béatitudes</em>, an ensemble of works produced by æon in 2001 performed by the Ensemble Recherche won an award from the Académie Charles Cros. Gérard Pesson has been a composition professor at CNSMD de Paris since 2006.</p>\n<p>Futher information <a href=\"http://www.henry-lemoine.com/en/compositeurs/fiche/gerard-pesson\">Gérard Pesson</a></p>','<p>Après des études de lettres et de musicologie à la Sorbonne, puis au Conservatoire de Paris, Gérard Pesson fonde en 1986 la revue de musique contemporaine <em>Entretemps. </em>Son opéra <em>Forever Valley</em>, sur un livret de Marie Redonnet, est créé en 2000 au Théâtre des Amandiers à Nanterre. Il publie en 2004 aux Éditions Van Dieren son journal <em>Cran d\'arrêt du beau temps</em>. Son opéra <em>Pastorale</em>, d\'après <em>L\'Astrée </em>d\'Honoré d\'Urfé, est créé en version de concert en 2006 (création scénique en 2009 au Théâtre du Châtelet). Un premier disque monographique, par l\'ensemble Fa, est paru en 1996 chez Accord/Una corda. <em>Mes béatitudes</em>, ensemble d\'œuvres paru chez æon en 2001, et interprété par l\'Ensemble Recherche, a été récompensé par l\'Académie Charles Cros. Il est professeur de composition au Conservatoire de Paris depuis 2006.</p>\n<p>Plus d\'informations sur <a href=\"http://www.henry-lemoine.com/fr/compositeurs/fiche/gerard-pesson\">Gérard Pesson</a></p>','Gérard Pesson studied literature and musicology at the Sorbonne, and then at the CNSMD de Paris before founding the contemporary music journal Entretemps in 1986.','Gérard Pesson studied literature and musicology at the Sorbonne, and then at the CNSMD de Paris before founding the contemporary music journal Entretemps in 1986.','Après des études de lettres et de musicologie à la Sorbonne, puis au Conservatoire de Paris, Gérard Pesson fonde en 1986 la revue de musique contemporaine <i>Entretemps</i>.',0,'','','2016-03-01 15:42:59',NULL,0,1,'','2016-03-01 14:10:27','',1,'gérard-pesson',2,'GÉRARD PESSON','2016-03-01 15:42:59','','','','GÉRARD PESSON','','left','uploads/images/photos/gerard_pesson_featured.jpg',''),(28,'','','<p>A professionally trained violinist, Rebecca Saunders studied composition at Edinburgh University with Nigel Osborne and Wolfgang Rhim in Germany.</p>\n<p>One of her particularities is her use of mechanical instruments, like music boxes. Space and silence interrupting specific orders are fundamental in her musical conception as are spatialization and the placement of musical instruemnts in the room: she sculpts sound and creates music like an architect. Rebecca Saunders worked with Sasha Waltz on a choreographic installation: <em>Insideout</em> (2003).</p>\n<p>Futher information <a href=\"http://edition-peters.com/composer/Saunders-Rebecca\">Rebecca Saunders</a></p>\n<p><img alt=\"Rebecca Saunders © Christian Schroth\" height=\"797\" src=\"/media/uploads/images/photos/rebecca_saunders.jpg\" width=\"1000\"></p>','<p>A professionally trained violinist, Rebecca Saunders studied composition at Edinburgh University with Nigel Osborne and Wolfgang Rhim in Germany.</p>\n<p>One of her particularities is her use of mechanical instruments, like music boxes. Space and silence interrupting specific orders are fundamental in her musical conception as are spatialization and the placement of musical instruemnts in the room: she sculpts sound and creates music like an architect. Rebecca Saunders worked with Sasha Waltz on a choreographic installation: <em>Insideout</em> (2003).</p>\n<p>Futher information <a href=\"http://edition-peters.com/composer/Saunders-Rebecca\">Rebecca Saunders</a></p>\n<p><img alt=\"Rebecca Saunders © Christian Schroth\" height=\"797\" src=\"/media/uploads/images/photos/rebecca_saunders.jpg\" width=\"1000\"></p>','<p>Violoniste de formation, Rebecca Saunders commence ses études de musique à l\'université d\'Édimbourg, études qu\'elle poursuit auprès de Wolfgang Rihm puis de Nigel Osborne.</p>\n<p>Son catalogue, varié, tient l\'une de ses particularités de l\'utilisation d\'instruments mécaniques comme des boîtes à musique. L\'espace et le silence interrompant des énoncés concis sont des paramètres fondamentaux de sa conception musicale ainsi que la spatialisation, notamment par la répartition des instrumentistes dans les salles : Rebecca Saunders sculpte le son et élabore sa musique à la manière d\'un architecte. Rebeccas Saunders a également collaboré à une « installation chorégraphique » avec Sasha Waltz :<em> Insideout</em> (2003).</p>\n<p>Plus d\'informations sur <a href=\"http://edition-peters.com/composer/Saunders-Rebecca\">Rebecca Saunders</a></p>\n<p><img alt=\"Rebecca Saunders © Christian Schroth\" height=\"797\" src=\"/media/uploads/images/photos/rebecca_saunders.jpg\" width=\"1000\"></p>','A professionally trained violinist, Rebecca Saunders studied composition at Edinburgh University with Nigel Osborne and Wolfgang Rhim in Germany.','A professionally trained violinist, Rebecca Saunders studied composition at Edinburgh University with Nigel Osborne and Wolfgang Rhim in Germany.','Violoniste de formation, Rebecca Saunders commence ses études de musique à l\'université d\'Édimbourg, études qu\'elle poursuit auprès de Wolfgang Rihm puis de Nigel Osborne.',0,'','','2016-03-01 16:03:20',NULL,0,1,'','2016-03-01 14:22:58','',1,'rebecca-saunders',2,'REBECCA SAUNDERS','2016-03-01 16:03:20','','','','REBECCA SAUNDERS','','left','uploads/images/photos/rebecca_saunders_featured.jpg',''),(29,'','','<p>Despite his training as a pianiste and composer, Philippe Manoury maintains that he is self-taught. His discovery of Karlheinz Stockhausen’s music had a decisive influence on his writing, often influenced by mathematical models. This interest led him to IRCAM where he was a part of the development of Max/MSP. This research was both the starting point and the inspiration of his oeuvre. Manoury has continued this research incessantly in parallel to his activity as a composer.</p>\n<p><img alt=\"Philippe Manoury © Philippe Stirnweiss\" height=\"665\" src=\"/media/uploads/images/photos/philippe_manoury_7.jpg\" width=\"1000\"></p>\n<p>Manoury has taught composition at the CNSMD de Lyon (1987-1997) and at at the University of California Sand Diego (2004-2012). From 1998 to 2000, he headed the Académie de composition at the Festival d\'Aix-en-Provence. In 2013, he was named composition professor at the Haute École des Arts du Rhin.</p>\n<p>Futher information <a href=\"http://www.philippemanoury.com/\">Philippe Manoury</a></p>','<p>Despite his training as a pianiste and composer, Philippe Manoury maintains that he is self-taught. His discovery of Karlheinz Stockhausen’s music had a decisive influence on his writing, often influenced by mathematical models. This interest led him to IRCAM where he was a part of the development of Max/MSP. This research was both the starting point and the inspiration of his oeuvre. Manoury has continued this research incessantly in parallel to his activity as a composer.</p>\n<p><img alt=\"Philippe Manoury © Philippe Stirnweiss\" height=\"665\" src=\"/media/uploads/images/photos/philippe_manoury_7.jpg\" width=\"1000\"></p>\n<p>Manoury has taught composition at the CNSMD de Lyon (1987-1997) and at at the University of California Sand Diego (2004-2012). From 1998 to 2000, he headed the Académie de composition at the Festival d\'Aix-en-Provence. In 2013, he was named composition professor at the Haute École des Arts du Rhin.</p>\n<p>Futher information <a href=\"http://www.philippemanoury.com/\">Philippe Manoury</a></p>','<p>Malgré sa formation de pianiste et de compositeur, Philippe Manoury se dit autodidacte. Sa rencontre avec la musique de Karlheinz Stockhausen a une influence décisive sur son écriture, qui s\'inscrit souvent dans des modèles mathématiques. Cet intérêt le conduit à l\'Ircam où il participe au développement de MAX-MSP. Ces recherches sont le point de départ de son œuvre en même temps qu\'elles la nourrissent. Depuis cette période, il ne cesse de poursuivre ses recherches parallèlement à son activité de compositeur.</p>\n<p><img alt=\"Philippe Manoury © Philippe Stirnweiss\" height=\"665\" src=\"/media/uploads/images/photos/philippe_manoury_7.jpg\" width=\"1000\"></p>\n<p>Il enseigne la composition au CNSMD de Lyon (1987-1997), dirige l\'Académie de composition du Festival d\'Aix-en-Provence (1998-2000), enseigne à l\'université de Californie à San Diego (2004-2012). En 2013, il est nommé professeur de composition à la Haute école des arts du Rhin.</p>\n<p>Plus d\'informations sur <a href=\"http://www.philippemanoury.com/\">Philippe Manoury</a></p>','Despite his training as a pianiste and composer, Philippe Manoury maintains that he is self-taught. His discovery of Karlheinz Stockhausen’s music had a decisive influence on his writing...','Despite his training as a pianiste and composer, Philippe Manoury maintains that he is self-taught. His discovery of Karlheinz Stockhausen’s music had a decisive influence on his writing...','Malgré sa formation de pianiste et de compositeur, Philippe Manoury se dit autodidacte. Sa rencontre avec la musique de Karlheinz Stockhausen a une influence décisive sur son écriture...',0,'','','2016-03-01 16:16:09',NULL,0,1,'','2016-03-01 14:43:42','',1,'philippe-manoury',2,'PHILIPPE MANOURY','2016-03-01 16:16:09','','','','PHILIPPE MANOURY','','left','uploads/images/photos/philippe_manoury_featured.jpg',''),(30,'uploads/images/photos/xavier_le_roy_1.jpg','Xavier Le Roy © Emma Picq','<p>Upon completion of his studies in molecular biology, Xavier Le Roy began working as a artist-choreographer in 1991. Following his beginings as a performer with a variety of groups and choreographers, since 1994 he has developed solo work and has initiated projects exploring modes of production and collaboration constitutive of working as a group. His latest works question the relationships between the audience and performers. Le Roy continutes his research with works developed for specific exhibit spaces.</p>\n<p>From 1996 to 2003, he was a resident at Podewil in Berlin. In 2007-2008, he was the associated artist at the CCN de Montpellier. In 2010, Xavier Le Roy was a resident in the <em>Art Culture and Technology</em> program at MIT (USA) and from 2012 to 2015 he was a resident at the Cité Internationale de Paris.</p>\n<p>Futher information <a href=\"http://xavierleroy.com/\">Xavier Le Roy</a></p>','<p>Upon completion of his studies in molecular biology, Xavier Le Roy began working as a artist-choreographer in 1991. Following his beginings as a performer with a variety of groups and choreographers, since 1994 he has developed solo work and has initiated projects exploring modes of production and collaboration constitutive of working as a group. His latest works question the relationships between the audience and performers. Le Roy continutes his research with works developed for specific exhibit spaces.</p>\n<p>From 1996 to 2003, he was a resident at Podewil in Berlin. In 2007-2008, he was the associated artist at the CCN de Montpellier. In 2010, Xavier Le Roy was a resident in the <em>Art Culture and Technology</em> program at MIT (USA) and from 2012 to 2015 he was a resident at the Cité Internationale de Paris.</p>\n<p>Futher information <a href=\"http://xavierleroy.com/\">Xavier Le Roy</a></p>','<p>Après des études de biologie moléculaire, Xavier Le Roy travaille comme artiste chorégraphique depuis 1991. Après des débuts comme interprète avec divers groupes et chorégraphes, il développe depuis 1994 des travaux solos et initie des projets explorant les modes de production et de collaboration constitutives du travail de groupe. Ses derniers travaux interrogent, entre autres, les relations entre spectateurs et performers. Il poursuit ces recherches avec des travaux développés spécifiquement pour des espaces d\'exposition.</p>\n<p>De 1996 à 2003, il est en résidence au Podewil à Berlin. En 2007-2008, il est artiste associé au CCN de Montpellier. En 2010, il est en résidence <em>Art Culture and Technology</em> au MIT (États-Unis). De 2012 à 2015, il est en résidence à la Cité internationale de Paris.</p>\n<p>Plus d\'informations sur <a href=\"http://xavierleroy.com/\">Xavier Le Roy</a></p>','pon completion of his studies in molecular biology, Xavier Le Roy began working as a artist-choreographer in 1991. Following his beginings as a performer with a variety of groups and choreographers...','pon completion of his studies in molecular biology, Xavier Le Roy began working as a artist-choreographer in 1991. Following his beginings as a performer with a variety of groups and choreographers...','Après des études de biologie moléculaire, Xavier Le Roy travaille comme artiste chorégraphique depuis 1991. Après des débuts comme interprète avec divers groupes et chorégraphes...',0,'','','2016-03-01 16:19:09',NULL,0,1,'','2016-03-01 14:50:07','',1,'xavier-le-roy',2,'XAVIER LE ROY','2016-03-01 16:21:04','','','','XAVIER LE ROY','','left','uploads/images/photos/xavier_le_roy_featured.jpg',''),(31,'uploads/images/photos/olivier_cadiot_featured.jpg','Olivier Cadiot © Jean-Luc Guérin','<p>Olivier Cadiot est l\'auteur d\'une œuvre poétique protéiforme. Depuis les premiers ouvrages parus chez P.O.L jusqu\'à l\'écriture pour le théâtre auprès de Ludovic Lagarde, de livrets d\'opéra pour Pascal Dusapin et la traduction de textes bibliques (les <em>Psaumes</em>, le <em>Cantique des Cantiques)</em> ou enfin de Gertrude Stein.</p>\n<p>Il se fait lui-même depuis plusieurs années le passeur de ses propres textes lors de lectures jubilatoires. Son écriture est fortement influencée par les avant-gardes littéraires du XX<sup>e</sup> siècle : Gertrude Stein, James Joyce, Willam Burrgoughs… Il fut marqué, comme nombre d\'écrivains de sa génération par les séminaires de Roland Barthes et, de son propre aveu, son premier choc esthétique eut lieu à l\'occasion de la lecture du poème <em>Le Tombeau d\'Anatole</em> de Mallarmé. Ainsi, manifeste-t-il dans son écriture le souci d\'une invention formelle constante, faite de découpages, de brisures, de simultanéités. Il garde pourtant toujours en ligne de mire la volonté de « rendre simples des choses compliquées ».</p>','','<p>Olivier Cadiot est l\'auteur d\'une œuvre poétique protéiforme. Depuis les premiers ouvrages parus chez P.O.L jusqu\'à l\'écriture pour le théâtre auprès de Ludovic Lagarde, de livrets d\'opéra pour Pascal Dusapin et la traduction de textes bibliques (les <em>Psaumes</em>, le <em>Cantique des Cantiques)</em> ou enfin de Gertrude Stein.</p>\n<p>Il se fait lui-même depuis plusieurs années le passeur de ses propres textes lors de lectures jubilatoires. Son écriture est fortement influencée par les avant-gardes littéraires du XX<sup>e</sup> siècle : Gertrude Stein, James Joyce, Willam Burrgoughs… Il fut marqué, comme nombre d\'écrivains de sa génération par les séminaires de Roland Barthes et, de son propre aveu, son premier choc esthétique eut lieu à l\'occasion de la lecture du poème <em>Le Tombeau d\'Anatole</em> de Mallarmé. Ainsi, manifeste-t-il dans son écriture le souci d\'une invention formelle constante, faite de découpages, de brisures, de simultanéités. Il garde pourtant toujours en ligne de mire la volonté de « rendre simples des choses compliquées ».</p>','Olivier Cadiot est l\'auteur d\'une œuvre poétique protéiforme. Depuis les premiers ouvrages parus chez P.O.L jusqu\'à l\'écriture pour le théâtre auprès de Ludovic Lagarde...','','Olivier Cadiot est l\'auteur d\'une œuvre poétique protéiforme. Depuis les premiers ouvrages parus chez P.O.L jusqu\'à l\'écriture pour le théâtre auprès de Ludovic Lagarde...',0,'','','2016-03-01 16:28:55',NULL,0,1,'','2016-03-01 14:56:59','',1,'olivier-cadiot',2,'OLIVIER CADIOT','2016-03-01 16:28:55','','','','OLIVIER CADIOT','','left','uploads/images/photos/olivier_cadiot_featured.jpg',''),(32,'','','<p>Après des études au Cours Florent et au Conservatoire national supérieur d\'art dramatique (auprès de Daniel Mesguich et Catherine Hiegel), Clotilde Hesmes joue à partir de 1999 dans des pièces, souvent exigeantes, au sein de la compagnie de François Orsoni dont elle sera membre durant plus de dix ans.</p>\n<p>Elle se fait remarquer par le réalisateur Jérôme Bonnell qui la fait tourner dans <em>Le Chignon d\'Olga </em>en 2002 puis par Philippe Garrel qui lui propose un rôle dans <em>Les Amants réguliers</em>. Sa carrière démarre réellement en 2007 avec le tournage de quatre films dont <em>Les Chansons d’amour</em> de Christophe Honoré pour lequel elle est nommée au César du meilleur espoir féminin en 2008 qu\'elle obtient en 2012 pour <em>Angèle et Tony</em>.</p>\n<p>En 2015, elle a le premier rôle féminin dans <em>Chocolat</em> où elle donne la réplique à James Thierrée et Omar Sy.</p>','','<p>Après des études au Cours Florent et au Conservatoire national supérieur d\'art dramatique (auprès de Daniel Mesguich et Catherine Hiegel), Clotilde Hesmes joue à partir de 1999 dans des pièces, souvent exigeantes, au sein de la compagnie de François Orsoni dont elle sera membre durant plus de dix ans.</p>\n<p>Elle se fait remarquer par le réalisateur Jérôme Bonnell qui la fait tourner dans <em>Le Chignon d\'Olga </em>en 2002 puis par Philippe Garrel qui lui propose un rôle dans <em>Les Amants réguliers</em>. Sa carrière démarre réellement en 2007 avec le tournage de quatre films dont <em>Les Chansons d’amour</em> de Christophe Honoré pour lequel elle est nommée au César du meilleur espoir féminin en 2008 qu\'elle obtient en 2012 pour <em>Angèle et Tony</em>.</p>\n<p>En 2015, elle a le premier rôle féminin dans <em>Chocolat</em> où elle donne la réplique à James Thierrée et Omar Sy.</p>','Après des études au Cours Florent et au Conservatoire national supérieur d\'art dramatique, Clotilde Hesmes joue à partir de 1999 dans des pièces, souvent exigeantes...','','Après des études au Cours Florent et au Conservatoire national supérieur d\'art dramatique, Clotilde Hesmes joue à partir de 1999 dans des pièces, souvent exigeantes...',0,'','','2016-03-01 16:30:47',NULL,0,1,'','2016-03-01 15:02:43','',1,'clotilde-hesmes',2,'CLOTILDE HESMES','2016-03-01 16:30:47','','','','CLOTILDE HESMES','','left','',''),(33,'','','<p>Laurent Poitrenaux a effectué la majeure partie de sa formation à l\'École Théâtre en Actes dirigée par Lucien Marchal.</p>\n<p>Il se lie très vite au metteur en scène Ludovic Lagarde et devient le l\'interprète fétiche de l\'écrivain Olivier Cadiot. Le trio collabore sur les spectacles <em>Soeurs et Frères</em>, <em>Le Colonel des Zouaves</em>, <em>Retour définitif et durable de l\'être aimé</em>, <em>Fairy queen</em>, <em>Un nid pour quoi faire, Un Mage en été </em>créé au festival d\'Avignon 2010, dans La trilogie Büchner (<em>Woyzeck</em>, <em>La Mort de Danton</em> et <em>Léonce et Léna</em>) et <em>Lear is Town</em> créé au festival d\'Avignon 2013. Il jouera, sous la direction de Ludovic Lagarde, <em>L\'Avare </em>de Molière en avril 2016.<br> Au cinéma, il a travaillé avec Claude Mouriéras, Sigried Alnoy, Christine Dory, Patrick Mille, Gilles Bourdos, Christian Vincent, Sophie Fillières et plus récemment avec Agnès Jaoui dans <em>Au bout du conte</em>, Isabelle Czajka dans <em>D\'Amour et d\'eau fraîche </em>et <em>La vie Domestique</em>, et Mathieu Amalric dans <em>La Chambre bleue</em>.</p>','','<p>Laurent Poitrenaux a effectué la majeure partie de sa formation à l\'École Théâtre en Actes dirigée par Lucien Marchal.</p>\n<p>Il se lie très vite au metteur en scène Ludovic Lagarde et devient le l\'interprète fétiche de l\'écrivain Olivier Cadiot. Le trio collabore sur les spectacles <em>Soeurs et Frères</em>, <em>Le Colonel des Zouaves</em>, <em>Retour définitif et durable de l\'être aimé</em>, <em>Fairy queen</em>, <em>Un nid pour quoi faire, Un Mage en été </em>créé au festival d\'Avignon 2010, dans La trilogie Büchner (<em>Woyzeck</em>, <em>La Mort de Danton</em> et <em>Léonce et Léna</em>) et <em>Lear is Town</em> créé au festival d\'Avignon 2013. Il jouera, sous la direction de Ludovic Lagarde, <em>L\'Avare </em>de Molière en avril 2016.<br> Au cinéma, il a travaillé avec Claude Mouriéras, Sigried Alnoy, Christine Dory, Patrick Mille, Gilles Bourdos, Christian Vincent, Sophie Fillières et plus récemment avec Agnès Jaoui dans <em>Au bout du conte</em>, Isabelle Czajka dans <em>D\'Amour et d\'eau fraîche </em>et <em>La vie Domestique</em>, et Mathieu Amalric dans <em>La Chambre bleue</em>.</p>','Laurent Poitrenaux a effectué la majeure partie de sa formation à l\'École Théâtre en Actes dirigée par Lucien Marchal.','','Laurent Poitrenaux a effectué la majeure partie de sa formation à l\'École Théâtre en Actes dirigée par Lucien Marchal.',0,'','','2016-03-01 16:34:06',NULL,0,1,'','2016-03-01 15:05:20','',1,'laurent-poitneraux',2,'LAURENT POITNERAUX','2016-03-01 16:34:06','','','','LAURENT POITNERAUX','','left','',''),(34,'','','<p>Musicien inventeur et indocile, Benoît Delbecq se produit de par le monde en mêlant l\'âme du jazz avec le piano préparé cher à John Cage, tout en s\'acoquinant parfois des outils électroniques d\'aujourd\'hui. Il a été l\'un des activistes des collectifs Hask (1992-2004) et Astrolab (1994-1999). Ses musiques et projets comportent également nombre de collaborations avec le théâtre, la danse contemporaine, la littérature, les arts plastiques et cinématographiques. Il se produit dans le monde entier dans les plus importants festivals. Il a publié 37 disques en leader ou co-leader parmi une discographie comptant plus d\'une centaine de disques. Depuis le milieu des années 1990, il reçoit l\'approbation de la critique internationale, et son approche à « multivitesses » ou « polyvitesses » de son jeu au piano influence désormais nombre de musiciens des nouvelles générations.</p>','','<p>Musicien inventeur et indocile, Benoît Delbecq se produit de par le monde en mêlant l\'âme du jazz avec le piano préparé cher à John Cage, tout en s\'acoquinant parfois des outils électroniques d\'aujourd\'hui. Il a été l\'un des activistes des collectifs Hask (1992-2004) et Astrolab (1994-1999). Ses musiques et projets comportent également nombre de collaborations avec le théâtre, la danse contemporaine, la littérature, les arts plastiques et cinématographiques. Il se produit dans le monde entier dans les plus importants festivals. Il a publié 37 disques en leader ou co-leader parmi une discographie comptant plus d\'une centaine de disques. Depuis le milieu des années 1990, il reçoit l\'approbation de la critique internationale, et son approche à « multivitesses » ou « polyvitesses » de son jeu au piano influence désormais nombre de musiciens des nouvelles générations.</p>','Musicien inventeur et indocile, Benoît Delbecq se produit de par le monde en mêlant l\'âme du jazz avec le piano préparé cher à John Cage, tout en s\'acoquinant parfois des outils électroniques d\'aujourd\'hui.','','Musicien inventeur et indocile, Benoît Delbecq se produit de par le monde en mêlant l\'âme du jazz avec le piano préparé cher à John Cage, tout en s\'acoquinant parfois des outils électroniques d\'aujourd\'hui.',0,'','','2016-03-01 16:37:45',NULL,0,1,'','2016-03-01 15:09:18','',1,'benoît-delbecq',2,'BENOÎT DELBECQ','2016-03-01 16:37:45','','','','BENOÎT DELBECQ','','left','',''),(35,'','','<p>The Argentinian composer Tomas Bordalejo is passionate about the rythmes, styles, and genres from his native land. Tomas taught himself to play guitar before studying jazz in Buenos Aires. At the age of 22, he came to Europe to study music at the Conservatoire de Gennevilliers, the CRR de Paris, and at the Pôle Supérieur Paris Boulogne-Billancourt. His meeting with Bernard Cavanna was a decisive moment in his career.</p>\n<p>His recent works include <em>Parkour </em>(2012) for 8 horns and orchestra, <em>Surveiller et Punir </em>(2012) for violin, cello, and accordion, <em>Sapier And Inô</em> (2014) for ensemble, <em>Zapping 2</em> (2013) for ensemble, <em>Cercles</em> for piano, <em>En Rappel </em>for accordion, <em>D’ombre et de Lumière </em>(2015) for violin, <em>IOTA (2015) </em>and <em>BUREAU 470 </em>(2016), Kafka-esque pocket operas.</p>\n<p>Futher information <a href=\"http://tomasbordalejo.tumblr.com/\">Tomas Bordalejo</a></p>\n<p><img alt=\"Tomas Bordalejo © pfroment\" height=\"646\" src=\"/media/uploads/images/photos/tomas_bordalejo.jpg\" width=\"1000\"></p>','<p>The Argentinian composer Tomas Bordalejo is passionate about the rythmes, styles, and genres from his native land. Tomas taught himself to play guitar before studying jazz in Buenos Aires. At the age of 22, he came to Europe to study music at the Conservatoire de Gennevilliers, the CRR de Paris, and at the Pôle Supérieur Paris Boulogne-Billancourt. His meeting with Bernard Cavanna was a decisive moment in his career.</p>\n<p>His recent works include <em>Parkour </em>(2012) for 8 horns and orchestra, <em>Surveiller et Punir </em>(2012) for violin, cello, and accordion, <em>Sapier And Inô</em> (2014) for ensemble, <em>Zapping 2</em> (2013) for ensemble, <em>Cercles</em> for piano, <em>En Rappel </em>for accordion, <em>D’ombre et de Lumière </em>(2015) for violin, <em>IOTA (2015) </em>and <em>BUREAU 470 </em>(2016), Kafka-esque pocket operas.</p>\n<p>Futher information <a href=\"http://tomasbordalejo.tumblr.com/\">Tomas Bordalejo</a></p>\n<p><img alt=\"Tomas Bordalejo © pfroment\" height=\"646\" src=\"/media/uploads/images/photos/tomas_bordalejo.jpg\" width=\"1000\"></p>','<p>D\'origine argentine, Tomas Bordalejo est un passionné de tous les rythmes, styles et genres musicaux de son pays natal. Il apprend d\'abord la guitare en autodidacte puis étudie le jazz à Buenos Aires. À 22 ans, il gagne l\'Europe pour suivre des études musicales plus approfondies qui l\'amèneront notamment au Conservatoire de Gennevilliers, au CRR de Paris et au Pôle Supérieur Paris Boulogne-Billancourt. Sa rencontre avec Bernard Cavanna est déterminante.</p>\n<p>Parmi ses œuvres récentes, citons <em>Parkour </em>(2012) pour 8 cors et orchestre, <em>Surveiller et Punir </em>(2012) pour violon, violoncelle et accordéon, <em>Sapier And Inô</em> (2014) pour ensemble, <em>Zapping 2</em> (2013) pour ensemble, <em>Cercles</em> pour piano et <em>En Rappel </em>pour accordéon, <em>D\'ombre et de Lumière </em>(2015) pour violon mais également <em>IOTA (2015), 3 Motets </em>et <em>BUREAU 470 </em>(2016), opéra de poche kafkaïen.</p>\n<p>Plus d\'informations sur <a href=\"http://tomasbordalejo.tumblr.com/\">Tomas Bordalejo</a></p>\n<p><img alt=\"Tomas Bordalejo © pfroment\" height=\"646\" src=\"/media/uploads/images/photos/tomas_bordalejo.jpg\" width=\"1000\"></p>','The Argentinian composer Tomas Bordalejo is passionate about the rythmes, styles, and genres from his native land. Tomas taught himself to play guitar before studying jazz in Buenos Aires.','The Argentinian composer Tomas Bordalejo is passionate about the rythmes, styles, and genres from his native land. Tomas taught himself to play guitar before studying jazz in Buenos Aires.','D\'origine argentine, Tomas Bordalejo est un passionné de tous les rythmes, styles et genres musicaux de son pays natal. Il apprend d\'abord la guitare en autodidacte puis étudie le jazz à Buenos Aires.',0,'','','2016-03-01 16:48:29',NULL,0,1,'','2016-03-01 15:11:48','',1,'tomas-bordalejo',2,'TOMAS BORDALEJO','2016-03-01 16:48:29','','','','TOMAS BORDALEJO','','left','uploads/images/photos/tomas_bordalejo_featured.jpg',''),(36,'','','<p>Heiner Goebbels moved to Frankfurt am Main in 1972 to study sociology and music. In 1976 he founded the Sogenannten Linksradikalen Blasorchester (<em>lit. Radical-Left Wind Orchestra</em>), a duo with Alfred Harth, and Cassiber an experimental rock group.</p>\n<p><img alt=\"Mention de copyright: Heiner Goebbels © Wonge Bergmann for the Ruhrtriennale\" height=\"650\" src=\"/media/uploads/images/photos/heiner_goebbels_3.jpg\" width=\"1000\"></p>\n<p>He first composed music for the theater for Hans Neuenfels, Claus Peymann, Matthias Langhoff, Ruth Berghaus and music for film for Helke Sander. In the mid-1980s, he composed and staged his own works—several of which were based on works by Heiner Müller, Bertold Brecht and Hanns Eisler, Samuel Beckett, and Gertrude Stein. Author of numerous musical works for theater and productions, Heiner Goebbels erased the boundary between opera and theater.</p>\n<p>Futher information <a href=\"http://www.heinergoebbels.com/\">Heiner Goebbels</a></p>','<p>Heiner Goebbels moved to Frankfurt am Main in 1972 to study sociology and music. In 1976 he founded the Sogenannten Linksradikalen Blasorchester (<em>lit. Radical-Left Wind Orchestra</em>), a duo with Alfred Harth, and Cassiber an experimental rock group.</p>\n<p><img alt=\"Mention de copyright: Heiner Goebbels © Wonge Bergmann for the Ruhrtriennale\" height=\"650\" src=\"/media/uploads/images/photos/heiner_goebbels_3.jpg\" width=\"1000\"></p>\n<p>He first composed music for the theater for Hans Neuenfels, Claus Peymann, Matthias Langhoff, Ruth Berghaus and music for film for Helke Sander. In the mid-1980s, he composed and staged his own works—several of which were based on works by Heiner Müller, Bertold Brecht and Hanns Eisler, Samuel Beckett, and Gertrude Stein. Author of numerous musical works for theater and productions, Heiner Goebbels erased the boundary between opera and theater.</p>\n<p>Futher information <a href=\"http://www.heinergoebbels.com/\">Heiner Goebbels</a></p>','<p>Heiner Goebbels s\'installe à Francfort-sur-le-Main en 1972 pour étudier la sociologie et la musique. Il fonde en 1976 le Sogenannten Linksradikalen Blasorchester (« orchestre à vent radical de gauche »), ainsi qu\'un duo avec Alfred Harth et Cassiber, un groupe de rock expériental.</p>\n<p><img alt=\"Mention de copyright: Heiner Goebbels © Wonge Bergmann for the Ruhrtriennale\" height=\"650\" src=\"/media/uploads/images/photos/heiner_goebbels_3.jpg\" width=\"1000\"></p>\n<p>Il compose d\'abord de la musique de scène pour Hans Neuenfels, Claus Peymann, Matthias Langhoff, Ruth Berghaus et de la musique de film pour Helke Sander. Au milieu des années 1980, il compose et met en scène ses propres œuvres – dont de nombreuses sur des œuvres de Heiner Müller, Bertold Brecht et Hanns Eisler, Samuel Beckett ou Gertrud Stein. Auteur de nombreuses musiques de théâtre et mises en scènes, Heiner Goebbels fait disparaître la frontière entre opéra et théâtre.</p>\n<p>Plus d\'informations sur <a href=\"http://www.heinergoebbels.com/\">Heiner Goebbels</a></p>\n<p></p>','Heiner Goebbels moved to Frankfurt am Main in 1972 to study sociology and music. In 1976 he founded the Sogenannten Linksradikalen Blasorchester...','Heiner Goebbels moved to Frankfurt am Main in 1972 to study sociology and music. In 1976 he founded the Sogenannten Linksradikalen Blasorchester...','Heiner Goebbels s\'installe à Francfort-sur-le-Main en 1972 pour étudier la sociologie et la musique. Il fonde en 1976 le Sogenannten Linksradikalen Blasorchester...',0,'','','2016-03-01 16:58:21',NULL,0,1,'','2016-03-01 15:24:41','',1,'heiner-goebbels',2,'HEINER GOEBBELS','2016-03-01 16:58:21','','','','HEINER GOEBBELS','','left','uploads/images/photos/heiner_goebbels_featured.jpg',''),(37,'','','<p>Julien Leroy started his training at the Sergiu Celibidache Stiftung München, followed by classes with A. McDonnell at the Conservatoire de la Ville de Paris. He perfected his art through several master classes directed by V. Gergiev, K. Masur, and D. Harding. Leroy improved his knowledge of the contemporary repertoire with P. Boulez and L. Cuniot. His repertoire extends from the 18<sup>th</sup> century to contemporary music. From 2012 to 2015 he was the assistant conductor for the Ensemble intercontemporain, performing several premieres including <em>Winterreise </em>(F. Schubert/M. Andre) and <em>Te craindre en ton absence</em> by H. Parra. Julien Leroy is the musical director of the Paris Percussion Group and a works regularly with Court-Circuit, Sillages, and United Instruments of Lucilin.</p>\n<p>Futher information <a href=\"http://julienleroy.com/julienleroyconductor/Home.html\">Julien Leroy</a></p>\n<p><img alt=\"Julien Leroy © Phuong N\'guyen\" height=\"665\" src=\"/media/uploads/images/photos/julien_leroy_3.jpg\" width=\"1000\"></p>','<p>Julien Leroy started his training at the Sergiu Celibidache Stiftung München, followed by classes with A. McDonnell at the Conservatoire de la Ville de Paris. He perfected his art through several master classes directed by V. Gergiev, K. Masur, and D. Harding. Leroy improved his knowledge of the contemporary repertoire with P. Boulez and L. Cuniot. His repertoire extends from the 18<sup>th</sup> century to contemporary music. From 2012 to 2015 he was the assistant conductor for the Ensemble intercontemporain, performing several premieres including <em>Winterreise </em>(F. Schubert/M. Andre) and <em>Te craindre en ton absence</em> by H. Parra. Julien Leroy is the musical director of the Paris Percussion Group and a works regularly with Court-Circuit, Sillages, and United Instruments of Lucilin.</p>\n<p>Futher information <a href=\"http://julienleroy.com/julienleroyconductor/Home.html\">Julien Leroy</a></p>\n<p><img alt=\"Julien Leroy © Phuong N\'guyen\" height=\"665\" src=\"/media/uploads/images/photos/julien_leroy_3.jpg\" width=\"1000\"></p>','<p>Initié à la direction au sein de la Fondation Sergiu Celibidache, Julien Leroy poursuit sa formation avec A. McDonnell au conservatoire de la Ville de Paris. Il se perfectionne lors de master classes avec V. Gergiev, K. Masur et D. Harding. Il approfondit le répertoire contemporain auprès de P. Boulez et L. Cuniot. Son répertoire s\'étend de la musique du XVIII<sup>e</sup> siècle au contemporain. De 2012 à 2015, il est chef assistant de l\'Ensemble intercontemporain et assure de nombreuses créations, dont <em>Winterreise </em>(F. Schubert/M. Andre) et <em>Te craindre en ton absence</em> d\'H. Parra. Julien Leroy est directeur musical du Paris Percussion Group et partenaire régulier des ensembles Court-circuit, Sillages et United Instruments of Lucilin.</p>\n<p>Plus d\'informations sur <a href=\"http://julienleroy.com/julienleroyChefdorchestre/Bienvenue.html\">Julien Leroy</a></p>\n<p><img alt=\"Julien Leroy © Phuong N\'guyen\" height=\"665\" src=\"/media/uploads/images/photos/julien_leroy_3.jpg\" width=\"1000\"></p>','Julien Leroy started his training at the Sergiu Celibidache Stiftung München, followed by classes with A. McDonnell at the Conservatoire de la Ville de Paris.','Julien Leroy started his training at the Sergiu Celibidache Stiftung München, followed by classes with A. McDonnell at the Conservatoire de la Ville de Paris.','Initié à la direction au sein de la Fondation Sergiu Celibidache, Julien Leroy poursuit sa formation avec A. McDonnell au conservatoire de la Ville de Paris.',0,'','','2016-03-01 17:28:14',NULL,0,1,'','2016-03-01 15:55:23','',1,'julien-leroy',2,'JULIEN LEROY','2016-03-01 17:28:14','','','','JULIEN LEROY','','left','uploads/images/photos/julien_leroy_featured.jpg',''),(38,'','','<p>Founded in 1930 by the French radio, based on the legacy of the first orchestra created in 1928 by André Messager, the Orchestre Philharmonique was remodeled in 1976 following Pierre Boulez\' criticism of the rigidity of traditional symphonic groups. On the contrary, the orchestra can simultaneously break down into several formations ranging from a small ensemble to a full orchestra, adapting to all configurations required by the repertory from the 18th century to today. Committed to renewing the repertory, the orchestra performs twenty premieres (French or worldwide) annually. The composer Gilbert Amy and the conductor Marek Janowski were the first musical directors, followed by Myung-Whun Chung, succeeded by Mikko Franck in 2015.</p>\n<p>Futher information <a href=\"http://maisondelaradio.fr/concerts-classiques/orchestre-philharmonique-de-radio-france\">Orchestre Philharmonique de Radio France</a></p>\n<p><img alt=\"Orchestre Philharmonique de Radio France © Radio France / Christophe Abramowitz\" height=\"663\" src=\"/media/uploads/images/photos/oprf.jpg\" width=\"1000\"></p>','<p>Founded in 1930 by the French radio, based on the legacy of the first orchestra created in 1928 by André Messager, the Orchestre Philharmonique was remodeled in 1976 following Pierre Boulez\' criticism of the rigidity of traditional symphonic groups. On the contrary, the orchestra can simultaneously break down into several formations ranging from a small ensemble to a full orchestra, adapting to all configurations required by the repertory from the 18th century to today. Committed to renewing the repertory, the orchestra performs twenty premieres (French or worldwide) annually. The composer Gilbert Amy and the conductor Marek Janowski were the first musical directors, followed by Myung-Whun Chung, succeeded by Mikko Franck in 2015.</p>\n<p>Futher information <a href=\"http://maisondelaradio.fr/concerts-classiques/orchestre-philharmonique-de-radio-france\">Orchestre Philharmonique de Radio France</a></p>\n<p><img alt=\"Orchestre Philharmonique de Radio France © Radio France / Christophe Abramowitz\" height=\"663\" src=\"/media/uploads/images/photos/oprf.jpg\" width=\"1000\"></p>','<p>Créé dans les années 1930 par la radio française sur les bases d\'un premier orchestre de radio fondé en 1928 par André Messager, l\'Orchestre Philharmonique a été refondé en 1976 sous l\'inspiration de Pierre Boulez qui dénonçait le manque de flexibilité des formations traditionnelles. L\'Orchestre Philharmonique peut aborder tous les répertoires du XVIII<sup>e</sup> siècle à nos jours, que les œuvres soient écrites pour petit ensemble ou pour grand orchestre. Engagé dans le renouvellement du répertoire, l\'orchestre donne la création française ou mondiale d\'une vingtaine d\'œuvres chaque année. Le compositeur Gilbert Amy et le chef Marek Janowski en ont été les premiers directeurs musicaux, suivi de Myung-Whun Chung, Mikko Franck lui succédant à partir de 2015.</p>\n<p>Plus d\'informations sur l\'<a href=\"http://maisondelaradio.fr/concerts-classiques/orchestre-philharmonique-de-radio-france\">Orchestre Philharmonique de Radio France</a></p>\n<p><img alt=\"Orchestre Philharmonique de Radio France © Radio France / Christophe Abramowitz\" height=\"663\" src=\"/media/uploads/images/photos/oprf.jpg\" width=\"1000\"></p>','Founded in 1930 by the French radio, based on the legacy of the first orchestra created in 1928 by André Messager, the Orchestre Philharmonique was remodeled in 1976 following Pierre Boulez...','Founded in 1930 by the French radio, based on the legacy of the first orchestra created in 1928 by André Messager, the Orchestre Philharmonique was remodeled in 1976 following Pierre Boulez...','Créé dans les années 1930 par la radio française sur les bases d\'un premier orchestre de radio fondé en 1928 par André Messager, l\'Orchestre Philharmonique a été refondé en 1976 sous l\'inspiration de Pierre Boulez...',0,'','','2016-03-01 17:52:05',NULL,0,1,'','2016-03-01 16:16:28','',1,'orchestre-philharmonique-de-radio-france',2,'ORCHESTRE PHILHARMONIQUE DE RADIO FRANCE','2016-03-01 17:52:05','','','','ORCHESTRE PHILHARMONIQUE DE RADIO FRANCE','','left','uploads/images/photos/oprf_featured.jpg',''),(39,'','','<p>French conductor, bassoonist, composer, Dylan Corlay won  in 2015 the International Conducting Jorma Panula music competition and has been appointed assistant conductor of the Ensemble Intercontemporain.</p>\n<p>Futher information <a href=\"http://www.dylancorlay.com/spip.php?page=sommaire\">Dylan Corlay</a></p>\n<p><img alt=\"Dylan Corlay\" height=\"593\" src=\"/media/uploads/images/photos/dylan_corlay_1.jpg\" width=\"1000\"></p>','<p>French conductor, bassoonist, composer, Dylan Corlay won  in 2015 the International Conducting Jorma Panula music competition and has been appointed assistant conductor of the Ensemble Intercontemporain.</p>\n<p>Futher information <a href=\"http://www.dylancorlay.com/spip.php?page=sommaire\">Dylan Corlay</a></p>\n<p><img alt=\"Dylan Corlay\" height=\"593\" src=\"/media/uploads/images/photos/dylan_corlay_1.jpg\" width=\"1000\"></p>','<p>Chef d\'orchestre, bassoniste et compositeur français, Dylan Corlay a remporté en 2015 le prix international de direction Jorma Panula et a été nommé chef assistant de l\'Ensemble intercontemporain. </p>\n<p>Plus d\'informations sur <a href=\"http://www.dylancorlay.com/spip.php?page=sommaire\">Dylan Corlay</a></p>\n<p><img alt=\"Dylan Corlay\" height=\"593\" src=\"/media/uploads/images/photos/dylan_corlay_1.jpg\" width=\"1000\"></p>','French conductor, bassoonist, composer, Dylan Corlay won  in 2015 the International Conducting Jorma Panula music competition and has been appointed assistant conductor of the Ensemble Intercontemporain.','French conductor, bassoonist, composer, Dylan Corlay won  in 2015 the International Conducting Jorma Panula music competition and has been appointed assistant conductor of the Ensemble Intercontemporain.','Chef d\'orchestre, bassoniste et compositeur français, Dylan Corlay a remporté en 2015 le prix international de direction Jorma Panula et a été nommé chef assistant de l\'Ensemble intercontemporain.',0,'','','2016-03-01 18:04:36',NULL,0,1,'','2016-03-01 16:26:44','',1,'dylan-corlay',2,'DYLAN CORLAY','2016-03-02 12:29:07','','','','DYLAN CORLAY','','left','uploads/images/photos/dylan_corlay_featured.jpg','');
/*!40000 ALTER TABLE `festival_artists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_eventcategory`
--

DROP TABLE IF EXISTS `festival_eventcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_eventcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  `description` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_eventcategory`
--

LOCK TABLES `festival_eventcategory` WRITE;
/*!40000 ALTER TABLE `festival_eventcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_eventcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_events`
--

DROP TABLE IF EXISTS `festival_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eve_event_id` int(11) NOT NULL,
  `featured` tinyint(1) NOT NULL,
  `featured_image` varchar(1024) NOT NULL,
  `featured_image_header` varchar(1024) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `event_id` int(11) DEFAULT NULL,
  `featured_image_description` longtext NOT NULL,
  PRIMARY KEY (`id`),
  KEY `festiv_category_id_43356ff053afa4e5_fk_festival_eventcategory_id` (`category_id`),
  KEY `festival__event_id_59a8caff1179c338_fk_mezzanine_agenda_event_id` (`event_id`),
  CONSTRAINT `festiv_category_id_43356ff053afa4e5_fk_festival_eventcategory_id` FOREIGN KEY (`category_id`) REFERENCES `festival_eventcategory` (`id`),
  CONSTRAINT `festival__event_id_59a8caff1179c338_fk_mezzanine_agenda_event_id` FOREIGN KEY (`event_id`) REFERENCES `mezzanine_agenda_event` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_events`
--

LOCK TABLES `festival_events` WRITE;
/*!40000 ALTER TABLE `festival_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_events_artists`
--

DROP TABLE IF EXISTS `festival_events_artists`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_events_artists` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `festivalevent_id` int(11) NOT NULL,
  `artist_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `festivalevent_id` (`festivalevent_id`,`artist_id`),
  KEY `festival_event_artist_id_4d667c1a020c301b_fk_festival_artists_id` (`artist_id`),
  CONSTRAINT `festival_event_artist_id_4d667c1a020c301b_fk_festival_artists_id` FOREIGN KEY (`artist_id`) REFERENCES `festival_artists` (`id`),
  CONSTRAINT `festival_festivalevent_id_111955a710e5179d_fk_festival_events_id` FOREIGN KEY (`festivalevent_id`) REFERENCES `festival_events` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_events_artists`
--

LOCK TABLES `festival_events_artists` WRITE;
/*!40000 ALTER TABLE `festival_events_artists` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_events_artists` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_pagecategory`
--

DROP TABLE IF EXISTS `festival_pagecategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_pagecategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  `description` longtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_pagecategory`
--

LOCK TABLES `festival_pagecategory` WRITE;
/*!40000 ALTER TABLE `festival_pagecategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_pagecategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `festival_videos`
--

DROP TABLE IF EXISTS `festival_videos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `festival_videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keywords_string` varchar(500) NOT NULL,
  `title` varchar(500) NOT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `_meta_title` varchar(500) DEFAULT NULL,
  `description` longtext NOT NULL,
  `gen_description` tinyint(1) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `status` int(11) NOT NULL,
  `publish_date` datetime DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `short_url` varchar(200) DEFAULT NULL,
  `in_sitemap` tinyint(1) NOT NULL,
  `media_id` int(11) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  `content` longtext NOT NULL,
  `description_en` longtext,
  `description_fr` longtext,
  `title_en` varchar(500) DEFAULT NULL,
  `title_fr` varchar(500) DEFAULT NULL,
  `content_en` longtext,
  `content_fr` longtext,
  PRIMARY KEY (`id`),
  KEY `festival_video_site_id_4b2a2aeefa63025_fk_django_site_id` (`site_id`),
  KEY `festival_video_76776489` (`publish_date`),
  KEY `festival__event_id_42229c3b7115c0f9_fk_mezzanine_agenda_event_id` (`event_id`),
  CONSTRAINT `festival__event_id_42229c3b7115c0f9_fk_mezzanine_agenda_event_id` FOREIGN KEY (`event_id`) REFERENCES `mezzanine_agenda_event` (`id`),
  CONSTRAINT `festival_video_site_id_4b2a2aeefa63025_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `festival_videos`
--

LOCK TABLES `festival_videos` WRITE;
/*!40000 ALTER TABLE `festival_videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `festival_videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_field`
--

DROP TABLE IF EXISTS `forms_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `_order` int(11) DEFAULT NULL,
  `label` varchar(200) NOT NULL,
  `field_type` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  `choices` varchar(1000) NOT NULL,
  `default` varchar(2000) NOT NULL,
  `placeholder_text` varchar(100) NOT NULL,
  `help_text` varchar(100) NOT NULL,
  `form_id` int(11) NOT NULL,
  `choices_en` varchar(1000) DEFAULT NULL,
  `choices_fr` varchar(1000) DEFAULT NULL,
  `default_en` varchar(2000) DEFAULT NULL,
  `default_fr` varchar(2000) DEFAULT NULL,
  `help_text_en` varchar(100) DEFAULT NULL,
  `help_text_fr` varchar(100) DEFAULT NULL,
  `label_en` varchar(200) DEFAULT NULL,
  `label_fr` varchar(200) DEFAULT NULL,
  `placeholder_text_en` varchar(100) DEFAULT NULL,
  `placeholder_text_fr` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `forms_field_d6cba1ad` (`form_id`),
  CONSTRAINT `forms_field_form_id_3660963e8b17a175_fk_forms_form_page_ptr_id` FOREIGN KEY (`form_id`) REFERENCES `forms_form` (`page_ptr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_field`
--

LOCK TABLES `forms_field` WRITE;
/*!40000 ALTER TABLE `forms_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_fieldentry`
--

DROP TABLE IF EXISTS `forms_fieldentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_fieldentry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_id` int(11) NOT NULL,
  `value` varchar(2000) DEFAULT NULL,
  `entry_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `forms_fieldentry_b64a62ea` (`entry_id`),
  CONSTRAINT `forms_fieldentry_entry_id_7b83c1acf66a9d67_fk_forms_formentry_id` FOREIGN KEY (`entry_id`) REFERENCES `forms_formentry` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_fieldentry`
--

LOCK TABLES `forms_fieldentry` WRITE;
/*!40000 ALTER TABLE `forms_fieldentry` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_fieldentry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_form`
--

DROP TABLE IF EXISTS `forms_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_form` (
  `page_ptr_id` int(11) NOT NULL,
  `content` longtext NOT NULL,
  `button_text` varchar(50) NOT NULL,
  `response` longtext NOT NULL,
  `send_email` tinyint(1) NOT NULL,
  `email_from` varchar(254) NOT NULL,
  `email_copies` varchar(200) NOT NULL,
  `email_subject` varchar(200) NOT NULL,
  `email_message` longtext NOT NULL,
  `button_text_en` varchar(50) DEFAULT NULL,
  `button_text_fr` varchar(50) DEFAULT NULL,
  `content_en` longtext,
  `content_fr` longtext,
  `email_message_en` longtext,
  `email_message_fr` longtext,
  `email_subject_en` varchar(200) DEFAULT NULL,
  `email_subject_fr` varchar(200) DEFAULT NULL,
  `response_en` longtext,
  `response_fr` longtext,
  PRIMARY KEY (`page_ptr_id`),
  CONSTRAINT `forms_form_page_ptr_id_2363a7422cd85950_fk_pages_page_id` FOREIGN KEY (`page_ptr_id`) REFERENCES `pages_page` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_form`
--

LOCK TABLES `forms_form` WRITE;
/*!40000 ALTER TABLE `forms_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_formentry`
--

DROP TABLE IF EXISTS `forms_formentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_formentry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_time` datetime NOT NULL,
  `form_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `forms_forment_form_id_5fca4521fe2d9b9b_fk_forms_form_page_ptr_id` (`form_id`),
  CONSTRAINT `forms_forment_form_id_5fca4521fe2d9b9b_fk_forms_form_page_ptr_id` FOREIGN KEY (`form_id`) REFERENCES `forms_form` (`page_ptr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_formentry`
--

LOCK TABLES `forms_formentry` WRITE;
/*!40000 ALTER TABLE `forms_formentry` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_formentry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `galleries_gallery`
--

DROP TABLE IF EXISTS `galleries_gallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `galleries_gallery` (
  `page_ptr_id` int(11) NOT NULL,
  `content` longtext NOT NULL,
  `zip_import` varchar(100) NOT NULL,
  `content_en` longtext,
  `content_fr` longtext,
  PRIMARY KEY (`page_ptr_id`),
  CONSTRAINT `galleries_gallery_page_ptr_id_6cf84f17bef39d64_fk_pages_page_id` FOREIGN KEY (`page_ptr_id`) REFERENCES `pages_page` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `galleries_gallery`
--

LOCK TABLES `galleries_gallery` WRITE;
/*!40000 ALTER TABLE `galleries_gallery` DISABLE KEYS */;
/*!40000 ALTER TABLE `galleries_gallery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `galleries_galleryimage`
--

DROP TABLE IF EXISTS `galleries_galleryimage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `galleries_galleryimage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `_order` int(11) DEFAULT NULL,
  `file` varchar(200) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `gallery_id` int(11) NOT NULL,
  `description_en` varchar(1000) DEFAULT NULL,
  `description_fr` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gal_gallery_id_5f743e845a8d8b01_fk_galleries_gallery_page_ptr_id` (`gallery_id`),
  CONSTRAINT `gal_gallery_id_5f743e845a8d8b01_fk_galleries_gallery_page_ptr_id` FOREIGN KEY (`gallery_id`) REFERENCES `galleries_gallery` (`page_ptr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `galleries_galleryimage`
--

LOCK TABLES `galleries_galleryimage` WRITE;
/*!40000 ALTER TABLE `galleries_galleryimage` DISABLE KEYS */;
/*!40000 ALTER TABLE `galleries_galleryimage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_assignedkeyword`
--

DROP TABLE IF EXISTS `generic_assignedkeyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generic_assignedkeyword` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `_order` int(11) DEFAULT NULL,
  `object_pk` int(11) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `keyword_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `gener_content_type_id_340baca94a5341cc_fk_django_content_type_id` (`content_type_id`),
  KEY `generic_assignedkeyword_5c003bba` (`keyword_id`),
  CONSTRAINT `gener_content_type_id_340baca94a5341cc_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `generic_assign_keyword_id_61d6fae39a09e150_fk_generic_keyword_id` FOREIGN KEY (`keyword_id`) REFERENCES `generic_keyword` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_assignedkeyword`
--

LOCK TABLES `generic_assignedkeyword` WRITE;
/*!40000 ALTER TABLE `generic_assignedkeyword` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_assignedkeyword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_keyword`
--

DROP TABLE IF EXISTS `generic_keyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generic_keyword` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `generic_keyword_site_id_7727e5473a304097_fk_django_site_id` (`site_id`),
  CONSTRAINT `generic_keyword_site_id_7727e5473a304097_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_keyword`
--

LOCK TABLES `generic_keyword` WRITE;
/*!40000 ALTER TABLE `generic_keyword` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_keyword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_rating`
--

DROP TABLE IF EXISTS `generic_rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generic_rating` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` int(11) NOT NULL,
  `rating_date` datetime DEFAULT NULL,
  `object_pk` int(11) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gener_content_type_id_28e2096071be2a4f_fk_django_content_type_id` (`content_type_id`),
  KEY `generic_rating_user_id_323dfdffa0c13bac_fk_auth_user_id` (`user_id`),
  CONSTRAINT `gener_content_type_id_28e2096071be2a4f_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `generic_rating_user_id_323dfdffa0c13bac_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_rating`
--

LOCK TABLES `generic_rating` WRITE;
/*!40000 ALTER TABLE `generic_rating` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_threadedcomment`
--

DROP TABLE IF EXISTS `generic_threadedcomment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generic_threadedcomment` (
  `comment_ptr_id` int(11) NOT NULL,
  `rating_count` int(11) NOT NULL,
  `rating_sum` int(11) NOT NULL,
  `rating_average` double NOT NULL,
  `by_author` tinyint(1) NOT NULL,
  `replied_to_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`comment_ptr_id`),
  KEY `D7947a861fd85b8f3a6688a645eb55f3` (`replied_to_id`),
  CONSTRAINT `D7947a861fd85b8f3a6688a645eb55f3` FOREIGN KEY (`replied_to_id`) REFERENCES `generic_threadedcomment` (`comment_ptr_id`),
  CONSTRAINT `generic_th_comment_ptr_id_7ce6b4612f86bbc6_fk_django_comments_id` FOREIGN KEY (`comment_ptr_id`) REFERENCES `django_comments` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_threadedcomment`
--

LOCK TABLES `generic_threadedcomment` WRITE;
/*!40000 ALTER TABLE `generic_threadedcomment` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_threadedcomment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mezzanine_agenda_event`
--

DROP TABLE IF EXISTS `mezzanine_agenda_event`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mezzanine_agenda_event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comments_count` int(11) NOT NULL,
  `keywords_string` varchar(500) NOT NULL,
  `rating_count` int(11) NOT NULL,
  `rating_sum` int(11) NOT NULL,
  `rating_average` double NOT NULL,
  `title` varchar(500) NOT NULL,
  `title_fr` varchar(500) DEFAULT NULL,
  `title_en` varchar(500) DEFAULT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `_meta_title` varchar(500) DEFAULT NULL,
  `description` longtext NOT NULL,
  `gen_description` tinyint(1) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `status` int(11) NOT NULL,
  `publish_date` datetime DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `short_url` varchar(200) DEFAULT NULL,
  `in_sitemap` tinyint(1) NOT NULL,
  `content` longtext NOT NULL,
  `start` datetime NOT NULL,
  `end` datetime DEFAULT NULL,
  `facebook_event` bigint(20) DEFAULT NULL,
  `allow_comments` tinyint(1) NOT NULL,
  `featured_image` varchar(255) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `content_en` longtext,
  `content_fr` longtext,
  PRIMARY KEY (`id`),
  KEY `mezzanine_agenda_event_76776489` (`publish_date`),
  KEY `mezzanine_agenda_event_e274a5da` (`location_id`),
  KEY `mezzanine_agenda_event_9365d6e7` (`site_id`),
  KEY `mezzanine_agenda_event_e8701ad4` (`user_id`),
  CONSTRAINT `fbd81322a86dfbaef531591c77043151` FOREIGN KEY (`location_id`) REFERENCES `mezzanine_agenda_eventlocation` (`id`),
  CONSTRAINT `mezzanine_agenda_even_site_id_169a7797bca29416_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`),
  CONSTRAINT `mezzanine_agenda_event_user_id_628aa93bcaeead1e_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mezzanine_agenda_event`
--

LOCK TABLES `mezzanine_agenda_event` WRITE;
/*!40000 ALTER TABLE `mezzanine_agenda_event` DISABLE KEYS */;
/*!40000 ALTER TABLE `mezzanine_agenda_event` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `mezzanine_agenda_eventlocation`
--

DROP TABLE IF EXISTS `mezzanine_agenda_eventlocation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mezzanine_agenda_eventlocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `address` longtext NOT NULL,
  `mappable_location` varchar(128) NOT NULL,
  `lat` decimal(10,7) DEFAULT NULL,
  `lon` decimal(10,7) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `mezzanine_agenda_even_site_id_79bb57d8c7cef4a5_fk_django_site_id` (`site_id`),
  CONSTRAINT `mezzanine_agenda_even_site_id_79bb57d8c7cef4a5_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mezzanine_agenda_eventlocation`
--

LOCK TABLES `mezzanine_agenda_eventlocation` WRITE;
/*!40000 ALTER TABLE `mezzanine_agenda_eventlocation` DISABLE KEYS */;
/*!40000 ALTER TABLE `mezzanine_agenda_eventlocation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages_link`
--

DROP TABLE IF EXISTS `pages_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages_link` (
  `page_ptr_id` int(11) NOT NULL,
  PRIMARY KEY (`page_ptr_id`),
  CONSTRAINT `pages_link_page_ptr_id_560afe0956838fd3_fk_pages_page_id` FOREIGN KEY (`page_ptr_id`) REFERENCES `pages_page` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_link`
--

LOCK TABLES `pages_link` WRITE;
/*!40000 ALTER TABLE `pages_link` DISABLE KEYS */;
INSERT INTO `pages_link` VALUES (1),(2),(3);
/*!40000 ALTER TABLE `pages_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages_page`
--

DROP TABLE IF EXISTS `pages_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keywords_string` varchar(500) NOT NULL,
  `title` varchar(500) NOT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `_meta_title` varchar(500) DEFAULT NULL,
  `description` longtext NOT NULL,
  `gen_description` tinyint(1) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `status` int(11) NOT NULL,
  `publish_date` datetime DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `short_url` varchar(200) DEFAULT NULL,
  `in_sitemap` tinyint(1) NOT NULL,
  `_order` int(11) DEFAULT NULL,
  `in_menus` varchar(100) DEFAULT NULL,
  `titles` varchar(1000) DEFAULT NULL,
  `content_model` varchar(50) DEFAULT NULL,
  `login_required` tinyint(1) NOT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  `_meta_title_en` varchar(500) DEFAULT NULL,
  `_meta_title_fr` varchar(500) DEFAULT NULL,
  `description_en` longtext,
  `description_fr` longtext,
  `title_en` varchar(500) DEFAULT NULL,
  `title_fr` varchar(500) DEFAULT NULL,
  `titles_en` varchar(1000) DEFAULT NULL,
  `titles_fr` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pages_page_6be37982` (`parent_id`),
  KEY `pages_page_9365d6e7` (`site_id`),
  KEY `pages_page_publish_date_4b581dded15f4cdf_uniq` (`publish_date`),
  CONSTRAINT `pages_page_parent_id_7bf3217d99139bb8_fk_pages_page_id` FOREIGN KEY (`parent_id`) REFERENCES `pages_page` (`id`),
  CONSTRAINT `pages_page_site_id_22239f4327580ae9_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_page`
--

LOCK TABLES `pages_page` WRITE;
/*!40000 ALTER TABLE `pages_page` DISABLE KEYS */;
INSERT INTO `pages_page` VALUES (1,'','Program','/events/',NULL,'Programme',1,'2016-02-25 12:52:02','2016-02-25 12:52:02',2,'2016-02-25 12:52:02',NULL,NULL,0,0,'1','Program','link',0,NULL,1,NULL,NULL,'Programme','Programme','Program','Programme','Program','Programme'),(2,'','Artists','/festival/artists/',NULL,'Artistes',1,'2016-02-25 12:52:49','2016-02-25 12:52:49',2,'2016-02-25 12:52:49',NULL,NULL,0,1,'1','Artists','link',0,NULL,1,NULL,NULL,'Artistes','Artistes','Artists','Artistes','Artists','Artistes'),(3,'','Videos','/festival/videos/',NULL,'Vidéos',1,'2016-02-25 13:06:47','2016-02-25 13:07:09',2,'2016-02-25 13:06:47',NULL,NULL,0,2,'1','Videos','link',0,NULL,1,NULL,NULL,'Vidéos','Vidéos','Videos','Vidéos','Videos','Vidéos'),(4,'','Infos/Réservations','infosreservations',NULL,'\nManiFeste Pass\nAt least 3 different performances per person. ORDER YOUR MANIFESTE PASS',1,'2016-02-25 14:42:59','2016-03-02 17:54:37',2,'2016-02-25 14:42:59',NULL,NULL,1,6,'1','Infos/Réservations','richtextpage',0,NULL,1,NULL,NULL,'\nManiFeste Pass\nAt least 3 different performances per person. ORDER YOUR MANIFESTE PASS','Pass ManiFeste\nBénéficiez du tarif privilégié abonné Pass ManiFeste avec l\'achat, en une fois, d\'au moins trois spectacles de votre choix.Accédez ensuite au tarif abonné pour tout spectacle supplémentaire.COMMANDER LE PASS MANIFESTE','','Infos/Réservations','Infos/Réservations','Infos/Réservations'),(5,'','Academy','academy',NULL,'Rendez-vous de la création à Paris, le festival et l\'académie pluridisciplinaire de l\'Ircam, ManiFeste replace la musique dans le concert des autres disciplines, spectacle vivant, théâtre, danse, arts numériques. Les arts du temps rencontrent les arts visuels et ceux de l\'espace. En 2016, ManiFeste se contrepointe pour la première fois à une grande exposition au Centre Pompidou consacrée à l\'Arte Povera. Qu\'est-ce que le « pauvre » aujourd\'hui dans l\'art et dans l\'innovation ? La conception d\'un matériau raréfié, d\'une lutherie inouïe, la présence d\'une nature ré-enchantée dans l\'œuvre, se retrouvent au cœur d\'aventures artistiques singulières, comme celle de Salvatore Sciarrino en Europe ou encore de Harry Partch aux États-Unis.',1,'2016-02-25 14:44:42','2016-03-03 11:57:35',2,'2016-02-25 14:44:42',NULL,NULL,1,5,'1','Academy','richtextpage',0,NULL,1,NULL,NULL,'Rendez-vous de la création à Paris, le festival et l\'académie pluridisciplinaire de l\'Ircam, ManiFeste replace la musique dans le concert des autres disciplines, spectacle vivant, théâtre, danse, arts numériques. Les arts du temps rencontrent les arts visuels et ceux de l\'espace. En 2016, ManiFeste se contrepointe pour la première fois à une grande exposition au Centre Pompidou consacrée à l\'Arte Povera. Qu\'est-ce que le « pauvre » aujourd\'hui dans l\'art et dans l\'innovation ? La conception d\'un matériau raréfié, d\'une lutherie inouïe, la présence d\'une nature ré-enchantée dans l\'œuvre, se retrouvent au cœur d\'aventures artistiques singulières, comme celle de Salvatore Sciarrino en Europe ou encore de Harry Partch aux États-Unis.','Rendez-vous de la création à Paris, le festival et l\'académie pluridisciplinaire de l\'Ircam, ManiFeste replace la musique dans le concert des autres disciplines, spectacle vivant, théâtre, danse, arts numériques. Les arts du temps rencontrent les arts visuels et ceux de l\'espace. En 2016, ManiFeste se contrepointe pour la première fois à une grande exposition au Centre Pompidou consacrée à l\'Arte Povera. Qu\'est-ce que le « pauvre » aujourd\'hui dans l\'art et dans l\'innovation ? La conception d\'un matériau raréfié, d\'une lutherie inouïe, la présence d\'une nature ré-enchantée dans l\'œuvre, se retrouvent au cœur d\'aventures artistiques singulières, comme celle de Salvatore Sciarrino en Europe ou encore de Harry Partch aux États-Unis.','Academy','Académie','Academy','Académie'),(6,'','Exhibitions','expositions',NULL,'Expositions',1,'2016-02-29 10:23:31','2016-02-29 10:23:52',2,'2016-02-29 10:23:31',NULL,NULL,1,4,'1','Exhibitions','richtextpage',0,NULL,1,NULL,NULL,'Expositions','Expositions','Exhibitions','Expositions','Exhibitions','Expositions'),(7,'','Sciences','sciences',NULL,'Sciences',1,'2016-02-29 10:23:44','2016-02-29 10:23:44',2,'2016-02-29 10:23:44',NULL,NULL,1,3,'1','Sciences','richtextpage',0,NULL,1,NULL,NULL,'Sciences','Sciences','','Sciences','Sciences','Sciences'),(8,'','Partners','partners',NULL,'Partenaires',1,'2016-02-29 15:00:35','2016-03-02 17:59:26',2,'2016-02-29 15:00:35',NULL,NULL,1,8,'','Partners','richtextpage',0,NULL,1,NULL,NULL,'Partenaires','Partenaires','Partners','Partenaires','Partners','Partenaires'),(9,'','Espace presse','espace-presse',NULL,'Espace presse',1,'2016-03-02 18:01:46','2016-03-02 18:01:46',2,'2016-03-02 16:34:27',NULL,NULL,1,9,'','Espace presse','richtextpage',0,NULL,1,NULL,NULL,'Espace presse','Espace presse','','Espace presse','Espace presse','Espace presse'),(10,'','Soutenir l\'Ircam','soutenir-lircam',NULL,'Soutenir l\'Ircam',1,'2016-03-02 18:02:05','2016-03-02 18:02:05',2,'2016-03-02 16:34:48',NULL,NULL,1,10,'','Soutenir l\'Ircam','richtextpage',0,NULL,1,NULL,NULL,'Soutenir l\'Ircam','Soutenir l\'Ircam','','Soutenir l\'Ircam','Soutenir l\'Ircam','Soutenir l\'Ircam'),(11,'','Contacts / Équipes','contacts-équipes',NULL,'Contacts / Équipes',1,'2016-03-02 18:02:23','2016-03-02 18:02:23',2,'2016-03-02 16:35:06',NULL,NULL,1,11,'','Contacts / Équipes','richtextpage',0,NULL,1,NULL,NULL,'Contacts / Équipes','Contacts / Équipes','','Contacts / Équipes','Contacts / Équipes','Contacts / Équipes'),(12,'','Lieux','lieux',NULL,'Lieux',1,'2016-03-02 18:03:04','2016-03-02 18:03:04',2,'2016-03-02 16:35:49',NULL,NULL,1,7,'1','Lieux','richtextpage',0,NULL,1,NULL,NULL,'Lieux','Lieux','','Lieux','Lieux','Lieux');
/*!40000 ALTER TABLE `pages_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages_richtextpage`
--

DROP TABLE IF EXISTS `pages_richtextpage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages_richtextpage` (
  `page_ptr_id` int(11) NOT NULL,
  `content` longtext NOT NULL,
  `content_en` longtext,
  `content_fr` longtext,
  PRIMARY KEY (`page_ptr_id`),
  CONSTRAINT `pages_richtextpage_page_ptr_id_303aa0962fe9608b_fk_pages_page_id` FOREIGN KEY (`page_ptr_id`) REFERENCES `pages_page` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_richtextpage`
--

LOCK TABLES `pages_richtextpage` WRITE;
/*!40000 ALTER TABLE `pages_richtextpage` DISABLE KEYS */;
INSERT INTO `pages_richtextpage` VALUES (4,'<div class=\"entry-content\">\n<h2 class=\"entry-title contenttit\">ManiFeste Pass</h2>\n<p>At least 3 different performances per person.<br> <a href=\"http://eve.ircam.fr/manifeste.php/\" target=\"_blank\"><strong>ORDER YOUR MANIFESTE PASS</strong></a></p>\n<p> </p>\n<h2 class=\"entry-title contenttit\">Young People Pass</h2>\n<p>For those under 26 years old. At least 2 performances per person.<br> <a href=\"http://eve.ircam.fr/manifeste.php/\" target=\"_blank\"><strong>ORDER YOUR YOUNG PEOPLE PASS</strong></a></p>\n<p> </p>\n<h2 class=\"entry-title contenttit\">New: Discovery Pack*</h2>\n<p>Discover the festival with 3 emblematic performances for the exceptional price of just 10€ per performance and per person: <a href=\"http://manifeste2015.ircam.fr/events/event/requiem-pour-un-jeune-poete-2/index.html?lang=en&amp;lang=en\" title=\"Requiem pour un jeune poète\">Requiem pour un jeune poète</a>, <a href=\"http://manifeste2015.ircam.fr/events/event/fado-erratico-2/index.html?lang=en&amp;lang=en\" title=\"Fado errático\">Fado errático</a>, and <a href=\"http://manifeste2015.ircam.fr/events/event/il-se-trouve-que-les-oreilles-nont-pas-de-paupieres-2/index.html?lang=en&amp;lang=en\" title=\"Il se trouve que les oreilles n’ont pas de paupières\">Il se trouve que les oreilles n’ont pas de paupières</a>.<br> <strong><a href=\"http://eve.ircam.fr/manifeste.php/\" target=\"_blank\">ORDER YOUR DISCOVERY PACK </a></strong></p>\n<p>*Tickets must be purchased before June 1, 2015</p>\n<p> </p>\n<h2 class=\"entry-title contenttit\">Box Office</h2>\n<p><strong>By Téléphone</strong><br> <strong>01 44 78 12 40</strong></p>\n<p><strong>By Internet</strong><br> Click on <strong>RESERVATION</strong> at the bottom of each performance description on this website to purchase tickets online or by mail at <a href=\"mailto:billetterie@ircam.fr\">billetterie@ircam.fr</a>. All reservations must be confirmed by an immediate payment by credit card or by cheque within 48 hours.</p>\n<p><strong>By Correspondance</strong><br> Return the completed <a href=\"http://manifeste2015.ircam.fr/wp-content/uploads/2015/04/bulletin_reservation_2015.pdf\" target=\"_blank\">bulletin-reservation</a> (pdf) with payment to:<br> Ircam – Billetterie, 1 place Igor-Stravinsky – 75004 Paris</p>\n<p><strong>At IRCAM</strong><br> Monday through Friday, 11am-7pm. Saturdays, May 30, June 6 &amp; 13, 3pm-7pm.</p>\n<p>Tickets are non-exchangeable and non-refundable. All tickets will be sent by post until two weeks before the date of the first performance selected. Beyond this date, tickets must be picked up at the venue’s box office 30 minutes before each performance.</p>\n<p> </p>\n<h2 class=\"entry-title contenttit\">Ticket Prices</h2>\n<p>Ticket prices (full price, discount price, ManiFeste &amp; Student Pass, Discovery Pack) are indicated on each performances description on this Website. To see what discount you are eligible for, please read the terms in the <a href=\"http://manifeste2015.ircam.fr/wp-content/uploads/2015/04/bulletin_reservation_2015.pdf\" target=\"_blank\">bulletin-reservation</a> (pdf) for further information.</p>\n</div>','<div class=\"entry-content\">\n<h2 class=\"entry-title contenttit\">ManiFeste Pass</h2>\n<p>At least 3 different performances per person.<br> <a href=\"http://eve.ircam.fr/manifeste.php/\" target=\"_blank\"><strong>ORDER YOUR MANIFESTE PASS</strong></a></p>\n<p> </p>\n<h2 class=\"entry-title contenttit\">Young People Pass</h2>\n<p>For those under 26 years old. At least 2 performances per person.<br> <a href=\"http://eve.ircam.fr/manifeste.php/\" target=\"_blank\"><strong>ORDER YOUR YOUNG PEOPLE PASS</strong></a></p>\n<p> </p>\n<h2 class=\"entry-title contenttit\">New: Discovery Pack*</h2>\n<p>Discover the festival with 3 emblematic performances for the exceptional price of just 10€ per performance and per person: <a href=\"http://manifeste2015.ircam.fr/events/event/requiem-pour-un-jeune-poete-2/index.html?lang=en&amp;lang=en\" title=\"Requiem pour un jeune poète\">Requiem pour un jeune poète</a>, <a href=\"http://manifeste2015.ircam.fr/events/event/fado-erratico-2/index.html?lang=en&amp;lang=en\" title=\"Fado errático\">Fado errático</a>, and <a href=\"http://manifeste2015.ircam.fr/events/event/il-se-trouve-que-les-oreilles-nont-pas-de-paupieres-2/index.html?lang=en&amp;lang=en\" title=\"Il se trouve que les oreilles n’ont pas de paupières\">Il se trouve que les oreilles n’ont pas de paupières</a>.<br> <strong><a href=\"http://eve.ircam.fr/manifeste.php/\" target=\"_blank\">ORDER YOUR DISCOVERY PACK </a></strong></p>\n<p>*Tickets must be purchased before June 1, 2015</p>\n<p> </p>\n<h2 class=\"entry-title contenttit\">Box Office</h2>\n<p><strong>By Téléphone</strong><br> <strong>01 44 78 12 40</strong></p>\n<p><strong>By Internet</strong><br> Click on <strong>RESERVATION</strong> at the bottom of each performance description on this website to purchase tickets online or by mail at <a href=\"mailto:billetterie@ircam.fr\">billetterie@ircam.fr</a>. All reservations must be confirmed by an immediate payment by credit card or by cheque within 48 hours.</p>\n<p><strong>By Correspondance</strong><br> Return the completed <a href=\"http://manifeste2015.ircam.fr/wp-content/uploads/2015/04/bulletin_reservation_2015.pdf\" target=\"_blank\">bulletin-reservation</a> (pdf) with payment to:<br> Ircam – Billetterie, 1 place Igor-Stravinsky – 75004 Paris</p>\n<p><strong>At IRCAM</strong><br> Monday through Friday, 11am-7pm. Saturdays, May 30, June 6 &amp; 13, 3pm-7pm.</p>\n<p>Tickets are non-exchangeable and non-refundable. All tickets will be sent by post until two weeks before the date of the first performance selected. Beyond this date, tickets must be picked up at the venue’s box office 30 minutes before each performance.</p>\n<p> </p>\n<h2 class=\"entry-title contenttit\">Ticket Prices</h2>\n<p>Ticket prices (full price, discount price, ManiFeste &amp; Student Pass, Discovery Pack) are indicated on each performances description on this Website. To see what discount you are eligible for, please read the terms in the <a href=\"http://manifeste2015.ircam.fr/wp-content/uploads/2015/04/bulletin_reservation_2015.pdf\" target=\"_blank\">bulletin-reservation</a> (pdf) for further information.</p>\n</div>','<h4>Pass ManiFeste</h4>\n<p>Bénéficiez du tarif privilégié abonné Pass ManiFeste avec l\'achat, en une fois, d\'<strong>au moins trois spectacles de votre choix</strong>.<br>Accédez ensuite au tarif abonné pour tout spectacle supplémentaire.<br>COMMANDER LE PASS MANIFESTE</p>\n<h4>Pass Jeunes</h4>\n<p>Pour les jeunes de moins de 26 ans.</p>\n<p>Bénéficiez du tarif privilégié abonné Pass Jeunes avec l\'achat, en une fois, d\'<strong>au moins deux spectacles de votre choix</strong>.<br>Accédez ensuite au tarif abonné Jeunes pour tout spectacle supplémentaire.<br>COMMANDER LE PASS JEUNES</p>\n<h4>Billetterie</h4>\n<p><strong>Par téléphone</strong><br>01 44 78 12 40</p>\n<p><strong>En ligne</strong> <br>Sur ce site : directement au sein des fiches spectacles en cliquant sur le bouton Réserver ou par mail à <a href=\"mailto:billetterie@ircam.fr\">billetterie@ircam.fr</a>. <br>Toute réservation doit être suivie du réglement immédiat par carte bancaire ou de l\'envoi d\'un chèque dans les 48h.</p>\n<p><strong>Par courrier</strong><br>Envoyez votre bulletin de réservation (pdf) accompagné du réglement (CB ou chèque à l\'ordre de l\'Ircam) et de la photocopie des pièces justificatives pour les tarifs réduits à :<br>Ircam - Billetterie<br>1, place Igor-Stravinsky - 75004 Paris</p>\n<p><strong>Sur place</strong><br>Du lundi au vendredi de 11h à 19h et les samedis 28 mai, 4 et 11 juin de 15h à 19h.</p>\n<p><strong>À l\'entrée de chaque concert ou spectacle</strong><br>45 minutes avant le concert dans la limite des places disponibles.</p>\n<div class=\"entry-content\">\n<p>Les billets ne sont ni échangeables ni remboursables. Ils sont envoyés par courrier jusqu’à deux semaines avant la date de votre premier spectacle. Au-delà, les billets sont à retirer auprès de la billetterie de la salle de spectacle, 30 minutes avant le début de chaque représentation.</p>\n<h4 class=\"entry-title contenttit\">Tarifs</h4>\n<p>Les tarifs (plein, réduit, Pass ManiFeste et Pass Jeunes et Offre découverte) sont signalés sur ce site directement au sein du descriptif de chaque événement. Détails des conditions (réduit, groupes et scolaires, étudiants) au sein du <a href=\"http://manifeste2015.ircam.fr/wp-content/uploads/2015/04/bulletin_reservation_2015.pdf\" target=\"_blank\">bulletin-réservation</a> (pdf).</p>\n</div>'),(5,'<p class=\"bodytext\">Rendez-vous de la création à Paris, le festival et l\'académie pluridisciplinaire de l\'Ircam, ManiFeste replace la musique dans le concert des autres disciplines, spectacle vivant, théâtre, danse, arts numériques. Les arts du temps rencontrent les arts visuels et ceux de l\'espace. En 2016, ManiFeste se contrepointe pour la première fois à une grande exposition au Centre Pompidou consacrée à l\'Arte Povera. Qu\'est-ce que le « pauvre » aujourd\'hui dans l\'art et dans l\'innovation ? La conception d\'un matériau raréfié, d\'une lutherie inouïe, la présence d\'une nature ré-enchantée dans l\'œuvre, se retrouvent au cœur d\'aventures artistiques singulières, comme celle de Salvatore Sciarrino en Europe ou encore de Harry Partch aux États-Unis.</p>\n<p class=\"bodytext\">ManiFeste réunit Beat Furrer, Philippe Leroux, Rebecca Saunders, Mauro Lanza et le circassien Jérôme Thomas, et le percussionniste Steven Schick. L\'Ensemble intercontemporain (ensemble associé de l\'académie) et l\'Orchestre philharmonique de Radio France offrent la possibilité aux jeunes compositeurs d\'expérimenter une esquisse en formation de chambre, d\'ensemble ou d\'orchestre. L\'électronique est au centre d\'un Atelier In Vivo inédit, élaboré par des artistes du cirque qui en feront la scénographie dans un échange étroit avec les compositeurs. Enfin la dimension collective est renforcée du côté des jeunes interprètes dans l\'atelier de percussion de Steven Schick.</p>\n<p class=\"bodytext\">Outre les stagiaires actifs, l\'académie offre la possibilité à des musiciens, compositeurs, artistes, enseignants… d’assister en libre accès à toutes les activités de l’académie (répétitions des ateliers, master classes, cours d’informatique musicale, cours de composition, orchestration, analyse d’œuvre, conférences), dans la mesure des places disponibles. <strong>Les personnes intéressées sont invitées à postuler en ligne sur</strong> <a href=\"http://www.ulysses-network.eu/web/competitions/manifeste2016-auditors/\">la plateforme Ulysses</a> <strong>pour présenter leur candidature jusqu\'au 19 mai 2016</strong>. Les frais d\'inscription s\'élevent à 200€ et ouvrent également droit à :</p>\n<ul>\n<li>d\'un accès privilégié au fond documentaire de la médiathèque de l\'Ircam ;</li>\n<li>d\'un accès gratuit à toutes les sorties d\'ateliers et master classes de l\'académie ;</li>\n<li>de tarifs privilégiés pour les concerts du festival ManiFeste-2016 ;</li>\n<li>une réduction de 50% à l\'<a href=\"http://forumnet.ircam.fr/shop/fr/forumnet/42-abonnement-vip-1-an.html\">abonnement Premium individuel</a> du Forum Ircam.</li>\n</ul>\n<p><strong>Découvrez <a href=\"http://www.ulysses-network.eu/web/home/l\">ULYSSES COMMUNITY</a>, la plate-forme conçue pour les jeunes artistes et les structures culturelles de la musique contemporaine.</strong></p>\n<p>Quatre partenaires principaux participent à la mise en œuvre de l\'académie : l\'Ensemble intercontemporain, ensemble associé permanent, le CENTQUATRE-Paris, l\'Orchestre Philharmonique de Radio France et Les Spectacles vivants-Centre Pompidou. Cette cinquième édition s\'appuie par ailleurs sur le concours d\'acteurs importants du domaine de la culture et de la formation supérieure : le Council on International Education Exchange (universités américaines), le Center for Research in Electro-Acoustic Music and Audio (Corée).</p>','','<p class=\"bodytext\">Rendez-vous de la création à Paris, le festival et l\'académie pluridisciplinaire de l\'Ircam, ManiFeste replace la musique dans le concert des autres disciplines, spectacle vivant, théâtre, danse, arts numériques. Les arts du temps rencontrent les arts visuels et ceux de l\'espace. En 2016, ManiFeste se contrepointe pour la première fois à une grande exposition au Centre Pompidou consacrée à l\'Arte Povera. Qu\'est-ce que le « pauvre » aujourd\'hui dans l\'art et dans l\'innovation ? La conception d\'un matériau raréfié, d\'une lutherie inouïe, la présence d\'une nature ré-enchantée dans l\'œuvre, se retrouvent au cœur d\'aventures artistiques singulières, comme celle de Salvatore Sciarrino en Europe ou encore de Harry Partch aux États-Unis.</p>\n<p class=\"bodytext\">ManiFeste réunit Beat Furrer, Philippe Leroux, Rebecca Saunders, Mauro Lanza et le circassien Jérôme Thomas, et le percussionniste Steven Schick. L\'Ensemble intercontemporain (ensemble associé de l\'académie) et l\'Orchestre philharmonique de Radio France offrent la possibilité aux jeunes compositeurs d\'expérimenter une esquisse en formation de chambre, d\'ensemble ou d\'orchestre. L\'électronique est au centre d\'un Atelier In Vivo inédit, élaboré par des artistes du cirque qui en feront la scénographie dans un échange étroit avec les compositeurs. Enfin la dimension collective est renforcée du côté des jeunes interprètes dans l\'atelier de percussion de Steven Schick.</p>\n<p class=\"bodytext\">Outre les stagiaires actifs, l\'académie offre la possibilité à des musiciens, compositeurs, artistes, enseignants… d’assister en libre accès à toutes les activités de l’académie (répétitions des ateliers, master classes, cours d’informatique musicale, cours de composition, orchestration, analyse d’œuvre, conférences), dans la mesure des places disponibles. <strong>Les personnes intéressées sont invitées à postuler en ligne sur</strong> <a href=\"http://www.ulysses-network.eu/web/competitions/manifeste2016-auditors/\">la plateforme Ulysses</a> <strong>pour présenter leur candidature jusqu\'au 19 mai 2016</strong>. Les frais d\'inscription s\'élevent à 200€ et ouvrent également droit à :</p>\n<ul>\n<li>d\'un accès privilégié au fond documentaire de la médiathèque de l\'Ircam ;</li>\n<li>d\'un accès gratuit à toutes les sorties d\'ateliers et master classes de l\'académie ;</li>\n<li>de tarifs privilégiés pour les concerts du festival ManiFeste-2016 ;</li>\n<li>une réduction de 50% à l\'<a href=\"http://forumnet.ircam.fr/shop/fr/forumnet/42-abonnement-vip-1-an.html\">abonnement Premium individuel</a> du Forum Ircam.</li>\n</ul>\n<p><strong>Découvrez <a href=\"http://www.ulysses-network.eu/web/home/l\">ULYSSES COMMUNITY</a>, la plate-forme conçue pour les jeunes artistes et les structures culturelles de la musique contemporaine.</strong></p>\n<p>Quatre partenaires principaux participent à la mise en œuvre de l\'académie : l\'Ensemble intercontemporain, ensemble associé permanent, le CENTQUATRE-Paris, l\'Orchestre Philharmonique de Radio France et Les Spectacles vivants-Centre Pompidou. Cette cinquième édition s\'appuie par ailleurs sur le concours d\'acteurs importants du domaine de la culture et de la formation supérieure : le Council on International Education Exchange (universités américaines), le Center for Research in Electro-Acoustic Music and Audio (Corée).</p>'),(6,'','',''),(7,'','',''),(8,'','',''),(9,'','',''),(10,'','',''),(11,'','',''),(12,'','','');
/*!40000 ALTER TABLE `pages_richtextpage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `twitter_query`
--

DROP TABLE IF EXISTS `twitter_query`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `twitter_query` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(10) NOT NULL,
  `value` varchar(140) NOT NULL,
  `interested` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `twitter_query`
--

LOCK TABLES `twitter_query` WRITE;
/*!40000 ALTER TABLE `twitter_query` DISABLE KEYS */;
INSERT INTO `twitter_query` VALUES (1,'search','from:stephen_mcd mezzanine',1);
/*!40000 ALTER TABLE `twitter_query` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `twitter_tweet`
--

DROP TABLE IF EXISTS `twitter_tweet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `twitter_tweet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `remote_id` varchar(50) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `text` longtext,
  `profile_image_url` varchar(200) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `retweeter_profile_image_url` varchar(200) DEFAULT NULL,
  `retweeter_user_name` varchar(100) DEFAULT NULL,
  `retweeter_full_name` varchar(100) DEFAULT NULL,
  `query_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `twitter_tweet_query_id_5de4bfd6dfe46065_fk_twitter_query_id` (`query_id`),
  CONSTRAINT `twitter_tweet_query_id_5de4bfd6dfe46065_fk_twitter_query_id` FOREIGN KEY (`query_id`) REFERENCES `twitter_query` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `twitter_tweet`
--

LOCK TABLES `twitter_tweet` WRITE;
/*!40000 ALTER TABLE `twitter_tweet` DISABLE KEYS */;
/*!40000 ALTER TABLE `twitter_tweet` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-03-03 13:10:23
