-- MySQL dump 10.16  Distrib 10.1.10-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db    Database: manifeste
-- ------------------------------------------------------
-- Server version	10.1.10-MariaDB-1~jessie

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(80) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_group_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `group_id` (`group_id`,`permission_id`),
  KEY `auth_group__permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id` (`permission_id`),
  CONSTRAINT `auth_group__permission_id_1f49ccbbdc69d2fc_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_group_permission_group_id_689710a9a73b7457_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `content_type_id` (`content_type_id`,`codename`),
  CONSTRAINT `auth__content_type_id_508cf46651277a81_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=680 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add permission',1,'add_permission'),(2,'Can change permission',1,'change_permission'),(3,'Can delete permission',1,'delete_permission'),(4,'Can add group',2,'add_group'),(5,'Can change group',2,'change_group'),(6,'Can delete group',2,'delete_group'),(7,'Can add user',3,'add_user'),(8,'Can change user',3,'change_user'),(9,'Can delete user',3,'delete_user'),(10,'Can add content type',4,'add_contenttype'),(11,'Can change content type',4,'change_contenttype'),(12,'Can delete content type',4,'delete_contenttype'),(13,'Can add redirect',5,'add_redirect'),(14,'Can change redirect',5,'change_redirect'),(15,'Can delete redirect',5,'delete_redirect'),(16,'Can add session',6,'add_session'),(17,'Can change session',6,'change_session'),(18,'Can delete session',6,'delete_session'),(19,'Can add site',7,'add_site'),(20,'Can change site',7,'change_site'),(21,'Can delete site',7,'delete_site'),(22,'Can add Setting',8,'add_setting'),(23,'Can change Setting',8,'change_setting'),(24,'Can delete Setting',8,'delete_setting'),(25,'Can add Site permission',9,'add_sitepermission'),(26,'Can change Site permission',9,'change_sitepermission'),(27,'Can delete Site permission',9,'delete_sitepermission'),(28,'Can add Comment',10,'add_threadedcomment'),(29,'Can change Comment',10,'change_threadedcomment'),(30,'Can delete Comment',10,'delete_threadedcomment'),(31,'Can add Keyword',11,'add_keyword'),(32,'Can change Keyword',11,'change_keyword'),(33,'Can delete Keyword',11,'delete_keyword'),(34,'Can add assigned keyword',12,'add_assignedkeyword'),(35,'Can change assigned keyword',12,'change_assignedkeyword'),(36,'Can delete assigned keyword',12,'delete_assignedkeyword'),(37,'Can add Rating',13,'add_rating'),(38,'Can change Rating',13,'change_rating'),(39,'Can delete Rating',13,'delete_rating'),(40,'Can add Page',14,'add_page'),(41,'Can change Page',14,'change_page'),(42,'Can delete Page',14,'delete_page'),(43,'Can add Rich text page',15,'add_richtextpage'),(44,'Can change Rich text page',15,'change_richtextpage'),(45,'Can delete Rich text page',15,'delete_richtextpage'),(46,'Can add Link',16,'add_link'),(47,'Can change Link',16,'change_link'),(48,'Can delete Link',16,'delete_link'),(49,'Can add Blog post',17,'add_blogpost'),(50,'Can change Blog post',17,'change_blogpost'),(51,'Can delete Blog post',17,'delete_blogpost'),(52,'Can add Blog Category',18,'add_blogcategory'),(53,'Can change Blog Category',18,'change_blogcategory'),(54,'Can delete Blog Category',18,'delete_blogcategory'),(55,'Can add Form',19,'add_form'),(56,'Can change Form',19,'change_form'),(57,'Can delete Form',19,'delete_form'),(58,'Can add Field',20,'add_field'),(59,'Can change Field',20,'change_field'),(60,'Can delete Field',20,'delete_field'),(61,'Can add Form entry',21,'add_formentry'),(62,'Can change Form entry',21,'change_formentry'),(63,'Can delete Form entry',21,'delete_formentry'),(64,'Can add Form field entry',22,'add_fieldentry'),(65,'Can change Form field entry',22,'change_fieldentry'),(66,'Can delete Form field entry',22,'delete_fieldentry'),(67,'Can add Gallery',23,'add_gallery'),(68,'Can change Gallery',23,'change_gallery'),(69,'Can delete Gallery',23,'delete_gallery'),(70,'Can add Image',24,'add_galleryimage'),(71,'Can change Image',24,'change_galleryimage'),(72,'Can delete Image',24,'delete_galleryimage'),(73,'Can add Twitter query',25,'add_query'),(74,'Can change Twitter query',25,'change_query'),(75,'Can delete Twitter query',25,'delete_query'),(76,'Can add Tweet',26,'add_tweet'),(77,'Can change Tweet',26,'change_tweet'),(78,'Can delete Tweet',26,'delete_tweet'),(79,'Can add accounting',27,'add_accounting'),(80,'Can change accounting',27,'change_accounting'),(81,'Can delete accounting',27,'delete_accounting'),(82,'Can add accounting version',28,'add_accountingversion'),(83,'Can change accounting version',28,'change_accountingversion'),(84,'Can delete accounting version',28,'delete_accountingversion'),(85,'Can add addressable',29,'add_addressable'),(86,'Can change addressable',29,'change_addressable'),(87,'Can delete addressable',29,'delete_addressable'),(88,'Can add addressable index',30,'add_addressableindex'),(89,'Can change addressable index',30,'change_addressableindex'),(90,'Can delete addressable index',30,'delete_addressableindex'),(91,'Can add addressable version',31,'add_addressableversion'),(92,'Can change addressable version',31,'change_addressableversion'),(93,'Can delete addressable version',31,'delete_addressableversion'),(94,'Can add attachment',32,'add_attachment'),(95,'Can change attachment',32,'change_attachment'),(96,'Can delete attachment',32,'delete_attachment'),(97,'Can add attachment version',33,'add_attachmentversion'),(98,'Can change attachment version',33,'change_attachmentversion'),(99,'Can delete attachment version',33,'delete_attachmentversion'),(100,'Can add authentication',34,'add_authentication'),(101,'Can change authentication',34,'change_authentication'),(102,'Can delete authentication',34,'delete_authentication'),(103,'Can add auto group',35,'add_autogroup'),(104,'Can change auto group',35,'change_autogroup'),(105,'Can delete auto group',35,'delete_autogroup'),(106,'Can add bank payment',36,'add_bankpayment'),(107,'Can change bank payment',36,'change_bankpayment'),(108,'Can delete bank payment',36,'delete_bankpayment'),(109,'Can add bought product',37,'add_boughtproduct'),(110,'Can change bought product',37,'change_boughtproduct'),(111,'Can delete bought product',37,'delete_boughtproduct'),(112,'Can add bought product version',38,'add_boughtproductversion'),(113,'Can change bought product version',38,'change_boughtproductversion'),(114,'Can delete bought product version',38,'delete_boughtproductversion'),(115,'Can add cancellation',39,'add_cancellation'),(116,'Can change cancellation',39,'change_cancellation'),(117,'Can delete cancellation',39,'delete_cancellation'),(118,'Can add cancellation version',40,'add_cancellationversion'),(119,'Can change cancellation version',40,'change_cancellationversion'),(120,'Can delete cancellation version',40,'delete_cancellationversion'),(121,'Can add checkpoint',41,'add_checkpoint'),(122,'Can change checkpoint',41,'change_checkpoint'),(123,'Can delete checkpoint',41,'delete_checkpoint'),(124,'Can add color',42,'add_color'),(125,'Can change color',42,'change_color'),(126,'Can delete color',42,'delete_color'),(127,'Can add contact',43,'add_contact'),(128,'Can change contact',43,'change_contact'),(129,'Can delete contact',43,'delete_contact'),(130,'Can add contact archive',44,'add_contactarchive'),(131,'Can change contact archive',44,'change_contactarchive'),(132,'Can delete contact archive',44,'delete_contactarchive'),(133,'Can add contact entry',45,'add_contactentry'),(134,'Can change contact entry',45,'change_contactentry'),(135,'Can delete contact entry',45,'delete_contactentry'),(136,'Can add contact event archives',46,'add_contacteventarchives'),(137,'Can change contact event archives',46,'change_contacteventarchives'),(138,'Can delete contact event archives',46,'delete_contacteventarchives'),(139,'Can add contact index',47,'add_contactindex'),(140,'Can change contact index',47,'change_contactindex'),(141,'Can delete contact index',47,'delete_contactindex'),(142,'Can add contact phonenumber',48,'add_contactphonenumber'),(143,'Can change contact phonenumber',48,'change_contactphonenumber'),(144,'Can delete contact phonenumber',48,'delete_contactphonenumber'),(145,'Can add contact relationship',49,'add_contactrelationship'),(146,'Can change contact relationship',49,'change_contactrelationship'),(147,'Can delete contact relationship',49,'delete_contactrelationship'),(148,'Can add contact relationship type',50,'add_contactrelationshiptype'),(149,'Can change contact relationship type',50,'change_contactrelationshiptype'),(150,'Can delete contact relationship type',50,'delete_contactrelationshiptype'),(151,'Can add contact version',51,'add_contactversion'),(152,'Can change contact version',51,'change_contactversion'),(153,'Can delete contact version',51,'delete_contactversion'),(154,'Can add control',52,'add_control'),(155,'Can change control',52,'change_control'),(156,'Can delete control',52,'delete_control'),(157,'Can add control version',53,'add_controlversion'),(158,'Can change control version',53,'change_controlversion'),(159,'Can delete control version',53,'delete_controlversion'),(160,'Can add email',54,'add_email'),(161,'Can change email',54,'change_email'),(162,'Can delete email',54,'delete_email'),(163,'Can add email action',55,'add_emailaction'),(164,'Can change email action',55,'change_emailaction'),(165,'Can delete email action',55,'delete_emailaction'),(166,'Can add email contact',56,'add_emailcontact'),(167,'Can change email contact',56,'change_emailcontact'),(168,'Can delete email contact',56,'delete_emailcontact'),(169,'Can add email external link',57,'add_emailexternallink'),(170,'Can change email external link',57,'change_emailexternallink'),(171,'Can delete email external link',57,'delete_emailexternallink'),(172,'Can add email index',58,'add_emailindex'),(173,'Can change email index',58,'change_emailindex'),(174,'Can delete email index',58,'delete_emailindex'),(175,'Can add email link',59,'add_emaillink'),(176,'Can change email link',59,'change_emaillink'),(177,'Can delete email link',59,'delete_emaillink'),(178,'Can add email organism',60,'add_emailorganism'),(179,'Can change email organism',60,'change_emailorganism'),(180,'Can delete email organism',60,'delete_emailorganism'),(181,'Can add email professional',61,'add_emailprofessional'),(182,'Can change email professional',61,'change_emailprofessional'),(183,'Can delete email professional',61,'delete_emailprofessional'),(184,'Can add email spool',62,'add_emailspool'),(185,'Can change email spool',62,'change_emailspool'),(186,'Can delete email spool',62,'delete_emailspool'),(187,'Can add email template',63,'add_emailtemplate'),(188,'Can change email template',63,'change_emailtemplate'),(189,'Can delete email template',63,'delete_emailtemplate'),(190,'Can add entry',64,'add_entry'),(191,'Can change entry',64,'change_entry'),(192,'Can delete entry',64,'delete_entry'),(193,'Can add entry element',65,'add_entryelement'),(194,'Can change entry element',65,'change_entryelement'),(195,'Can delete entry element',65,'delete_entryelement'),(196,'Can add entry tickets',66,'add_entrytickets'),(197,'Can change entry tickets',66,'change_entrytickets'),(198,'Can delete entry tickets',66,'delete_entrytickets'),(199,'Can add event',67,'add_event'),(200,'Can change event',67,'change_event'),(201,'Can delete event',67,'delete_event'),(202,'Can add event category',68,'add_eventcategory'),(203,'Can change event category',68,'change_eventcategory'),(204,'Can delete event category',68,'delete_eventcategory'),(205,'Can add event company',69,'add_eventcompany'),(206,'Can change event company',69,'change_eventcompany'),(207,'Can delete event company',69,'delete_eventcompany'),(208,'Can add event index',70,'add_eventindex'),(209,'Can change event index',70,'change_eventindex'),(210,'Can delete event index',70,'delete_eventindex'),(211,'Can add event translation',71,'add_eventtranslation'),(212,'Can change event translation',71,'change_eventtranslation'),(213,'Can delete event translation',71,'delete_eventtranslation'),(214,'Can add event version',72,'add_eventversion'),(215,'Can change event version',72,'change_eventversion'),(216,'Can delete event version',72,'delete_eventversion'),(217,'Can add failed control',73,'add_failedcontrol'),(218,'Can change failed control',73,'change_failedcontrol'),(219,'Can delete failed control',73,'delete_failedcontrol'),(220,'Can add failed control version',74,'add_failedcontrolversion'),(221,'Can change failed control version',74,'change_failedcontrolversion'),(222,'Can delete failed control version',74,'delete_failedcontrolversion'),(223,'Can add familial quotient',75,'add_familialquotient'),(224,'Can change familial quotient',75,'change_familialquotient'),(225,'Can delete familial quotient',75,'delete_familialquotient'),(226,'Can add familial situation',76,'add_familialsituation'),(227,'Can change familial situation',76,'change_familialsituation'),(228,'Can delete familial situation',76,'delete_familialsituation'),(229,'Can add filter',77,'add_filter'),(230,'Can change filter',77,'change_filter'),(231,'Can delete filter',77,'delete_filter'),(232,'Can add gauge',78,'add_gauge'),(233,'Can change gauge',78,'change_gauge'),(234,'Can delete gauge',78,'delete_gauge'),(235,'Can add geo fr department',79,'add_geofrdepartment'),(236,'Can change geo fr department',79,'change_geofrdepartment'),(237,'Can delete geo fr department',79,'delete_geofrdepartment'),(238,'Can add geo fr region',80,'add_geofrregion'),(239,'Can change geo fr region',80,'change_geofrregion'),(240,'Can delete geo fr region',80,'delete_geofrregion'),(241,'Can add group auto user',81,'add_groupautouser'),(242,'Can change group auto user',81,'change_groupautouser'),(243,'Can delete group auto user',81,'delete_groupautouser'),(244,'Can add group contact',82,'add_groupcontact'),(245,'Can change group contact',82,'change_groupcontact'),(246,'Can delete group contact',82,'delete_groupcontact'),(247,'Can add group deleted',83,'add_groupdeleted'),(248,'Can change group deleted',83,'change_groupdeleted'),(249,'Can delete group deleted',83,'delete_groupdeleted'),(250,'Can add group detail',84,'add_groupdetail'),(251,'Can change group detail',84,'change_groupdetail'),(252,'Can delete group detail',84,'delete_groupdetail'),(253,'Can add group organism',85,'add_grouporganism'),(254,'Can change group organism',85,'change_grouporganism'),(255,'Can delete group organism',85,'delete_grouporganism'),(256,'Can add group professional',86,'add_groupprofessional'),(257,'Can change group professional',86,'change_groupprofessional'),(258,'Can delete group professional',86,'delete_groupprofessional'),(259,'Can add group table',87,'add_grouptable'),(260,'Can change group table',87,'change_grouptable'),(261,'Can delete group table',87,'delete_grouptable'),(262,'Can add group user',88,'add_groupuser'),(263,'Can change group user',88,'change_groupuser'),(264,'Can delete group user',88,'delete_groupuser'),(265,'Can add group workspace',89,'add_groupworkspace'),(266,'Can change group workspace',89,'change_groupworkspace'),(267,'Can delete group workspace',89,'delete_groupworkspace'),(268,'Can add hold',90,'add_hold'),(269,'Can change hold',90,'change_hold'),(270,'Can delete hold',90,'delete_hold'),(271,'Can add hold content',91,'add_holdcontent'),(272,'Can change hold content',91,'change_holdcontent'),(273,'Can delete hold content',91,'delete_holdcontent'),(274,'Can add hold transaction',92,'add_holdtransaction'),(275,'Can change hold transaction',92,'change_holdtransaction'),(276,'Can delete hold transaction',92,'delete_holdtransaction'),(277,'Can add hold transaction version',93,'add_holdtransactionversion'),(278,'Can change hold transaction version',93,'change_holdtransactionversion'),(279,'Can delete hold transaction version',93,'delete_holdtransactionversion'),(280,'Can add hold translation',94,'add_holdtranslation'),(281,'Can change hold translation',94,'change_holdtranslation'),(282,'Can delete hold translation',94,'delete_holdtranslation'),(283,'Can add hold version',95,'add_holdversion'),(284,'Can change hold version',95,'change_holdversion'),(285,'Can delete hold version',95,'delete_holdversion'),(286,'Can add invoice',96,'add_invoice'),(287,'Can change invoice',96,'change_invoice'),(288,'Can delete invoice',96,'delete_invoice'),(289,'Can add invoice version',97,'add_invoiceversion'),(290,'Can change invoice version',97,'change_invoiceversion'),(291,'Can delete invoice version',97,'delete_invoiceversion'),(292,'Can add itemable',98,'add_itemable'),(293,'Can change itemable',98,'change_itemable'),(294,'Can delete itemable',98,'delete_itemable'),(295,'Can add itemable version',99,'add_itemableversion'),(296,'Can change itemable version',99,'change_itemableversion'),(297,'Can delete itemable version',99,'delete_itemableversion'),(298,'Can add jabber',100,'add_jabber'),(299,'Can change jabber',100,'change_jabber'),(300,'Can delete jabber',100,'delete_jabber'),(301,'Can add location',101,'add_location'),(302,'Can change location',101,'change_location'),(303,'Can delete location',101,'delete_location'),(304,'Can add location booking',102,'add_locationbooking'),(305,'Can change location booking',102,'change_locationbooking'),(306,'Can delete location booking',102,'delete_locationbooking'),(307,'Can add location index',103,'add_locationindex'),(308,'Can change location index',103,'change_locationindex'),(309,'Can delete location index',103,'delete_locationindex'),(310,'Can add location version',104,'add_locationversion'),(311,'Can change location version',104,'change_locationversion'),(312,'Can delete location version',104,'delete_locationversion'),(313,'Can add manifestation',105,'add_manifestation'),(314,'Can change manifestation',105,'change_manifestation'),(315,'Can delete manifestation',105,'delete_manifestation'),(316,'Can add manifestation contact',106,'add_manifestationcontact'),(317,'Can change manifestation contact',106,'change_manifestationcontact'),(318,'Can delete manifestation contact',106,'delete_manifestationcontact'),(319,'Can add manifestation entry',107,'add_manifestationentry'),(320,'Can change manifestation entry',107,'change_manifestationentry'),(321,'Can delete manifestation entry',107,'delete_manifestationentry'),(322,'Can add manifestation extra information',108,'add_manifestationextrainformation'),(323,'Can change manifestation extra information',108,'change_manifestationextrainformation'),(324,'Can delete manifestation extra information',108,'delete_manifestationextrainformation'),(325,'Can add manifestation extra information version',109,'add_manifestationextrainformationversion'),(326,'Can change manifestation extra information version',109,'change_manifestationextrainformationversion'),(327,'Can delete manifestation extra information version',109,'delete_manifestationextrainformationversion'),(328,'Can add manifestation organizer',110,'add_manifestationorganizer'),(329,'Can change manifestation organizer',110,'change_manifestationorganizer'),(330,'Can delete manifestation organizer',110,'delete_manifestationorganizer'),(331,'Can add manifestation version',111,'add_manifestationversion'),(332,'Can change manifestation version',111,'change_manifestationversion'),(333,'Can delete manifestation version',111,'delete_manifestationversion'),(334,'Can add member card',112,'add_membercard'),(335,'Can change member card',112,'change_membercard'),(336,'Can delete member card',112,'delete_membercard'),(337,'Can add member card price',113,'add_membercardprice'),(338,'Can change member card price',113,'change_membercardprice'),(339,'Can delete member card price',113,'delete_membercardprice'),(340,'Can add member card price model',114,'add_membercardpricemodel'),(341,'Can change member card price model',114,'change_membercardpricemodel'),(342,'Can delete member card price model',114,'delete_membercardpricemodel'),(343,'Can add member card price model version',115,'add_membercardpricemodelversion'),(344,'Can change member card price model version',115,'change_membercardpricemodelversion'),(345,'Can delete member card price model version',115,'delete_membercardpricemodelversion'),(346,'Can add member card price version',116,'add_membercardpriceversion'),(347,'Can change member card price version',116,'change_membercardpriceversion'),(348,'Can delete member card price version',116,'delete_membercardpriceversion'),(349,'Can add member card type',117,'add_membercardtype'),(350,'Can change member card type',117,'change_membercardtype'),(351,'Can delete member card type',117,'delete_membercardtype'),(352,'Can add member card type translation',118,'add_membercardtypetranslation'),(353,'Can change member card type translation',118,'change_membercardtypetranslation'),(354,'Can delete member card type translation',118,'delete_membercardtypetranslation'),(355,'Can add member card type user',119,'add_membercardtypeuser'),(356,'Can change member card type user',119,'change_membercardtypeuser'),(357,'Can delete member card type user',119,'delete_membercardtypeuser'),(358,'Can add member card version',120,'add_membercardversion'),(359,'Can change member card version',120,'change_membercardversion'),(360,'Can delete member card version',120,'delete_membercardversion'),(361,'Can add meta event',121,'add_metaevent'),(362,'Can change meta event',121,'change_metaevent'),(363,'Can delete meta event',121,'delete_metaevent'),(364,'Can add meta event translation',122,'add_metaeventtranslation'),(365,'Can change meta event translation',122,'change_metaeventtranslation'),(366,'Can delete meta event translation',122,'delete_metaeventtranslation'),(367,'Can add meta event user',123,'add_metaeventuser'),(368,'Can change meta event user',123,'change_metaeventuser'),(369,'Can delete meta event user',123,'delete_metaeventuser'),(370,'Can add model type',124,'add_modeltype'),(371,'Can change model type',124,'change_modeltype'),(372,'Can delete model type',124,'delete_modeltype'),(373,'Can add option table',125,'add_optiontable'),(374,'Can change option table',125,'change_optiontable'),(375,'Can delete option table',125,'delete_optiontable'),(376,'Can add order table',126,'add_ordertable'),(377,'Can change order table',126,'change_ordertable'),(378,'Can delete order table',126,'delete_ordertable'),(379,'Can add order version',127,'add_orderversion'),(380,'Can change order version',127,'change_orderversion'),(381,'Can delete order version',127,'delete_orderversion'),(382,'Can add organism',128,'add_organism'),(383,'Can change organism',128,'change_organism'),(384,'Can delete organism',128,'delete_organism'),(385,'Can add organism category',129,'add_organismcategory'),(386,'Can change organism category',129,'change_organismcategory'),(387,'Can delete organism category',129,'delete_organismcategory'),(388,'Can add organism index',130,'add_organismindex'),(389,'Can change organism index',130,'change_organismindex'),(390,'Can delete organism index',130,'delete_organismindex'),(391,'Can add organism phonenumber',131,'add_organismphonenumber'),(392,'Can change organism phonenumber',131,'change_organismphonenumber'),(393,'Can delete organism phonenumber',131,'delete_organismphonenumber'),(394,'Can add organism version',132,'add_organismversion'),(395,'Can change organism version',132,'change_organismversion'),(396,'Can delete organism version',132,'delete_organismversion'),(397,'Can add payment',133,'add_payment'),(398,'Can change payment',133,'change_payment'),(399,'Can delete payment',133,'delete_payment'),(400,'Can add payment method',134,'add_paymentmethod'),(401,'Can change payment method',134,'change_paymentmethod'),(402,'Can delete payment method',134,'delete_paymentmethod'),(403,'Can add payment version',135,'add_paymentversion'),(404,'Can change payment version',135,'change_paymentversion'),(405,'Can delete payment version',135,'delete_paymentversion'),(406,'Can add phonenumber',136,'add_phonenumber'),(407,'Can change phonenumber',136,'change_phonenumber'),(408,'Can delete phonenumber',136,'delete_phonenumber'),(409,'Can add picture',137,'add_picture'),(410,'Can change picture',137,'change_picture'),(411,'Can delete picture',137,'delete_picture'),(412,'Can add picture version',138,'add_pictureversion'),(413,'Can change picture version',138,'change_pictureversion'),(414,'Can delete picture version',138,'delete_pictureversion'),(415,'Can add postalcode',139,'add_postalcode'),(416,'Can change postalcode',139,'change_postalcode'),(417,'Can delete postalcode',139,'delete_postalcode'),(418,'Can add price',140,'add_price'),(419,'Can change price',140,'change_price'),(420,'Can delete price',140,'delete_price'),(421,'Can add price gauge',141,'add_pricegauge'),(422,'Can change price gauge',141,'change_pricegauge'),(423,'Can delete price gauge',141,'delete_pricegauge'),(424,'Can add price manifestation',142,'add_pricemanifestation'),(425,'Can change price manifestation',142,'change_pricemanifestation'),(426,'Can delete price manifestation',142,'delete_pricemanifestation'),(427,'Can add price pos',143,'add_pricepos'),(428,'Can change price pos',143,'change_pricepos'),(429,'Can delete price pos',143,'delete_pricepos'),(430,'Can add price product',144,'add_priceproduct'),(431,'Can change price product',144,'change_priceproduct'),(432,'Can delete price product',144,'delete_priceproduct'),(433,'Can add price translation',145,'add_pricetranslation'),(434,'Can change price translation',145,'change_pricetranslation'),(435,'Can delete price translation',145,'delete_pricetranslation'),(436,'Can add product',146,'add_product'),(437,'Can change product',146,'change_product'),(438,'Can delete product',146,'delete_product'),(439,'Can add product category',147,'add_productcategory'),(440,'Can change product category',147,'change_productcategory'),(441,'Can delete product category',147,'delete_productcategory'),(442,'Can add product category index',148,'add_productcategoryindex'),(443,'Can change product category index',148,'change_productcategoryindex'),(444,'Can delete product category index',148,'delete_productcategoryindex'),(445,'Can add product category translation',149,'add_productcategorytranslation'),(446,'Can change product category translation',149,'change_productcategorytranslation'),(447,'Can delete product category translation',149,'delete_productcategorytranslation'),(448,'Can add product declination',150,'add_productdeclination'),(449,'Can change product declination',150,'change_productdeclination'),(450,'Can delete product declination',150,'delete_productdeclination'),(451,'Can add product declination index',151,'add_productdeclinationindex'),(452,'Can change product declination index',151,'change_productdeclinationindex'),(453,'Can delete product declination index',151,'delete_productdeclinationindex'),(454,'Can add product declination translation',152,'add_productdeclinationtranslation'),(455,'Can change product declination translation',152,'change_productdeclinationtranslation'),(456,'Can delete product declination translation',152,'delete_productdeclinationtranslation'),(457,'Can add product declination version',153,'add_productdeclinationversion'),(458,'Can change product declination version',153,'change_productdeclinationversion'),(459,'Can delete product declination version',153,'delete_productdeclinationversion'),(460,'Can add product index',154,'add_productindex'),(461,'Can change product index',154,'change_productindex'),(462,'Can delete product index',154,'delete_productindex'),(463,'Can add product link',155,'add_productlink'),(464,'Can change product link',155,'change_productlink'),(465,'Can delete product link',155,'delete_productlink'),(466,'Can add product manifestation link',156,'add_productmanifestationlink'),(467,'Can change product manifestation link',156,'change_productmanifestationlink'),(468,'Can delete product manifestation link',156,'delete_productmanifestationlink'),(469,'Can add product meta event link',157,'add_productmetaeventlink'),(470,'Can change product meta event link',157,'change_productmetaeventlink'),(471,'Can delete product meta event link',157,'delete_productmetaeventlink'),(472,'Can add product price link',158,'add_productpricelink'),(473,'Can change product price link',158,'change_productpricelink'),(474,'Can delete product price link',158,'delete_productpricelink'),(475,'Can add product product link',159,'add_productproductlink'),(476,'Can change product product link',159,'change_productproductlink'),(477,'Can delete product product link',159,'delete_productproductlink'),(478,'Can add product translation',160,'add_producttranslation'),(479,'Can change product translation',160,'change_producttranslation'),(480,'Can delete product translation',160,'delete_producttranslation'),(481,'Can add product version',161,'add_productversion'),(482,'Can change product version',161,'change_productversion'),(483,'Can delete product version',161,'delete_productversion'),(484,'Can add product workspace link',162,'add_productworkspacelink'),(485,'Can change product workspace link',162,'change_productworkspacelink'),(486,'Can delete product workspace link',162,'delete_productworkspacelink'),(487,'Can add professional',163,'add_professional'),(488,'Can change professional',163,'change_professional'),(489,'Can delete professional',163,'delete_professional'),(490,'Can add professional archive',164,'add_professionalarchive'),(491,'Can change professional archive',164,'change_professionalarchive'),(492,'Can delete professional archive',164,'delete_professionalarchive'),(493,'Can add professional base',165,'add_professionalbase'),(494,'Can change professional base',165,'change_professionalbase'),(495,'Can delete professional base',165,'delete_professionalbase'),(496,'Can add professional type',166,'add_professionaltype'),(497,'Can change professional type',166,'change_professionaltype'),(498,'Can delete professional type',166,'delete_professionaltype'),(499,'Can add raw accounting',167,'add_rawaccounting'),(500,'Can change raw accounting',167,'change_rawaccounting'),(501,'Can delete raw accounting',167,'delete_rawaccounting'),(502,'Can add raw accounting version',168,'add_rawaccountingversion'),(503,'Can change raw accounting version',168,'change_rawaccountingversion'),(504,'Can delete raw accounting version',168,'delete_rawaccountingversion'),(505,'Can add remote authentication',169,'add_remoteauthentication'),(506,'Can change remote authentication',169,'change_remoteauthentication'),(507,'Can delete remote authentication',169,'delete_remoteauthentication'),(508,'Can add seat',170,'add_seat'),(509,'Can change seat',170,'change_seat'),(510,'Can delete seat',170,'delete_seat'),(511,'Can add seat link',171,'add_seatlink'),(512,'Can change seat link',171,'change_seatlink'),(513,'Can delete seat link',171,'delete_seatlink'),(514,'Can add seated plan',172,'add_seatedplan'),(515,'Can change seated plan',172,'change_seatedplan'),(516,'Can delete seated plan',172,'delete_seatedplan'),(517,'Can add seated plan version',173,'add_seatedplanversion'),(518,'Can change seated plan version',173,'change_seatedplanversion'),(519,'Can delete seated plan version',173,'delete_seatedplanversion'),(520,'Can add seated plan workspace',174,'add_seatedplanworkspace'),(521,'Can change seated plan workspace',174,'change_seatedplanworkspace'),(522,'Can delete seated plan workspace',174,'delete_seatedplanworkspace'),(523,'Can add sf guard forgot password',175,'add_sfguardforgotpassword'),(524,'Can change sf guard forgot password',175,'change_sfguardforgotpassword'),(525,'Can delete sf guard forgot password',175,'delete_sfguardforgotpassword'),(526,'Can add sf guard group',176,'add_sfguardgroup'),(527,'Can change sf guard group',176,'change_sfguardgroup'),(528,'Can delete sf guard group',176,'delete_sfguardgroup'),(529,'Can add sf guard group permission',177,'add_sfguardgrouppermission'),(530,'Can change sf guard group permission',177,'change_sfguardgrouppermission'),(531,'Can delete sf guard group permission',177,'delete_sfguardgrouppermission'),(532,'Can add sf guard permission',178,'add_sfguardpermission'),(533,'Can change sf guard permission',178,'change_sfguardpermission'),(534,'Can delete sf guard permission',178,'delete_sfguardpermission'),(535,'Can add sf guard remember key',179,'add_sfguardrememberkey'),(536,'Can change sf guard remember key',179,'change_sfguardrememberkey'),(537,'Can delete sf guard remember key',179,'delete_sfguardrememberkey'),(538,'Can add sf guard user',180,'add_sfguarduser'),(539,'Can change sf guard user',180,'change_sfguarduser'),(540,'Can delete sf guard user',180,'delete_sfguarduser'),(541,'Can add sf guard user group',181,'add_sfguardusergroup'),(542,'Can change sf guard user group',181,'change_sfguardusergroup'),(543,'Can delete sf guard user group',181,'delete_sfguardusergroup'),(544,'Can add sf guard user permission',182,'add_sfguarduserpermission'),(545,'Can change sf guard user permission',182,'change_sfguarduserpermission'),(546,'Can delete sf guard user permission',182,'delete_sfguarduserpermission'),(547,'Can add slave ping',183,'add_slaveping'),(548,'Can change slave ping',183,'change_slaveping'),(549,'Can delete slave ping',183,'delete_slaveping'),(550,'Can add survey',184,'add_survey'),(551,'Can change survey',184,'change_survey'),(552,'Can delete survey',184,'delete_survey'),(553,'Can add survey answer',185,'add_surveyanswer'),(554,'Can change survey answer',185,'change_surveyanswer'),(555,'Can delete survey answer',185,'delete_surveyanswer'),(556,'Can add survey answer index',186,'add_surveyanswerindex'),(557,'Can change survey answer index',186,'change_surveyanswerindex'),(558,'Can delete survey answer index',186,'delete_surveyanswerindex'),(559,'Can add survey answer version',187,'add_surveyanswerversion'),(560,'Can change survey answer version',187,'change_surveyanswerversion'),(561,'Can delete survey answer version',187,'delete_surveyanswerversion'),(562,'Can add survey answers group',188,'add_surveyanswersgroup'),(563,'Can change survey answers group',188,'change_surveyanswersgroup'),(564,'Can delete survey answers group',188,'delete_surveyanswersgroup'),(565,'Can add survey answers group version',189,'add_surveyanswersgroupversion'),(566,'Can change survey answers group version',189,'change_surveyanswersgroupversion'),(567,'Can delete survey answers group version',189,'delete_surveyanswersgroupversion'),(568,'Can add survey apply to',190,'add_surveyapplyto'),(569,'Can change survey apply to',190,'change_surveyapplyto'),(570,'Can delete survey apply to',190,'delete_surveyapplyto'),(571,'Can add survey apply to version',191,'add_surveyapplytoversion'),(572,'Can change survey apply to version',191,'change_surveyapplytoversion'),(573,'Can delete survey apply to version',191,'delete_surveyapplytoversion'),(574,'Can add survey index',192,'add_surveyindex'),(575,'Can change survey index',192,'change_surveyindex'),(576,'Can delete survey index',192,'delete_surveyindex'),(577,'Can add survey query',193,'add_surveyquery'),(578,'Can change survey query',193,'change_surveyquery'),(579,'Can delete survey query',193,'delete_surveyquery'),(580,'Can add survey query index',194,'add_surveyqueryindex'),(581,'Can change survey query index',194,'change_surveyqueryindex'),(582,'Can delete survey query index',194,'delete_surveyqueryindex'),(583,'Can add survey query option',195,'add_surveyqueryoption'),(584,'Can change survey query option',195,'change_surveyqueryoption'),(585,'Can delete survey query option',195,'delete_surveyqueryoption'),(586,'Can add survey query option translation',196,'add_surveyqueryoptiontranslation'),(587,'Can change survey query option translation',196,'change_surveyqueryoptiontranslation'),(588,'Can delete survey query option translation',196,'delete_surveyqueryoptiontranslation'),(589,'Can add survey query translation',197,'add_surveyquerytranslation'),(590,'Can change survey query translation',197,'change_surveyquerytranslation'),(591,'Can delete survey query translation',197,'delete_surveyquerytranslation'),(592,'Can add survey query version',198,'add_surveyqueryversion'),(593,'Can change survey query version',198,'change_surveyqueryversion'),(594,'Can delete survey query version',198,'delete_surveyqueryversion'),(595,'Can add survey translation',199,'add_surveytranslation'),(596,'Can change survey translation',199,'change_surveytranslation'),(597,'Can delete survey translation',199,'delete_surveytranslation'),(598,'Can add survey version',200,'add_surveyversion'),(599,'Can change survey version',200,'change_surveyversion'),(600,'Can delete survey version',200,'delete_surveyversion'),(601,'Can add tax',201,'add_tax'),(602,'Can change tax',201,'change_tax'),(603,'Can delete tax',201,'delete_tax'),(604,'Can add tax manifestation',202,'add_taxmanifestation'),(605,'Can change tax manifestation',202,'change_taxmanifestation'),(606,'Can delete tax manifestation',202,'delete_taxmanifestation'),(607,'Can add tax price',203,'add_taxprice'),(608,'Can change tax price',203,'change_taxprice'),(609,'Can delete tax price',203,'delete_taxprice'),(610,'Can add tax user',204,'add_taxuser'),(611,'Can change tax user',204,'change_taxuser'),(612,'Can delete tax user',204,'delete_taxuser'),(613,'Can add tax version',205,'add_taxversion'),(614,'Can change tax version',205,'change_taxversion'),(615,'Can delete tax version',205,'delete_taxversion'),(616,'Can add ticket',206,'add_ticket'),(617,'Can change ticket',206,'change_ticket'),(618,'Can delete ticket',206,'delete_ticket'),(619,'Can add ticket version',207,'add_ticketversion'),(620,'Can change ticket version',207,'change_ticketversion'),(621,'Can delete ticket version',207,'delete_ticketversion'),(622,'Can add traceable',208,'add_traceable'),(623,'Can change traceable',208,'change_traceable'),(624,'Can delete traceable',208,'delete_traceable'),(625,'Can add traceable version',209,'add_traceableversion'),(626,'Can change traceable version',209,'change_traceableversion'),(627,'Can delete traceable version',209,'delete_traceableversion'),(628,'Can add transaction',210,'add_transaction'),(629,'Can change transaction',210,'change_transaction'),(630,'Can delete transaction',210,'delete_transaction'),(631,'Can add transaction version',211,'add_transactionversion'),(632,'Can change transaction version',211,'change_transactionversion'),(633,'Can delete transaction version',211,'delete_transactionversion'),(634,'Can add type of resources',212,'add_typeofresources'),(635,'Can change type of resources',212,'change_typeofresources'),(636,'Can delete type of resources',212,'delete_typeofresources'),(637,'Can add user price',213,'add_userprice'),(638,'Can change user price',213,'change_userprice'),(639,'Can delete user price',213,'delete_userprice'),(640,'Can add vat',214,'add_vat'),(641,'Can change vat',214,'change_vat'),(642,'Can delete vat',214,'delete_vat'),(643,'Can add vat version',215,'add_vatversion'),(644,'Can change vat version',215,'change_vatversion'),(645,'Can delete vat version',215,'delete_vatversion'),(646,'Can add web origin',216,'add_weborigin'),(647,'Can change web origin',216,'change_weborigin'),(648,'Can delete web origin',216,'delete_weborigin'),(649,'Can add web origin ip',217,'add_weboriginip'),(650,'Can change web origin ip',217,'change_weboriginip'),(651,'Can delete web origin ip',217,'delete_weboriginip'),(652,'Can add web origin version',218,'add_weboriginversion'),(653,'Can change web origin version',218,'change_weboriginversion'),(654,'Can delete web origin version',218,'delete_weboriginversion'),(655,'Can add workspace',219,'add_workspace'),(656,'Can change workspace',219,'change_workspace'),(657,'Can delete workspace',219,'delete_workspace'),(658,'Can add workspace price',220,'add_workspaceprice'),(659,'Can change workspace price',220,'change_workspaceprice'),(660,'Can delete workspace price',220,'delete_workspaceprice'),(661,'Can add workspace user',221,'add_workspaceuser'),(662,'Can change workspace user',221,'change_workspaceuser'),(663,'Can delete workspace user',221,'delete_workspaceuser'),(664,'Can add workspace user ordering',222,'add_workspaceuserordering'),(665,'Can change workspace user ordering',222,'change_workspaceuserordering'),(666,'Can delete workspace user ordering',222,'delete_workspaceuserordering'),(667,'Can add yob',223,'add_yob'),(668,'Can change yob',223,'change_yob'),(669,'Can delete yob',223,'delete_yob'),(670,'Can add log entry',224,'add_logentry'),(671,'Can change log entry',224,'change_logentry'),(672,'Can delete log entry',224,'delete_logentry'),(673,'Can add comment',225,'add_comment'),(674,'Can change comment',225,'change_comment'),(675,'Can delete comment',225,'delete_comment'),(676,'Can moderate comments',225,'can_moderate'),(677,'Can add comment flag',226,'add_commentflag'),(678,'Can change comment flag',226,'change_commentflag'),(679,'Can delete comment flag',226,'delete_commentflag');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(30) NOT NULL,
  `first_name` varchar(30) NOT NULL,
  `last_name` varchar(30) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`group_id`),
  KEY `auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id` (`group_id`),
  CONSTRAINT `auth_user_groups_group_id_33ac548dcf5f8e37_fk_auth_group_id` FOREIGN KEY (`group_id`) REFERENCES `auth_group` (`id`),
  CONSTRAINT `auth_user_groups_user_id_4b5ed4ffdb8fd9b0_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`,`permission_id`),
  KEY `auth_user_u_permission_id_384b62483d7071f0_fk_auth_permission_id` (`permission_id`),
  CONSTRAINT `auth_user_u_permission_id_384b62483d7071f0_fk_auth_permission_id` FOREIGN KEY (`permission_id`) REFERENCES `auth_permission` (`id`),
  CONSTRAINT `auth_user_user_permissi_user_id_7f0938558328534a_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_blogcategory`
--

DROP TABLE IF EXISTS `blog_blogcategory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_blogcategory` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  `title_en` varchar(500),
  `title_fr` varchar(500),
  PRIMARY KEY (`id`),
  KEY `blog_blogcategory_site_id_1565b70d240d75b_fk_django_site_id` (`site_id`),
  CONSTRAINT `blog_blogcategory_site_id_1565b70d240d75b_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_blogcategory`
--

LOCK TABLES `blog_blogcategory` WRITE;
/*!40000 ALTER TABLE `blog_blogcategory` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_blogcategory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_blogpost`
--

DROP TABLE IF EXISTS `blog_blogpost`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_blogpost` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `comments_count` int(11) NOT NULL,
  `keywords_string` varchar(500) NOT NULL,
  `rating_count` int(11) NOT NULL,
  `rating_sum` int(11) NOT NULL,
  `rating_average` double NOT NULL,
  `title` varchar(500) NOT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `_meta_title` varchar(500) DEFAULT NULL,
  `description` longtext NOT NULL,
  `gen_description` tinyint(1) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `status` int(11) NOT NULL,
  `publish_date` datetime DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `short_url` varchar(200) DEFAULT NULL,
  `in_sitemap` tinyint(1) NOT NULL,
  `content` longtext NOT NULL,
  `allow_comments` tinyint(1) NOT NULL,
  `featured_image` varchar(255) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `_meta_title_en` varchar(500),
  `_meta_title_fr` varchar(500),
  `content_en` longtext,
  `content_fr` longtext,
  `description_en` longtext,
  `description_fr` longtext,
  `title_en` varchar(500),
  `title_fr` varchar(500),
  PRIMARY KEY (`id`),
  KEY `blog_blogpost_site_id_3cd2a8869a3bc877_fk_django_site_id` (`site_id`),
  KEY `blog_blogpost_user_id_3d08a741310d8f6f_fk_auth_user_id` (`user_id`),
  KEY `blog_blogpost_publish_date_1015da2554a8e97f_uniq` (`publish_date`),
  CONSTRAINT `blog_blogpost_site_id_3cd2a8869a3bc877_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`),
  CONSTRAINT `blog_blogpost_user_id_3d08a741310d8f6f_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_blogpost`
--

LOCK TABLES `blog_blogpost` WRITE;
/*!40000 ALTER TABLE `blog_blogpost` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_blogpost` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_blogpost_categories`
--

DROP TABLE IF EXISTS `blog_blogpost_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_blogpost_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blogpost_id` int(11) NOT NULL,
  `blogcategory_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `blogpost_id` (`blogpost_id`,`blogcategory_id`),
  KEY `blog_bl_blogcategory_id_5c987a15b9426892_fk_blog_blogcategory_id` (`blogcategory_id`),
  CONSTRAINT `blog_bl_blogcategory_id_5c987a15b9426892_fk_blog_blogcategory_id` FOREIGN KEY (`blogcategory_id`) REFERENCES `blog_blogcategory` (`id`),
  CONSTRAINT `blog_blogpost_c_blogpost_id_11545014277324dc_fk_blog_blogpost_id` FOREIGN KEY (`blogpost_id`) REFERENCES `blog_blogpost` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_blogpost_categories`
--

LOCK TABLES `blog_blogpost_categories` WRITE;
/*!40000 ALTER TABLE `blog_blogpost_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_blogpost_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_blogpost_related_posts`
--

DROP TABLE IF EXISTS `blog_blogpost_related_posts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog_blogpost_related_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_blogpost_id` int(11) NOT NULL,
  `to_blogpost_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `from_blogpost_id` (`from_blogpost_id`,`to_blogpost_id`),
  KEY `blog_blogpos_to_blogpost_id_48f773544ff96fa5_fk_blog_blogpost_id` (`to_blogpost_id`),
  CONSTRAINT `blog_blogp_from_blogpost_id_161efba073ba4d90_fk_blog_blogpost_id` FOREIGN KEY (`from_blogpost_id`) REFERENCES `blog_blogpost` (`id`),
  CONSTRAINT `blog_blogpos_to_blogpost_id_48f773544ff96fa5_fk_blog_blogpost_id` FOREIGN KEY (`to_blogpost_id`) REFERENCES `blog_blogpost` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_blogpost_related_posts`
--

LOCK TABLES `blog_blogpost_related_posts` WRITE;
/*!40000 ALTER TABLE `blog_blogpost_related_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_blogpost_related_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `conf_setting`
--

DROP TABLE IF EXISTS `conf_setting`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `conf_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `value` varchar(2000) NOT NULL,
  `site_id` int(11) NOT NULL,
  `value_en` varchar(2000),
  `value_fr` varchar(2000),
  PRIMARY KEY (`id`),
  KEY `conf_setting_site_id_3971204fedfdfec8_fk_django_site_id` (`site_id`),
  CONSTRAINT `conf_setting_site_id_3971204fedfdfec8_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `conf_setting`
--

LOCK TABLES `conf_setting` WRITE;
/*!40000 ALTER TABLE `conf_setting` DISABLE KEYS */;
/*!40000 ALTER TABLE `conf_setting` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `core_sitepermission`
--

DROP TABLE IF EXISTS `core_sitepermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `core_sitepermission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `core_sitepermission_user_id_d964e296aed9970_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `core_sitepermission`
--

LOCK TABLES `core_sitepermission` WRITE;
/*!40000 ALTER TABLE `core_sitepermission` DISABLE KEYS */;
/*!40000 ALTER TABLE `core_sitepermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `core_sitepermission_sites`
--

DROP TABLE IF EXISTS `core_sitepermission_sites`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `core_sitepermission_sites` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sitepermission_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `sitepermission_id` (`sitepermission_id`,`site_id`),
  KEY `core_sitepermission_s_site_id_6dd5fffb45435677_fk_django_site_id` (`site_id`),
  CONSTRAINT `cor_sitepermission_id_64c924a870a6a554_fk_core_sitepermission_id` FOREIGN KEY (`sitepermission_id`) REFERENCES `core_sitepermission` (`id`),
  CONSTRAINT `core_sitepermission_s_site_id_6dd5fffb45435677_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `core_sitepermission_sites`
--

LOCK TABLES `core_sitepermission_sites` WRITE;
/*!40000 ALTER TABLE `core_sitepermission_sites` DISABLE KEYS */;
/*!40000 ALTER TABLE `core_sitepermission_sites` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_admin_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `action_time` datetime NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint(5) unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int(11) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `djang_content_type_id_697914295151027a_fk_django_content_type_id` (`content_type_id`),
  KEY `django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id` (`user_id`),
  CONSTRAINT `djang_content_type_id_697914295151027a_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_admin_log_user_id_52fdd58701c5f563_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_comment_flags`
--

DROP TABLE IF EXISTS `django_comment_flags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_comment_flags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `flag` varchar(30) NOT NULL,
  `flag_date` datetime NOT NULL,
  `comment_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_comment_flags_user_id_c7a132a641f11c1_uniq` (`user_id`,`comment_id`,`flag`),
  KEY `django_comment__comment_id_26f904a7f2b4c55_fk_django_comments_id` (`comment_id`),
  KEY `django_comment_flags_327a6c43` (`flag`),
  CONSTRAINT `django_comment__comment_id_26f904a7f2b4c55_fk_django_comments_id` FOREIGN KEY (`comment_id`) REFERENCES `django_comments` (`id`),
  CONSTRAINT `django_comment_flags_user_id_1442753a03512f4c_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_comment_flags`
--

LOCK TABLES `django_comment_flags` WRITE;
/*!40000 ALTER TABLE `django_comment_flags` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_comment_flags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_comments`
--

DROP TABLE IF EXISTS `django_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `object_pk` longtext NOT NULL,
  `user_name` varchar(50) NOT NULL,
  `user_email` varchar(254) NOT NULL,
  `user_url` varchar(200) NOT NULL,
  `comment` longtext NOT NULL,
  `submit_date` datetime NOT NULL,
  `ip_address` char(39) DEFAULT NULL,
  `is_public` tinyint(1) NOT NULL,
  `is_removed` tinyint(1) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `site_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `djang_content_type_id_39798e235626a505_fk_django_content_type_id` (`content_type_id`),
  KEY `django_comments_site_id_48b7896f6ea83216_fk_django_site_id` (`site_id`),
  KEY `django_comments_user_id_20e3794dfd3a7b1e_fk_auth_user_id` (`user_id`),
  CONSTRAINT `djang_content_type_id_39798e235626a505_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `django_comments_site_id_48b7896f6ea83216_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`),
  CONSTRAINT `django_comments_user_id_20e3794dfd3a7b1e_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_comments`
--

LOCK TABLES `django_comments` WRITE;
/*!40000 ALTER TABLE `django_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_content_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_45f3b1d93ec8c61c_uniq` (`app_label`,`model`)
) ENGINE=InnoDB AUTO_INCREMENT=227 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (224,'admin','logentry'),(2,'auth','group'),(1,'auth','permission'),(3,'auth','user'),(18,'blog','blogcategory'),(17,'blog','blogpost'),(8,'conf','setting'),(4,'contenttypes','contenttype'),(9,'core','sitepermission'),(225,'django_comments','comment'),(226,'django_comments','commentflag'),(27,'eve','accounting'),(28,'eve','accountingversion'),(29,'eve','addressable'),(30,'eve','addressableindex'),(31,'eve','addressableversion'),(32,'eve','attachment'),(33,'eve','attachmentversion'),(34,'eve','authentication'),(35,'eve','autogroup'),(36,'eve','bankpayment'),(37,'eve','boughtproduct'),(38,'eve','boughtproductversion'),(39,'eve','cancellation'),(40,'eve','cancellationversion'),(41,'eve','checkpoint'),(42,'eve','color'),(43,'eve','contact'),(44,'eve','contactarchive'),(45,'eve','contactentry'),(46,'eve','contacteventarchives'),(47,'eve','contactindex'),(48,'eve','contactphonenumber'),(49,'eve','contactrelationship'),(50,'eve','contactrelationshiptype'),(51,'eve','contactversion'),(52,'eve','control'),(53,'eve','controlversion'),(54,'eve','email'),(55,'eve','emailaction'),(56,'eve','emailcontact'),(57,'eve','emailexternallink'),(58,'eve','emailindex'),(59,'eve','emaillink'),(60,'eve','emailorganism'),(61,'eve','emailprofessional'),(62,'eve','emailspool'),(63,'eve','emailtemplate'),(64,'eve','entry'),(65,'eve','entryelement'),(66,'eve','entrytickets'),(67,'eve','event'),(68,'eve','eventcategory'),(69,'eve','eventcompany'),(70,'eve','eventindex'),(71,'eve','eventtranslation'),(72,'eve','eventversion'),(73,'eve','failedcontrol'),(74,'eve','failedcontrolversion'),(75,'eve','familialquotient'),(76,'eve','familialsituation'),(77,'eve','filter'),(78,'eve','gauge'),(79,'eve','geofrdepartment'),(80,'eve','geofrregion'),(81,'eve','groupautouser'),(82,'eve','groupcontact'),(83,'eve','groupdeleted'),(84,'eve','groupdetail'),(85,'eve','grouporganism'),(86,'eve','groupprofessional'),(87,'eve','grouptable'),(88,'eve','groupuser'),(89,'eve','groupworkspace'),(90,'eve','hold'),(91,'eve','holdcontent'),(92,'eve','holdtransaction'),(93,'eve','holdtransactionversion'),(94,'eve','holdtranslation'),(95,'eve','holdversion'),(96,'eve','invoice'),(97,'eve','invoiceversion'),(98,'eve','itemable'),(99,'eve','itemableversion'),(100,'eve','jabber'),(101,'eve','location'),(102,'eve','locationbooking'),(103,'eve','locationindex'),(104,'eve','locationversion'),(105,'eve','manifestation'),(106,'eve','manifestationcontact'),(107,'eve','manifestationentry'),(108,'eve','manifestationextrainformation'),(109,'eve','manifestationextrainformationversion'),(110,'eve','manifestationorganizer'),(111,'eve','manifestationversion'),(112,'eve','membercard'),(113,'eve','membercardprice'),(114,'eve','membercardpricemodel'),(115,'eve','membercardpricemodelversion'),(116,'eve','membercardpriceversion'),(117,'eve','membercardtype'),(118,'eve','membercardtypetranslation'),(119,'eve','membercardtypeuser'),(120,'eve','membercardversion'),(121,'eve','metaevent'),(122,'eve','metaeventtranslation'),(123,'eve','metaeventuser'),(124,'eve','modeltype'),(125,'eve','optiontable'),(126,'eve','ordertable'),(127,'eve','orderversion'),(128,'eve','organism'),(129,'eve','organismcategory'),(130,'eve','organismindex'),(131,'eve','organismphonenumber'),(132,'eve','organismversion'),(133,'eve','payment'),(134,'eve','paymentmethod'),(135,'eve','paymentversion'),(136,'eve','phonenumber'),(137,'eve','picture'),(138,'eve','pictureversion'),(139,'eve','postalcode'),(140,'eve','price'),(141,'eve','pricegauge'),(142,'eve','pricemanifestation'),(143,'eve','pricepos'),(144,'eve','priceproduct'),(145,'eve','pricetranslation'),(146,'eve','product'),(147,'eve','productcategory'),(148,'eve','productcategoryindex'),(149,'eve','productcategorytranslation'),(150,'eve','productdeclination'),(151,'eve','productdeclinationindex'),(152,'eve','productdeclinationtranslation'),(153,'eve','productdeclinationversion'),(154,'eve','productindex'),(155,'eve','productlink'),(156,'eve','productmanifestationlink'),(157,'eve','productmetaeventlink'),(158,'eve','productpricelink'),(159,'eve','productproductlink'),(160,'eve','producttranslation'),(161,'eve','productversion'),(162,'eve','productworkspacelink'),(163,'eve','professional'),(164,'eve','professionalarchive'),(165,'eve','professionalbase'),(166,'eve','professionaltype'),(167,'eve','rawaccounting'),(168,'eve','rawaccountingversion'),(169,'eve','remoteauthentication'),(170,'eve','seat'),(172,'eve','seatedplan'),(173,'eve','seatedplanversion'),(174,'eve','seatedplanworkspace'),(171,'eve','seatlink'),(175,'eve','sfguardforgotpassword'),(176,'eve','sfguardgroup'),(177,'eve','sfguardgrouppermission'),(178,'eve','sfguardpermission'),(179,'eve','sfguardrememberkey'),(180,'eve','sfguarduser'),(181,'eve','sfguardusergroup'),(182,'eve','sfguarduserpermission'),(183,'eve','slaveping'),(184,'eve','survey'),(185,'eve','surveyanswer'),(186,'eve','surveyanswerindex'),(188,'eve','surveyanswersgroup'),(189,'eve','surveyanswersgroupversion'),(187,'eve','surveyanswerversion'),(190,'eve','surveyapplyto'),(191,'eve','surveyapplytoversion'),(192,'eve','surveyindex'),(193,'eve','surveyquery'),(194,'eve','surveyqueryindex'),(195,'eve','surveyqueryoption'),(196,'eve','surveyqueryoptiontranslation'),(197,'eve','surveyquerytranslation'),(198,'eve','surveyqueryversion'),(199,'eve','surveytranslation'),(200,'eve','surveyversion'),(201,'eve','tax'),(202,'eve','taxmanifestation'),(203,'eve','taxprice'),(204,'eve','taxuser'),(205,'eve','taxversion'),(206,'eve','ticket'),(207,'eve','ticketversion'),(208,'eve','traceable'),(209,'eve','traceableversion'),(210,'eve','transaction'),(211,'eve','transactionversion'),(212,'eve','typeofresources'),(213,'eve','userprice'),(214,'eve','vat'),(215,'eve','vatversion'),(216,'eve','weborigin'),(217,'eve','weboriginip'),(218,'eve','weboriginversion'),(219,'eve','workspace'),(220,'eve','workspaceprice'),(221,'eve','workspaceuser'),(222,'eve','workspaceuserordering'),(223,'eve','yob'),(20,'forms','field'),(22,'forms','fieldentry'),(19,'forms','form'),(21,'forms','formentry'),(23,'galleries','gallery'),(24,'galleries','galleryimage'),(12,'generic','assignedkeyword'),(11,'generic','keyword'),(13,'generic','rating'),(10,'generic','threadedcomment'),(16,'pages','link'),(14,'pages','page'),(15,'pages','richtextpage'),(5,'redirects','redirect'),(6,'sessions','session'),(7,'sites','site'),(25,'twitter','query'),(26,'twitter','tweet');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_migrations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2016-01-27 15:26:01'),(2,'auth','0001_initial','2016-01-27 15:26:03'),(3,'admin','0001_initial','2016-01-27 15:26:03'),(4,'contenttypes','0002_remove_content_type_name','2016-01-27 15:26:03'),(5,'auth','0002_alter_permission_name_max_length','2016-01-27 15:26:03'),(6,'auth','0003_alter_user_email_max_length','2016-01-27 15:26:03'),(7,'auth','0004_alter_user_username_opts','2016-01-27 15:26:03'),(8,'auth','0005_alter_user_last_login_null','2016-01-27 15:26:03'),(9,'auth','0006_require_contenttypes_0002','2016-01-27 15:26:03'),(10,'sites','0001_initial','2016-01-27 15:26:03'),(11,'blog','0001_initial','2016-01-27 15:26:05'),(12,'blog','0002_auto_20150527_1555','2016-01-27 15:26:05'),(13,'blog','0003_auto_20151223_1313','2016-01-27 15:26:06'),(14,'conf','0001_initial','2016-01-27 15:26:06'),(15,'conf','0002_auto_20151223_1313','2016-01-27 15:26:06'),(16,'core','0001_initial','2016-01-27 15:26:07'),(17,'core','0002_auto_20150414_2140','2016-01-27 15:26:07'),(18,'django_comments','0001_initial','2016-01-27 15:26:08'),(19,'django_comments','0002_update_user_email_field_length','2016-01-27 15:26:08'),(20,'eve','0001_initial','2016-01-27 15:26:13'),(21,'pages','0001_initial','2016-01-27 15:26:14'),(22,'forms','0001_initial','2016-01-27 15:26:15'),(23,'forms','0002_auto_20141227_0224','2016-01-27 15:26:15'),(24,'forms','0003_emailfield','2016-01-27 15:26:16'),(25,'forms','0004_auto_20150517_0510','2016-01-27 15:26:16'),(26,'forms','0005_auto_20151223_1313','2016-01-27 15:26:21'),(27,'galleries','0001_initial','2016-01-27 15:26:21'),(28,'galleries','0002_auto_20141227_0224','2016-01-27 15:26:21'),(29,'galleries','0003_auto_20151223_1313','2016-01-27 15:26:22'),(30,'generic','0001_initial','2016-01-27 15:26:25'),(31,'generic','0002_auto_20141227_0224','2016-01-27 15:26:25'),(32,'pages','0002_auto_20141227_0224','2016-01-27 15:26:25'),(33,'pages','0003_auto_20150527_1555','2016-01-27 15:26:26'),(34,'pages','0004_auto_20151223_1313','2016-01-27 15:26:28'),(35,'redirects','0001_initial','2016-01-27 15:26:29'),(36,'sessions','0001_initial','2016-01-27 15:26:29'),(37,'twitter','0001_initial','2016-01-27 15:26:29');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_redirect`
--

DROP TABLE IF EXISTS `django_redirect`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_redirect` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `site_id` int(11) NOT NULL,
  `old_path` varchar(200) NOT NULL,
  `new_path` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `site_id` (`site_id`,`old_path`),
  KEY `django_redirect_91a0b591` (`old_path`),
  CONSTRAINT `django_redirect_site_id_121a4403f653e524_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_redirect`
--

LOCK TABLES `django_redirect` WRITE;
/*!40000 ALTER TABLE `django_redirect` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_redirect` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_de54fa62` (`expire_date`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_site`
--

DROP TABLE IF EXISTS `django_site`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `django_site` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `domain` varchar(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_site`
--

LOCK TABLES `django_site` WRITE;
/*!40000 ALTER TABLE `django_site` DISABLE KEYS */;
INSERT INTO `django_site` VALUES (1,'example.com','example.com');
/*!40000 ALTER TABLE `django_site` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_field`
--

DROP TABLE IF EXISTS `forms_field`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `_order` int(11) DEFAULT NULL,
  `label` varchar(200) NOT NULL,
  `field_type` int(11) NOT NULL,
  `required` tinyint(1) NOT NULL,
  `visible` tinyint(1) NOT NULL,
  `choices` varchar(1000) NOT NULL,
  `default` varchar(2000) NOT NULL,
  `placeholder_text` varchar(100) NOT NULL,
  `help_text` varchar(100) NOT NULL,
  `form_id` int(11) NOT NULL,
  `choices_en` varchar(1000),
  `choices_fr` varchar(1000),
  `default_en` varchar(2000),
  `default_fr` varchar(2000),
  `help_text_en` varchar(100),
  `help_text_fr` varchar(100),
  `label_en` varchar(200),
  `label_fr` varchar(200),
  `placeholder_text_en` varchar(100),
  `placeholder_text_fr` varchar(100),
  PRIMARY KEY (`id`),
  KEY `forms_field_d6cba1ad` (`form_id`),
  CONSTRAINT `forms_field_form_id_3660963e8b17a175_fk_forms_form_page_ptr_id` FOREIGN KEY (`form_id`) REFERENCES `forms_form` (`page_ptr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_field`
--

LOCK TABLES `forms_field` WRITE;
/*!40000 ALTER TABLE `forms_field` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_field` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_fieldentry`
--

DROP TABLE IF EXISTS `forms_fieldentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_fieldentry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `field_id` int(11) NOT NULL,
  `value` varchar(2000) DEFAULT NULL,
  `entry_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `forms_fieldentry_b64a62ea` (`entry_id`),
  CONSTRAINT `forms_fieldentry_entry_id_7b83c1acf66a9d67_fk_forms_formentry_id` FOREIGN KEY (`entry_id`) REFERENCES `forms_formentry` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_fieldentry`
--

LOCK TABLES `forms_fieldentry` WRITE;
/*!40000 ALTER TABLE `forms_fieldentry` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_fieldentry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_form`
--

DROP TABLE IF EXISTS `forms_form`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_form` (
  `page_ptr_id` int(11) NOT NULL,
  `content` longtext NOT NULL,
  `button_text` varchar(50) NOT NULL,
  `response` longtext NOT NULL,
  `send_email` tinyint(1) NOT NULL,
  `email_from` varchar(254) NOT NULL,
  `email_copies` varchar(200) NOT NULL,
  `email_subject` varchar(200) NOT NULL,
  `email_message` longtext NOT NULL,
  `button_text_en` varchar(50),
  `button_text_fr` varchar(50),
  `content_en` longtext,
  `content_fr` longtext,
  `email_message_en` longtext,
  `email_message_fr` longtext,
  `email_subject_en` varchar(200),
  `email_subject_fr` varchar(200),
  `response_en` longtext,
  `response_fr` longtext,
  PRIMARY KEY (`page_ptr_id`),
  CONSTRAINT `forms_form_page_ptr_id_2363a7422cd85950_fk_pages_page_id` FOREIGN KEY (`page_ptr_id`) REFERENCES `pages_page` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_form`
--

LOCK TABLES `forms_form` WRITE;
/*!40000 ALTER TABLE `forms_form` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_form` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `forms_formentry`
--

DROP TABLE IF EXISTS `forms_formentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `forms_formentry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entry_time` datetime NOT NULL,
  `form_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `forms_forment_form_id_5fca4521fe2d9b9b_fk_forms_form_page_ptr_id` (`form_id`),
  CONSTRAINT `forms_forment_form_id_5fca4521fe2d9b9b_fk_forms_form_page_ptr_id` FOREIGN KEY (`form_id`) REFERENCES `forms_form` (`page_ptr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `forms_formentry`
--

LOCK TABLES `forms_formentry` WRITE;
/*!40000 ALTER TABLE `forms_formentry` DISABLE KEYS */;
/*!40000 ALTER TABLE `forms_formentry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `galleries_gallery`
--

DROP TABLE IF EXISTS `galleries_gallery`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `galleries_gallery` (
  `page_ptr_id` int(11) NOT NULL,
  `content` longtext NOT NULL,
  `zip_import` varchar(100) NOT NULL,
  `content_en` longtext,
  `content_fr` longtext,
  PRIMARY KEY (`page_ptr_id`),
  CONSTRAINT `galleries_gallery_page_ptr_id_6cf84f17bef39d64_fk_pages_page_id` FOREIGN KEY (`page_ptr_id`) REFERENCES `pages_page` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `galleries_gallery`
--

LOCK TABLES `galleries_gallery` WRITE;
/*!40000 ALTER TABLE `galleries_gallery` DISABLE KEYS */;
/*!40000 ALTER TABLE `galleries_gallery` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `galleries_galleryimage`
--

DROP TABLE IF EXISTS `galleries_galleryimage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `galleries_galleryimage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `_order` int(11) DEFAULT NULL,
  `file` varchar(200) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `gallery_id` int(11) NOT NULL,
  `description_en` varchar(1000),
  `description_fr` varchar(1000),
  PRIMARY KEY (`id`),
  KEY `gal_gallery_id_5f743e845a8d8b01_fk_galleries_gallery_page_ptr_id` (`gallery_id`),
  CONSTRAINT `gal_gallery_id_5f743e845a8d8b01_fk_galleries_gallery_page_ptr_id` FOREIGN KEY (`gallery_id`) REFERENCES `galleries_gallery` (`page_ptr_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `galleries_galleryimage`
--

LOCK TABLES `galleries_galleryimage` WRITE;
/*!40000 ALTER TABLE `galleries_galleryimage` DISABLE KEYS */;
/*!40000 ALTER TABLE `galleries_galleryimage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_assignedkeyword`
--

DROP TABLE IF EXISTS `generic_assignedkeyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generic_assignedkeyword` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `_order` int(11) DEFAULT NULL,
  `object_pk` int(11) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `keyword_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `gener_content_type_id_340baca94a5341cc_fk_django_content_type_id` (`content_type_id`),
  KEY `generic_assignedkeyword_5c003bba` (`keyword_id`),
  CONSTRAINT `gener_content_type_id_340baca94a5341cc_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `generic_assign_keyword_id_61d6fae39a09e150_fk_generic_keyword_id` FOREIGN KEY (`keyword_id`) REFERENCES `generic_keyword` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_assignedkeyword`
--

LOCK TABLES `generic_assignedkeyword` WRITE;
/*!40000 ALTER TABLE `generic_assignedkeyword` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_assignedkeyword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_keyword`
--

DROP TABLE IF EXISTS `generic_keyword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generic_keyword` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(500) NOT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `site_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `generic_keyword_site_id_7727e5473a304097_fk_django_site_id` (`site_id`),
  CONSTRAINT `generic_keyword_site_id_7727e5473a304097_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_keyword`
--

LOCK TABLES `generic_keyword` WRITE;
/*!40000 ALTER TABLE `generic_keyword` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_keyword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_rating`
--

DROP TABLE IF EXISTS `generic_rating`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generic_rating` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `value` int(11) NOT NULL,
  `rating_date` datetime DEFAULT NULL,
  `object_pk` int(11) NOT NULL,
  `content_type_id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `gener_content_type_id_28e2096071be2a4f_fk_django_content_type_id` (`content_type_id`),
  KEY `generic_rating_user_id_323dfdffa0c13bac_fk_auth_user_id` (`user_id`),
  CONSTRAINT `gener_content_type_id_28e2096071be2a4f_fk_django_content_type_id` FOREIGN KEY (`content_type_id`) REFERENCES `django_content_type` (`id`),
  CONSTRAINT `generic_rating_user_id_323dfdffa0c13bac_fk_auth_user_id` FOREIGN KEY (`user_id`) REFERENCES `auth_user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_rating`
--

LOCK TABLES `generic_rating` WRITE;
/*!40000 ALTER TABLE `generic_rating` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_rating` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `generic_threadedcomment`
--

DROP TABLE IF EXISTS `generic_threadedcomment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `generic_threadedcomment` (
  `comment_ptr_id` int(11) NOT NULL,
  `rating_count` int(11) NOT NULL,
  `rating_sum` int(11) NOT NULL,
  `rating_average` double NOT NULL,
  `by_author` tinyint(1) NOT NULL,
  `replied_to_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`comment_ptr_id`),
  KEY `D7947a861fd85b8f3a6688a645eb55f3` (`replied_to_id`),
  CONSTRAINT `D7947a861fd85b8f3a6688a645eb55f3` FOREIGN KEY (`replied_to_id`) REFERENCES `generic_threadedcomment` (`comment_ptr_id`),
  CONSTRAINT `generic_th_comment_ptr_id_7ce6b4612f86bbc6_fk_django_comments_id` FOREIGN KEY (`comment_ptr_id`) REFERENCES `django_comments` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `generic_threadedcomment`
--

LOCK TABLES `generic_threadedcomment` WRITE;
/*!40000 ALTER TABLE `generic_threadedcomment` DISABLE KEYS */;
/*!40000 ALTER TABLE `generic_threadedcomment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages_link`
--

DROP TABLE IF EXISTS `pages_link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages_link` (
  `page_ptr_id` int(11) NOT NULL,
  PRIMARY KEY (`page_ptr_id`),
  CONSTRAINT `pages_link_page_ptr_id_560afe0956838fd3_fk_pages_page_id` FOREIGN KEY (`page_ptr_id`) REFERENCES `pages_page` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_link`
--

LOCK TABLES `pages_link` WRITE;
/*!40000 ALTER TABLE `pages_link` DISABLE KEYS */;
/*!40000 ALTER TABLE `pages_link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages_page`
--

DROP TABLE IF EXISTS `pages_page`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages_page` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `keywords_string` varchar(500) NOT NULL,
  `title` varchar(500) NOT NULL,
  `slug` varchar(2000) DEFAULT NULL,
  `_meta_title` varchar(500) DEFAULT NULL,
  `description` longtext NOT NULL,
  `gen_description` tinyint(1) NOT NULL,
  `created` datetime DEFAULT NULL,
  `updated` datetime DEFAULT NULL,
  `status` int(11) NOT NULL,
  `publish_date` datetime DEFAULT NULL,
  `expiry_date` datetime DEFAULT NULL,
  `short_url` varchar(200) DEFAULT NULL,
  `in_sitemap` tinyint(1) NOT NULL,
  `_order` int(11) DEFAULT NULL,
  `in_menus` varchar(100),
  `titles` varchar(1000) DEFAULT NULL,
  `content_model` varchar(50) DEFAULT NULL,
  `login_required` tinyint(1) NOT NULL,
  `parent_id` int(11),
  `site_id` int(11) NOT NULL,
  `_meta_title_en` varchar(500),
  `_meta_title_fr` varchar(500),
  `description_en` longtext,
  `description_fr` longtext,
  `title_en` varchar(500),
  `title_fr` varchar(500),
  `titles_en` varchar(1000),
  `titles_fr` varchar(1000),
  PRIMARY KEY (`id`),
  KEY `pages_page_6be37982` (`parent_id`),
  KEY `pages_page_9365d6e7` (`site_id`),
  KEY `pages_page_publish_date_4b581dded15f4cdf_uniq` (`publish_date`),
  CONSTRAINT `pages_page_parent_id_7bf3217d99139bb8_fk_pages_page_id` FOREIGN KEY (`parent_id`) REFERENCES `pages_page` (`id`),
  CONSTRAINT `pages_page_site_id_22239f4327580ae9_fk_django_site_id` FOREIGN KEY (`site_id`) REFERENCES `django_site` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_page`
--

LOCK TABLES `pages_page` WRITE;
/*!40000 ALTER TABLE `pages_page` DISABLE KEYS */;
/*!40000 ALTER TABLE `pages_page` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages_richtextpage`
--

DROP TABLE IF EXISTS `pages_richtextpage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages_richtextpage` (
  `page_ptr_id` int(11) NOT NULL,
  `content` longtext NOT NULL,
  `content_en` longtext,
  `content_fr` longtext,
  PRIMARY KEY (`page_ptr_id`),
  CONSTRAINT `pages_richtextpage_page_ptr_id_303aa0962fe9608b_fk_pages_page_id` FOREIGN KEY (`page_ptr_id`) REFERENCES `pages_page` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages_richtextpage`
--

LOCK TABLES `pages_richtextpage` WRITE;
/*!40000 ALTER TABLE `pages_richtextpage` DISABLE KEYS */;
/*!40000 ALTER TABLE `pages_richtextpage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `twitter_query`
--

DROP TABLE IF EXISTS `twitter_query`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `twitter_query` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` varchar(10) NOT NULL,
  `value` varchar(140) NOT NULL,
  `interested` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `twitter_query`
--

LOCK TABLES `twitter_query` WRITE;
/*!40000 ALTER TABLE `twitter_query` DISABLE KEYS */;
/*!40000 ALTER TABLE `twitter_query` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `twitter_tweet`
--

DROP TABLE IF EXISTS `twitter_tweet`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `twitter_tweet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `remote_id` varchar(50) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `text` longtext,
  `profile_image_url` varchar(200) DEFAULT NULL,
  `user_name` varchar(100) DEFAULT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `retweeter_profile_image_url` varchar(200) DEFAULT NULL,
  `retweeter_user_name` varchar(100) DEFAULT NULL,
  `retweeter_full_name` varchar(100) DEFAULT NULL,
  `query_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `twitter_tweet_query_id_5de4bfd6dfe46065_fk_twitter_query_id` (`query_id`),
  CONSTRAINT `twitter_tweet_query_id_5de4bfd6dfe46065_fk_twitter_query_id` FOREIGN KEY (`query_id`) REFERENCES `twitter_query` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `twitter_tweet`
--

LOCK TABLES `twitter_tweet` WRITE;
/*!40000 ALTER TABLE `twitter_tweet` DISABLE KEYS */;
/*!40000 ALTER TABLE `twitter_tweet` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-01-27 15:26:56
